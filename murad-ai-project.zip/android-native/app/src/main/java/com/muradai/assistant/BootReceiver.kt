package com.muradai.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * Restarts Murad AI's Foreground Microphone Service after device reboot or app update
 * when microphone permission is granted and OPPO Auto-launch is enabled.
 * On Android 14+ if background microphone FGS start is restricted by OEM, posts a 1-tap notification.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val supportedActions = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_MY_PACKAGE_REPLACED
        )
        if (action !in supportedActions) {
            return
        }

        val hasMic = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasMic) return

        val prefs = context.getSharedPreferences(WakeWordService.PREFS_NAME, Context.MODE_PRIVATE)
        val wakeEnabled = prefs.getBoolean(WakeWordService.KEY_WAKE_ENABLED, true)
        if (!wakeEnabled) return

        val serviceIntent = Intent(context, WakeWordService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (_: Exception) {
            // Android 14+ may block starting a microphone FGS directly from BOOT_COMPLETED unless exempted.
            // Show a gentle 1-tap notification to re-arm "Murad" Wake Word cleanly.
            showResumeNotification(context)
        }
    }

    private fun showResumeNotification(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }

            val manager = context.getSystemService(NotificationManager::class.java) ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    WakeWordService.CHANNEL_ID,
                    "Murad AI Wake Word Service",
                    NotificationManager.IMPORTANCE_LOW
                )
                manager.createNotificationChannel(channel)
            }

            val openIntent = PendingIntent.getActivity(
                context,
                1002,
                Intent(context, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                },
                PendingIntent.FLAG_IMMUTABLE
            )

            val notification = Notification.Builder(context, WakeWordService.CHANNEL_ID)
                .setContentTitle("Murad AI ভয়েস সহকারী")
                .setContentText("“Murad” Wake Word পুনরায় চালু করতে এখানে চাপুন")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(openIntent)
                .setAutoCancel(true)
                .build()

            manager.notify(WakeWordService.NOTIFICATION_ID + 1, notification)
        } catch (_: Exception) {
        }
    }
}
