# Murad AI — Native Android Project (Background & Screen-Off "Murad" Wake Word)

এই ফোল্ডারে **Murad AI**-এর সম্পূর্ণ Native Android (Kotlin + Gradle) প্রজেক্ট রয়েছে, যা আপনার **OPPO A18 (4GB RAM)** ফোনে **অ্যাপ বন্ধ, ব্যাকগ্রাউন্ডে বা স্ক্রিন বন্ধ থাকলেও শুধু `"Murad"` ডাক শুনে** জেগে ওঠার জন্য তৈরি।

## নিরাপত্তা ও API Key সুরক্ষা
- এই Android প্রজেক্টে বা APK-তে **কোনো গোপন `GEMINI_API_KEY` রাখা হয়নি**।
- অ্যাপটি নিরাপদ HTTPS সার্ভারের মাধ্যমে `/api/chat` এন্ডপয়েন্টের সাথে যোগাযোগ করে, ফলে API Key সবসময় সার্ভারেই সুরক্ষিত থাকে।

## APK তৈরির ২টি সহজ উপায় (কোড না লিখেই)
1. **GitHub Actions ক্লাউড বিল্ড (পিসি ছাড়াই):** প্রজেক্টটি GitHub-এ আপলোড করলে `.github/workflows/build-android-apk.yml` স্বয়ংক্রিয়ভাবে ইনস্টলযোগ্য `app-debug.apk` তৈরি করে দেবে—Actions ট্যাব থেকে **MuradAI-Android-APK** ডাউনলোড করে ফোনে ইনস্টল করতে পারবেন।
2. **Android Studio (পিসি):** কম্পিউটারে **Android Studio**-তে `android-native` ফোল্ডারটি ওপেন করে **Build → Build Bundle(s) / APK(s) → Build APK(s)** ক্লিক করুন।

## OPPO A18-এ ব্যাকগ্রাউন্ড ও স্ক্রিন-অফ সেটআপ
APK ইনস্টল করার পর নিচের ৩টি সেটিংস চালু রাখুন:
- **Permissions:** Microphone ও Notifications **Allow** করুন।
- **Battery usage:** **Allow background activity** ও **Allow foreground activity** চালু করুন।
- **Auto-launch:** চালু করুন, যাতে অ্যাপ বন্ধ করলেও বা ফোন রিস্টার্টের পরও Background Foreground Service চালু থাকে।
