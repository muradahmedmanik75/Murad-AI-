export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  isVoicePrompt?: boolean;
  isError?: boolean;
  retryText?: string;
  action?: AssistantAction;
}

export type AITone = 'friendly' | 'formal' | 'academic' | 'creative';

export type AssistantActionType =
  | 'none'
  | 'open_website'
  | 'search_web'
  | 'open_app'
  | 'make_call'
  | 'send_sms'
  | 'set_alarm'
  | 'set_timer'
  | 'clear_chat'
  | 'delete_alarms'
  | 'check_capabilities'
  | 'unclear';

export interface AssistantAction {
  type: AssistantActionType;
  requiresConfirmation: boolean;
  confirmationReason?: string;
  label?: string;
  url?: string;
  phone?: string;
  smsBody?: string;
  appName?: string;
  alarmTime?: string; // HH:mm 24h
  alarmLabel?: string;
  timerSeconds?: number;
  nativeNote?: string;
}

export interface AlarmItem {
  id: string;
  label: string;
  timeDisplay: string;
  type: 'alarm' | 'timer';
  triggerAt: number;
  active: boolean;
}

export interface QuickContact {
  id: string;
  name: string;
  phone: string;
}

export interface UserProfile {
  name: string;
  bio: string;
  avatarUrl: string;
  voiceSpeed: number; // 0.8 - 1.2
  voicePitch: number; // 0.8 - 1.2
  autoSpeakVoice: boolean;
  aiTone: AITone;
  joinedDate: string;
  wakeWordEnabled?: boolean;
  alwaysReadyVoice?: boolean;
  quickContacts?: QuickContact[];
}

export type ActiveTab = 'home' | 'chat' | 'voice' | 'profile';

export interface PromptSuggestion {
  id: string;
  category: string;
  title: string;
  prompt: string;
  iconName: string;
}
