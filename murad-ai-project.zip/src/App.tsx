import React, { useState, useEffect, useCallback } from 'react';
import { BellRing, X } from 'lucide-react';
import { ActiveTab, AlarmItem, AssistantAction, ChatMessage, UserProfile } from './types';
import {
  loadStoredAlarms,
  loadStoredMessages,
  loadStoredProfile,
  saveStoredAlarms,
  saveStoredMessages,
  saveStoredProfile,
} from './utils/storage';
import {
  createAlarmFromAction,
  launchExternalUri,
  playAssistantTone,
  resolveAppLink,
  resolveContactPhone,
} from './utils/assistantActions';
import { useBengaliVoice } from './hooks/useBengaliVoice';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeScreen } from './components/HomeScreen';
import { ChatScreen } from './components/ChatScreen';
import { VoiceScreen } from './components/VoiceScreen';
import { ProfileScreen } from './components/ProfileScreen';

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const getInitialTab = (): ActiveTab => {
  if (typeof window !== 'undefined') {
    const tabParam = new URLSearchParams(window.location.search).get('tab');
    if (tabParam === 'home' || tabParam === 'chat' || tabParam === 'voice' || tabParam === 'profile') {
      return tabParam;
    }
  }
  return 'home';
};

export interface SendMessageResult {
  reply: string;
  action?: AssistantAction;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>(getInitialTab);
  const [messages, setMessages] = useState<ChatMessage[]>(() => loadStoredMessages());
  const [profile, setProfile] = useState<UserProfile>(() => loadStoredProfile());
  const [alarms, setAlarms] = useState<AlarmItem[]>(() => loadStoredAlarms());
  const [ringingAlarm, setRingingAlarm] = useState<AlarmItem | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const isOnline = useOnlineStatus();

  // Bengali Voice Synthesizer Hook
  const { speak, stopSpeaking, unlockAudio, isSpeaking, isLoadingAudio, activeMessageId } =
    useBengaliVoice(profile.voiceSpeed, profile.voicePitch);

  // Sync state to local storage
  useEffect(() => {
    saveStoredMessages(messages);
  }, [messages]);

  useEffect(() => {
    saveStoredProfile(profile);
  }, [profile]);

  useEffect(() => {
    saveStoredAlarms(alarms);
  }, [alarms]);

  // Monitor active in-app alarms & timers (runs only when at least 1 alarm is active)
  useEffect(() => {
    const hasActive = alarms.some((a) => a.active);
    if (!hasActive) return;

    const interval = window.setInterval(() => {
      const now = Date.now();
      const due = alarms.find((a) => a.active && now >= a.triggerAt);
      if (due) {
        setAlarms((prev) =>
          prev.map((item) => (item.id === due.id ? { ...item, active: false } : item))
        );
        setRingingAlarm(due);
        playAssistantTone('alarm');
        speak(
          `আসসালামু আলাইকুম, মুরাদ ভাই! আপনার ${due.label}-এর সময় হয়ে গেছে।`
        );
      }
    }, 1000);

    return () => window.clearInterval(interval);
  }, [alarms, speak]);

  // Format current time in Bengali numerals (e.g. ১২:৪৫ অপরাহ্ন)
  const getBengaliTime = () => {
    try {
      return new Date().toLocaleTimeString('bn-BD', {
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch (_) {
      return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
  };

  const getToneDescription = (tone: UserProfile['aiTone']) => {
    switch (tone) {
      case 'friendly':
        return 'বন্ধুভাবাপন্ন, অত্যন্ত মধুর, আন্তরিক ও উৎসাহব্যঞ্জক';
      case 'formal':
        return 'প্রাতিষ্ঠানিক, গম্ভীর, সুবিবেচক ও প্রজ্ঞাবান';
      case 'academic':
        return 'শিক্ষক ও নির্দেশকসুলভ, বিস্তারিত ব্যাখ্যামূলক ও তথ্যসমৃদ্ধ';
      case 'creative':
        return 'সৃজনশীল, কাব্যিক ও চিন্তাশীল';
      default:
        return 'বন্ধুভাবাপন্ন ও প্রজ্ঞাবান সহায়ক';
    }
  };

  const fetchChatReplyWithRetry = useCallback(
    async (
      historyForApi: Array<{ role: 'user' | 'assistant'; content: string }>,
      isVoiceMode: boolean
    ): Promise<SendMessageResult> => {
      const maxClientAttempts = 2;
      let lastError: Error | null = null;

      for (let attempt = 1; attempt <= maxClientAttempts; attempt++) {
        const controller = new AbortController();
        const timeoutId = window.setTimeout(() => controller.abort(), 30000);

        try {
          const res = await fetch('/api/chat', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            signal: controller.signal,
            body: JSON.stringify({
              messages: historyForApi,
              userProfile: profile,
              isVoiceMode,
              isAssistantMode: true,
              customTone: getToneDescription(profile.aiTone),
            }),
          });

          window.clearTimeout(timeoutId);

          if (!res.ok) {
            const errData = await res.json().catch(() => ({}));
            const errorMsg =
              errData.error ||
              (res.status === 503
                ? 'এআই সার্ভারে বর্তমানে অতিরিক্ত চাপ রয়েছে (Error 503)। অনুগ্রহ করে আবার চেষ্টা করুন।'
                : 'সার্ভার থেকে উত্তর পাওয়া যায়নি।');

            const isTransient = [408, 429, 500, 502, 503, 504].includes(res.status);
            if (isTransient && attempt < maxClientAttempts) {
              await wait(900);
              continue;
            }
            throw new Error(errorMsg);
          }

          const data = await res.json();
          const replyText = data.reply?.trim();
          if (!replyText) {
            throw new Error('জেমিনি এআই থেকে কোনো উত্তর পাওয়া যায়নি।');
          }

          let parsedAction: AssistantAction | undefined = data.action;
          if (parsedAction && (parsedAction.type === 'make_call' || parsedAction.type === 'send_sms')) {
            const resolved = resolveContactPhone(parsedAction.phone, profile.quickContacts);
            if (resolved.phone) {
              parsedAction = {
                ...parsedAction,
                phone: resolved.phone,
                label: resolved.contactName || parsedAction.phone,
              };
            }
          }

          return { reply: replyText, action: parsedAction };
        } catch (err: any) {
          window.clearTimeout(timeoutId);
          if (err?.name === 'AbortError') {
            lastError = new Error('উত্তর আসতে বেশি সময় লাগছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
          } else {
            lastError = err instanceof Error ? err : new Error('ইন্টারনেট সংযোগ চেক করুন।');
          }

          if (attempt < maxClientAttempts) {
            await wait(800);
            continue;
          }
        }
      }

      throw lastError || new Error('সার্ভারের সাথে সংযোগ স্থাপন করা যায়নি।');
    },
    [profile]
  );

  const handleClearChat = useCallback(() => {
    stopSpeaking();
    setMessages([]);
    saveStoredMessages([]);
  }, [stopSpeaking]);

  const handleDeleteAlarm = useCallback((alarmId: string) => {
    setAlarms((prev) => prev.filter((a) => a.id !== alarmId));
  }, []);

  // Execute a confirmed Assistant Action safely
  const executeAssistantAction = useCallback(
    (action: AssistantAction): { executed: boolean; feedback: string } => {
      switch (action.type) {
        case 'open_website':
        case 'search_web': {
          if (action.url) {
            launchExternalUri(action.url, false);
            return {
              executed: true,
              feedback: 'মুরাদ ভাই, নির্ধারিত ওয়েবসাইটটি খোলা হয়েছে।',
            };
          }
          return {
            executed: false,
            feedback: 'দুঃখিত মুরাদ ভাই, সঠিক ওয়েবসাইট ঠিকানা পাওয়া যায়নি।',
          };
        }

        case 'open_app': {
          const appInfo = resolveAppLink(action.appName);
          if (appInfo.supportedOnWeb && appInfo.url) {
            launchExternalUri(appInfo.url, appInfo.isAndroidIntent);
            return {
              executed: true,
              feedback: `মুরাদ ভাই, ${appInfo.displayName} খোলার অনুরোধ পাঠানো হয়েছে।`,
            };
          }
          return {
            executed: false,
            feedback: `মুরাদ ভাই, নিরাপত্তার কারণে ব্রাউজার সরাসরি "${appInfo.displayName}" সিস্টেম অ্যাপ খুলতে পারে না। এর জন্য Native Android App (APK) প্রয়োজন।`,
          };
        }

        case 'make_call': {
          const resolved = resolveContactPhone(action.phone, profile.quickContacts);
          if (resolved.phone) {
            launchExternalUri(`tel:${resolved.phone}`, true);
            return {
              executed: true,
              feedback: `মুরাদ ভাই, ${resolved.contactName || resolved.phone} নম্বরে কল করার জন্য ফোনের ডায়ালার খোলা হয়েছে।`,
            };
          }
          return {
            executed: false,
            feedback:
              'মুরাদ ভাই, কল করার জন্য সঠিক ফোন নম্বর পাওয়া যায়নি। দয়া করে নম্বরটি বলুন অথবা প্রোফাইলে দ্রুত কন্টাক্টে সেভ করুন।',
          };
        }

        case 'send_sms': {
          const resolved = resolveContactPhone(action.phone, profile.quickContacts);
          if (resolved.phone) {
            const body = encodeURIComponent(action.smsBody || '');
            launchExternalUri(`sms:${resolved.phone}?body=${body}`, true);
            return {
              executed: true,
              feedback: `মুরাদ ভাই, ${resolved.contactName || resolved.phone} নম্বরে SMS পাঠানোর জন্য মেসেজ অ্যাপ খোলা হয়েছে।`,
            };
          }
          return {
            executed: false,
            feedback:
              'মুরাদ ভাই, SMS পাঠানোর জন্য প্রাপকের ফোন নম্বর প্রয়োজন। দয়া করে নম্বরটি বলুন বা প্রোফাইলে সেভ করুন।',
          };
        }

        case 'clear_chat': {
          handleClearChat();
          return {
            executed: true,
            feedback: 'মুরাদ ভাই, আপনার অনুমতি অনুযায়ী সব চ্যাট হিস্ট্রি মুছে ফেলা হয়েছে।',
          };
        }

        case 'delete_alarms': {
          setAlarms([]);
          return {
            executed: true,
            feedback: 'মুরাদ ভাই, আপনার অনুমতি অনুযায়ী সব অ্যালার্ম ও টাইমার মুছে ফেলা হয়েছে।',
          };
        }

        default:
          return { executed: false, feedback: '' };
      }
    },
    [handleClearChat, profile.quickContacts]
  );

  // Send message to server-side Gemini API
  const handleSendMessage = useCallback(
    async (
      text: string,
      isVoicePrompt = false,
      onSpeakComplete?: () => void
    ): Promise<SendMessageResult | void> => {
      const trimmed = text.trim();
      if (!trimmed || isLoading) return;

      const userMsg: ChatMessage = {
        id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        role: 'user',
        content: trimmed,
        timestamp: getBengaliTime(),
        isVoicePrompt,
      };

      const validExisting = messages.filter((m) => !m.isError);
      const newHistory = [...validExisting, userMsg];

      setMessages((prev) => [...prev.filter((m) => !m.isError), userMsg]);
      setIsLoading(true);

      try {
        const result = await fetchChatReplyWithRetry(
          newHistory.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          isVoicePrompt || activeTab === 'voice'
        );

        let finalAction = result.action;
        if (finalAction && (finalAction.type === 'set_alarm' || finalAction.type === 'set_timer')) {
          const newAlarm = createAlarmFromAction(finalAction);
          if (newAlarm) {
            setAlarms((prev) => [newAlarm, ...prev].slice(0, 12));
          }
        }

        const assistantMsg: ChatMessage = {
          id: `ai-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          role: 'assistant',
          content: result.reply,
          timestamp: getBengaliTime(),
          action: finalAction && finalAction.type !== 'none' ? finalAction : undefined,
        };

        setMessages((prev) => [...prev, assistantMsg]);

        if (activeTab === 'voice' || profile.autoSpeakVoice || isVoicePrompt) {
          speak(result.reply, assistantMsg.id, onSpeakComplete);
        } else {
          onSpeakComplete?.();
        }

        return { reply: result.reply, action: finalAction };
      } catch (error: any) {
        console.error('Chat error:', error);
        const friendlyMsg = error?.message || 'ইন্টারনেট সংযোগ চেক করুন।';
        const errorMsg: ChatMessage = {
          id: `error-${Date.now()}`,
          role: 'assistant',
          content: `দুঃখিত, উত্তর পাওয়া যায়নি: ${friendlyMsg}`,
          timestamp: getBengaliTime(),
          isError: true,
          retryText: trimmed,
          isVoicePrompt,
        };
        setMessages((prev) => [...prev, errorMsg]);
        if (isVoicePrompt) {
          throw error;
        }
      } finally {
        setIsLoading(false);
      }
    },
    [messages, isLoading, profile.autoSpeakVoice, activeTab, speak, fetchChatReplyWithRetry]
  );

  // Retry failed message without duplicating the user's message bubble
  const handleRetryMessage = useCallback(
    async (errorMessageId: string, retryText: string, isVoicePrompt = false) => {
      if (isLoading || !retryText.trim()) return;

      const cleanHistory = messages.filter((m) => m.id !== errorMessageId && !m.isError);
      const lastMsg = cleanHistory[cleanHistory.length - 1];
      const historyToUse =
        lastMsg && lastMsg.role === 'user' && lastMsg.content === retryText.trim()
          ? cleanHistory
          : [
              ...cleanHistory,
              {
                id: `user-${Date.now()}`,
                role: 'user' as const,
                content: retryText.trim(),
                timestamp: getBengaliTime(),
                isVoicePrompt,
              },
            ];

      setMessages(historyToUse);
      setIsLoading(true);

      try {
        const result = await fetchChatReplyWithRetry(
          historyToUse.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          isVoicePrompt || activeTab === 'voice'
        );

        if (result.action && (result.action.type === 'set_alarm' || result.action.type === 'set_timer')) {
          const newAlarm = createAlarmFromAction(result.action);
          if (newAlarm) {
            setAlarms((prev) => [newAlarm, ...prev].slice(0, 12));
          }
        }

        const assistantMsg: ChatMessage = {
          id: `ai-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          role: 'assistant',
          content: result.reply,
          timestamp: getBengaliTime(),
          action: result.action && result.action.type !== 'none' ? result.action : undefined,
        };

        setMessages((prev) => [...prev, assistantMsg]);

        if (activeTab === 'voice' || profile.autoSpeakVoice || isVoicePrompt) {
          speak(result.reply, assistantMsg.id);
        }
      } catch (error: any) {
        const friendlyMsg = error?.message || 'ইন্টারনেট সংযোগ চেক করুন।';
        const errorMsg: ChatMessage = {
          id: `error-${Date.now()}`,
          role: 'assistant',
          content: `দুঃখিত, উত্তর পাওয়া যায়নি: ${friendlyMsg}`,
          timestamp: getBengaliTime(),
          isError: true,
          retryText: retryText.trim(),
          isVoicePrompt,
        };
        setMessages((prev) => [...prev, errorMsg]);
      } finally {
        setIsLoading(false);
      }
    },
    [messages, isLoading, profile.autoSpeakVoice, activeTab, speak, fetchChatReplyWithRetry]
  );

  const handleUpdateProfile = useCallback((updated: UserProfile) => {
    setProfile(updated);
    saveStoredProfile(updated);
  }, []);

  const handleTestVoice = useCallback(() => {
    unlockAudio();
    speak('আসসালামু আলাইকুম, মুরাদ ভাই! আমি Murad AI। আপনার বাংলা পুরুষ ভয়েস সহকারী সম্পূর্ণ প্রস্তুত।');
  }, [speak, unlockAudio]);

  return (
    <div className="min-h-screen bg-[#080415] text-[#f1f3f9] flex flex-col antialiased">
      {/* Brand Header */}
      <Header />

      {/* Active Ringing Alarm Banner */}
      {ringingAlarm && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-md rounded-2xl bg-gradient-to-r from-indigo-950 via-purple-950 to-rose-950 border border-rose-400/70 p-3.5 shadow-2xl flex items-center justify-between gap-3 animate-pulse">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-2 rounded-xl bg-rose-500/20 text-rose-300 shrink-0">
              <BellRing className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white truncate">
                অ্যালার্ম: {ringingAlarm.label}
              </p>
              <p className="text-[11px] text-rose-200">সময়: {ringingAlarm.timeDisplay}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              stopSpeaking();
              setRingingAlarm(null);
            }}
            className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1 shrink-0"
          >
            <X className="w-3.5 h-3.5" />
            <span>বন্ধ করুন</span>
          </button>
        </div>
      )}

      {/* Main Content Body */}
      <main className="flex-1 flex flex-col relative w-full overflow-hidden">
        {activeTab === 'home' && (
          <HomeScreen
            profile={profile}
            recentMessages={messages.filter((m) => !m.isError)}
            onStartVoice={() => {
              unlockAudio();
              stopSpeaking();
              setActiveTab('voice');
            }}
            onStartChat={(prompt) => {
              unlockAudio();
              setActiveTab('chat');
              if (prompt) {
                setTimeout(() => handleSendMessage(prompt), 100);
              }
            }}
            onChangeTab={setActiveTab}
          />
        )}

        {activeTab === 'chat' && (
          <ChatScreen
            messages={messages}
            isLoading={isLoading}
            onSendMessage={handleSendMessage}
            onRetryMessage={handleRetryMessage}
            onClearChat={handleClearChat}
            onExecuteAction={executeAssistantAction}
            profile={profile}
            speak={speak}
            stopSpeaking={stopSpeaking}
            unlockAudio={unlockAudio}
            isSpeaking={isSpeaking}
            activeSpeakingId={activeMessageId}
          />
        )}

        {activeTab === 'voice' && (
          <VoiceScreen
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            alarms={alarms}
            onDeleteAlarm={handleDeleteAlarm}
            isSpeaking={isSpeaking}
            isLoadingAudio={isLoadingAudio}
            speak={speak}
            stopSpeaking={stopSpeaking}
            unlockAudio={unlockAudio}
            onSendVoiceMessage={(txt, onSpeakComplete) =>
              handleSendMessage(txt, true, onSpeakComplete)
            }
            onExecuteAction={executeAssistantAction}
            onSwitchToChat={() => setActiveTab('chat')}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileScreen
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            onClearHistory={handleClearChat}
            onTestVoice={handleTestVoice}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={(tab) => {
          stopSpeaking();
          setActiveTab(tab);
        }}
        profile={profile}
      />

      {/* Non-intrusive Bengali Offline Banner */}
      {!isOnline && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 rounded-full bg-amber-500/95 px-3.5 py-1.5 text-[11px] font-medium text-slate-950 shadow-lg backdrop-blur-sm">
          <span className="h-2 w-2 rounded-full bg-slate-950 animate-pulse" />
          <span>অফলাইন মোড — সংরক্ষিত চ্যাট ও প্রোফাইল দেখানো হচ্ছে</span>
        </div>
      )}
    </div>
  );
}
