import { AlarmItem, AssistantAction, QuickContact } from '../types';

const BENGALI_TO_ENG_DIGITS: Record<string, string> = {
  '০': '0',
  '১': '1',
  '২': '2',
  '৩': '3',
  '৪': '4',
  '৫': '5',
  '৬': '6',
  '৭': '7',
  '৮': '8',
  '৯': '9',
};

export function toEnglishDigits(input: string): string {
  return input.replace(/[০-৯]/g, (ch) => BENGALI_TO_ENG_DIGITS[ch] ?? ch);
}

export function normalizePhoneNumber(raw?: string): string {
  if (!raw) return '';
  const eng = toEnglishDigits(raw);
  const cleaned = eng.replace(/[^\d+]/g, '');
  return cleaned.length >= 3 ? cleaned : '';
}

export function resolveContactPhone(
  queryOrPhone: string | undefined,
  contacts: QuickContact[] = []
): { phone: string; contactName?: string } {
  const direct = normalizePhoneNumber(queryOrPhone);
  if (direct.length >= 5) {
    return { phone: direct };
  }
  const needle = (queryOrPhone || '').trim().toLowerCase();
  if (!needle || contacts.length === 0) {
    return { phone: direct };
  }
  const matched = contacts.find(
    (c) =>
      c.name.trim().toLowerCase() === needle ||
      needle.includes(c.name.trim().toLowerCase()) ||
      c.name.trim().toLowerCase().includes(needle)
  );
  if (matched) {
    return {
      phone: normalizePhoneNumber(matched.phone),
      contactName: matched.name,
    };
  }
  return { phone: direct };
}

/**
 * Matches solo "Murad" wake word (English & Bengali ASR phonetic variants).
 * No "Hey" prefix required. Returns { matched, command, wakeOnly }.
 */
export function parseWakeWord(rawText: string): {
  matched: boolean;
  command: string;
  wakeOnly: boolean;
} {
  const text = rawText.trim();
  if (!text) {
    return { matched: false, command: '', wakeOnly: false };
  }

  const wakePatterns = [
    /^(?:murad|murat|morad|muradh)(?:\s+ai|\s+bhai|\s+ভাই)?[\s,।:!?-]*(.*)$/i,
    /^(?:মুরাদ|মোরাদ|মুড়াদ|মুড়াদ|মুরাত)(?:\s+এআই|\s+ai|\s+ভাই)?[\s,।:!?-]*(.*)$/i,
    /^(?:হে|হেই|হাই|হ্যালো|এই|ও|ওহে|শোনো|শুনুন|ওকে|hey|hay|hi|ok|okay)\s+(?:মুরাদ|মোরাদ|murad|murat|morad)(?:\s+এআই|\s+ai|\s+ভাই)?[\s,।:!?-]*(.*)$/i,
  ];

  for (const pattern of wakePatterns) {
    const match = text.match(pattern);
    if (match) {
      const rest = (match[1] || '').trim();
      return {
        matched: true,
        command: rest,
        wakeOnly: rest.length === 0,
      };
    }
  }

  // Also catch standalone "Murad" / "মুরাদ" if ASR picked up a short prefix noise word before it
  const midRegex =
    /(?:\bmurad\b|\bmurat\b|\bmorad\b|মুরাদ|মোরাদ|মুড়াদ|মুড়াদ)[\s,।:!?-]*(.*)$/i;
  const midMatch = text.match(midRegex);
  if (midMatch && text.split(/\s+/).length <= 4) {
    const rest = (midMatch[1] || '').trim();
    return {
      matched: true,
      command: rest,
      wakeOnly: rest.length === 0,
    };
  }

  return { matched: false, command: text, wakeOnly: false };
}

/**
 * Parses verbal Yes / No for pending permission confirmations.
 */
export function parseVoiceConfirmation(rawText: string): 'confirm' | 'cancel' | 'other' {
  const t = rawText.trim().toLowerCase().replace(/[।,!?.]/g, '');
  if (!t) return 'other';

  const confirmWords = [
    'হ্যাঁ',
    'হাঁ',
    'হ্যা',
    'জি',
    'জ্বি',
    'ঠিক আছে',
    'অবশ্যই',
    'করো',
    'করুন',
    'দাও',
    'দিন',
    'পাঠাও',
    'পাঠান',
    'খোলো',
    'খুলুন',
    'মুছো',
    'মুছে ফেলো',
    'অনুমতি দিলাম',
    'সম্মতি',
    'yes',
    'ok',
    'okay',
    'confirm',
    'sure',
    'go ahead',
    'allow',
  ];

  const cancelWords = [
    'না',
    'নাহ',
    'বাতিল',
    'থাক',
    'দরকার নেই',
    'লাগবে না',
    'বন্ধ করো',
    'ক্যানসেল',
    'no',
    'nope',
    'cancel',
    'stop',
    'abort',
  ];

  if (cancelWords.some((w) => t === w || t.startsWith(`${w} `) || t.endsWith(` ${w}`))) {
    return 'cancel';
  }
  if (confirmWords.some((w) => t === w || t.startsWith(`${w} `) || t.includes(w))) {
    return 'confirm';
  }
  return 'other';
}

export function isAndroidDevice(): boolean {
  if (typeof navigator === 'undefined') return false;
  return /android/i.test(navigator.userAgent);
}

/**
 * Resolves a friendly app name to an Android deep link / web fallback URL.
 */
export function resolveAppLink(appNameRaw?: string): {
  url: string;
  isAndroidIntent: boolean;
  displayName: string;
  supportedOnWeb: boolean;
} {
  const name = (appNameRaw || '').trim().toLowerCase();
  const android = isAndroidDevice();

  const knownApps: Array<{
    keys: string[];
    displayName: string;
    androidIntent: string;
    webUrl: string;
  }> = [
    {
      keys: ['youtube', 'ইউটিউব'],
      displayName: 'YouTube',
      androidIntent:
        'intent://www.youtube.com/#Intent;scheme=https;package=com.google.android.youtube;S.browser_fallback_url=https%3A%2F%2Fm.youtube.com;end',
      webUrl: 'https://m.youtube.com',
    },
    {
      keys: ['whatsapp', 'হোয়াটসঅ্যাপ', 'হোয়াটসঅ্যাপ'],
      displayName: 'WhatsApp',
      androidIntent:
        'intent://send/#Intent;scheme=whatsapp;package=com.whatsapp;S.browser_fallback_url=https%3A%2F%2Fweb.whatsapp.com;end',
      webUrl: 'https://wa.me/',
    },
    {
      keys: ['facebook', 'ফেসবুক', 'fb'],
      displayName: 'Facebook',
      androidIntent:
        'intent://facewebmodal/f?href=https://m.facebook.com/#Intent;scheme=fb;package=com.facebook.katana;S.browser_fallback_url=https%3A%2F%2Fm.facebook.com;end',
      webUrl: 'https://m.facebook.com',
    },
    {
      keys: ['maps', 'google maps', 'ম্যাপ', 'ম্যাপস', 'গুগল ম্যাপ'],
      displayName: 'Google Maps',
      androidIntent:
        'intent://maps.google.com/#Intent;scheme=https;package=com.google.android.apps.maps;S.browser_fallback_url=https%3A%2F%2Fmaps.google.com;end',
      webUrl: 'https://maps.google.com',
    },
    {
      keys: ['gmail', 'জিমেইল', 'ইমেইল', 'মেইল'],
      displayName: 'Gmail',
      androidIntent: 'mailto:',
      webUrl: 'https://mail.google.com',
    },
    {
      keys: ['instagram', 'ইনস্টাগ্রাম'],
      displayName: 'Instagram',
      androidIntent:
        'intent://instagram.com/#Intent;scheme=https;package=com.instagram.android;S.browser_fallback_url=https%3A%2F%2Fwww.instagram.com;end',
      webUrl: 'https://www.instagram.com',
    },
    {
      keys: ['play store', 'প্লে স্টোর', 'playstore'],
      displayName: 'Google Play Store',
      androidIntent: 'https://play.google.com/store',
      webUrl: 'https://play.google.com/store',
    },
    {
      keys: ['google', 'গুগল', 'chrome', 'ক্রোম'],
      displayName: 'Google',
      androidIntent: 'https://www.google.com',
      webUrl: 'https://www.google.com',
    },
  ];

  const found = knownApps.find((app) => app.keys.some((k) => name.includes(k)));
  if (found) {
    return {
      url: android ? found.androidIntent : found.webUrl,
      isAndroidIntent: android && found.androidIntent.startsWith('intent://'),
      displayName: found.displayName,
      supportedOnWeb: true,
    };
  }

  return {
    url: '',
    isAndroidIntent: false,
    displayName: appNameRaw || 'অ্যাপ',
    supportedOnWeb: false,
  };
}

/**
 * Triggers a URL or Android URI safely without window.open or window.alert.
 */
export function launchExternalUri(url: string, sameTab = false): boolean {
  if (!url || typeof document === 'undefined') return false;
  try {
    if (
      sameTab ||
      url.startsWith('tel:') ||
      url.startsWith('sms:') ||
      url.startsWith('mailto:') ||
      url.startsWith('intent://')
    ) {
      window.location.href = url;
      return true;
    }

    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    window.setTimeout(() => {
      try {
        document.body.removeChild(a);
      } catch (_) {}
    }, 150);
    return true;
  } catch (err) {
    console.error('URI launch failed:', err);
    return false;
  }
}

/**
 * Builds an AlarmItem from an AssistantAction (alarmTime HH:mm or timerSeconds).
 */
export function createAlarmFromAction(action: AssistantAction): AlarmItem | null {
  const now = Date.now();

  if (action.type === 'set_timer' && action.timerSeconds && action.timerSeconds > 0) {
    const secs = Math.min(86400, Math.max(5, Math.round(action.timerSeconds)));
    const triggerAt = now + secs * 1000;
    const mins = Math.floor(secs / 60);
    const remSecs = secs % 60;
    const label =
      action.alarmLabel ||
      (mins > 0
        ? `${mins} মিনিট${remSecs > 0 ? ` ${remSecs} সেকেন্ড` : ''} টাইমার`
        : `${remSecs} সেকেন্ড টাইমার`);
    const timeDisplay = new Date(triggerAt).toLocaleTimeString('bn-BD', {
      hour: '2-digit',
      minute: '2-digit',
    });

    return {
      id: `timer-${now}`,
      label,
      timeDisplay,
      type: 'timer',
      triggerAt,
      active: true,
    };
  }

  if (action.type === 'set_alarm' && action.alarmTime) {
    const normalized = toEnglishDigits(action.alarmTime).trim();
    const match = normalized.match(/^(\d{1,2}):(\d{2})$/);
    if (!match) return null;

    const hours = Math.min(23, Math.max(0, parseInt(match[1], 10)));
    const minutes = Math.min(59, Math.max(0, parseInt(match[2], 10)));

    const target = new Date();
    target.setHours(hours, minutes, 0, 0);
    if (target.getTime() <= now) {
      target.setDate(target.getDate() + 1);
    }

    const timeDisplay = target.toLocaleTimeString('bn-BD', {
      hour: '2-digit',
      minute: '2-digit',
    });

    return {
      id: `alarm-${now}`,
      label: action.alarmLabel || 'নির্ধারিত অ্যালার্ম',
      timeDisplay,
      type: 'alarm',
      triggerAt: target.getTime(),
      active: true,
    };
  }

  return null;
}

/**
 * Plays a crisp, low-memory Web Audio API tone for wake word activation or alarm chime.
 */
export function playAssistantTone(kind: 'wake' | 'confirm' | 'alarm'): void {
  if (typeof window === 'undefined') return;
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    const playNote = (freq: number, startOffset: number, duration: number, vol = 0.12) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = kind === 'alarm' ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(freq, now + startOffset);
      gain.gain.setValueAtTime(0.001, now + startOffset);
      gain.gain.exponentialRampToValueAtTime(vol, now + startOffset + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + startOffset + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + startOffset);
      osc.stop(now + startOffset + duration + 0.02);
    };

    if (kind === 'wake') {
      playNote(587.33, 0, 0.11, 0.09);
      playNote(880, 0.09, 0.14, 0.1);
    } else if (kind === 'confirm') {
      playNote(659.25, 0, 0.1, 0.08);
    } else {
      playNote(783.99, 0, 0.2, 0.18);
      playNote(987.77, 0.22, 0.2, 0.18);
      playNote(1174.66, 0.44, 0.28, 0.2);
    }

    window.setTimeout(() => {
      ctx.close().catch(() => {});
    }, 1200);
  } catch (_) {}
}
