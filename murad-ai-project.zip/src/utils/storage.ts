import { AlarmItem, ChatMessage, UserProfile } from '../types';

const STORAGE_KEY_MESSAGES = 'murad_ai_messages_v1';
const STORAGE_KEY_PROFILE = 'murad_ai_profile_v1';
const STORAGE_KEY_ALARMS = 'murad_ai_alarms_v1';

export const DEFAULT_PROFILE: UserProfile = {
  name: 'মোঃ মুরাদ সিদ্দিকী',
  bio: 'উদ্যোক্তা ও প্রযুক্তিপ্রেমী',
  avatarUrl: '',
  voiceSpeed: 1.0,
  voicePitch: 0.88,
  autoSpeakVoice: true,
  aiTone: 'friendly',
  joinedDate: 'নভেম্বর ২০২৪',
  wakeWordEnabled: true,
  alwaysReadyVoice: true,
  quickContacts: [],
};

export function loadStoredProfile(): UserProfile {
  if (typeof window === 'undefined') return DEFAULT_PROFILE;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PROFILE);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...DEFAULT_PROFILE,
        ...parsed,
        quickContacts: Array.isArray(parsed.quickContacts) ? parsed.quickContacts : [],
      };
    }
  } catch (e) {
    console.error('Failed to load profile:', e);
  }
  return DEFAULT_PROFILE;
}

export function saveStoredProfile(profile: UserProfile): boolean {
  if (typeof window === 'undefined') return false;
  try {
    localStorage.setItem(STORAGE_KEY_PROFILE, JSON.stringify(profile));
    return true;
  } catch (e) {
    // Free space from old chat messages if quota exceeded on mobile browser
    try {
      const existing = loadStoredMessages();
      localStorage.setItem(STORAGE_KEY_MESSAGES, JSON.stringify(existing.slice(-15)));
      localStorage.setItem(STORAGE_KEY_PROFILE, JSON.stringify(profile));
      return true;
    } catch (innerErr) {
      console.error('Failed to save profile:', innerErr);
      return false;
    }
  }
}

export function loadStoredMessages(): ChatMessage[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY_MESSAGES);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.slice(-50); // Keep max 50 for OPPO A18 speed
      }
    }
  } catch (e) {
    console.error('Failed to load messages:', e);
  }
  return [];
}

export function saveStoredMessages(messages: ChatMessage[]): void {
  if (typeof window === 'undefined') return;
  try {
    // Only keep last 50 messages to preserve memory on 4GB RAM devices
    const trimmed = messages.slice(-50);
    localStorage.setItem(STORAGE_KEY_MESSAGES, JSON.stringify(trimmed));
  } catch (e) {
    console.error('Failed to save messages:', e);
  }
}

export function loadStoredAlarms(): AlarmItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ALARMS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.slice(0, 12);
      }
    }
  } catch (e) {
    console.error('Failed to load alarms:', e);
  }
  return [];
}

export function saveStoredAlarms(alarms: AlarmItem[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_ALARMS, JSON.stringify(alarms.slice(0, 12)));
  } catch (e) {
    console.error('Failed to save alarms:', e);
  }
}

/**
 * Center-crops and resizes an uploaded photo to 280x280 JPEG using ObjectURL
 * so OPPO A18 (4GB RAM) handles high-res camera/gallery photos with minimal memory.
 */
export async function compressAvatarImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const objectUrl = URL.createObjectURL(file);
    const img = new Image();

    img.onload = () => {
      try {
        const targetSize = 280;
        const canvas = document.createElement('canvas');
        canvas.width = targetSize;
        canvas.height = targetSize;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          URL.revokeObjectURL(objectUrl);
          reject(new Error('ক্যানভাস তৈরি করা যায়নি'));
          return;
        }

        // Center square crop for crisp circular profile photo
        const minSide = Math.min(img.width, img.height);
        const sx = Math.floor((img.width - minSide) / 2);
        const sy = Math.floor((img.height - minSide) / 2);

        ctx.drawImage(img, sx, sy, minSide, minSide, 0, 0, targetSize, targetSize);

        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.8);
        URL.revokeObjectURL(objectUrl);
        resolve(compressedBase64);
      } catch (err) {
        URL.revokeObjectURL(objectUrl);
        reject(err);
      }
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('ছবিটি লোড করা সম্ভব হয়নি। অনুগ্রহ করে JPG বা PNG ছবি দিন।'));
    };

    img.src = objectUrl;
  });
}
