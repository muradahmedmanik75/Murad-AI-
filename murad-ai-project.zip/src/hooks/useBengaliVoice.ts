import { useState, useEffect, useRef, useCallback } from 'react';

interface CachedAudio {
  key: string;
  url: string;
}

export function useBengaliVoice(speed: number = 1.0, pitch: number = 1.0) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [activeMessageId, setActiveMessageId] = useState<string | null>(null);
  const [isSupported, setIsSupported] = useState(true);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  const synthRef = useRef<SpeechSynthesis | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const audioCacheRef = useRef<CachedAudio[]>([]);
  const requestCounterRef = useRef(0);
  const serverTtsUnavailableRef = useRef(false);
  const speechTimerRef = useRef<number | null>(null);
  const keepAliveTimerRef = useRef<number | null>(null);
  const onEndedCallbackRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;

      const updateVoices = () => {
        const available = window.speechSynthesis.getVoices();
        setVoices(available);
      };

      updateVoices();
      window.speechSynthesis.onvoiceschanged = updateVoices;
    } else {
      setIsSupported(false);
    }

    return () => {
      if (speechTimerRef.current) {
        window.clearTimeout(speechTimerRef.current);
      }
      if (keepAliveTimerRef.current) {
        window.clearInterval(keepAliveTimerRef.current);
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
      }
      if (synthRef.current) {
        try {
          synthRef.current.cancel();
        } catch (_) {}
      }
      audioCacheRef.current.forEach((item) => URL.revokeObjectURL(item.url));
      audioCacheRef.current = [];
    };
  }, []);

  const cleanTextForSpeech = (text: string): string => {
    return text
      .replace(/```[\s\S]*?```/g, 'কোড অংশ বাদ দেওয়া হলো।')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/#{1,6}\s+/g, '')
      .replace(/[*_]{1,3}([^*_]+)[*_]{1,3}/g, '$1')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/[>#*~_•]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  };

  // Split long Bengali text into short sentence chunks so Android Chrome TTS never drops or clips
  const splitBengaliSentences = (text: string): string[] => {
    const rawParts = text
      .split(/(?<=[।!?.\n])\s+/)
      .map((p) => p.trim())
      .filter(Boolean);

    const chunks: string[] = [];
    for (const part of rawParts) {
      if (part.length <= 160) {
        chunks.push(part);
      } else {
        const subParts = part.split(/(?<=[,;:])\s+/);
        let buffer = '';
        for (const sub of subParts) {
          if ((buffer + ' ' + sub).trim().length <= 160) {
            buffer = (buffer + ' ' + sub).trim();
          } else {
            if (buffer) chunks.push(buffer);
            buffer = sub;
          }
        }
        if (buffer) chunks.push(buffer);
      }
    }
    return chunks.length > 0 ? chunks : [text];
  };

  // Must be called synchronously inside a user tap/click handler on Android Chrome
  // so async AI replies can speak immediately without autoplay blocking
  const unlockAudio = useCallback(() => {
    if (synthRef.current) {
      try {
        synthRef.current.resume();
        if (!synthRef.current.speaking) {
          const primer = new SpeechSynthesisUtterance(' ');
          primer.volume = 0;
          primer.rate = 2;
          primer.lang = 'bn-BD';
          synthRef.current.speak(primer);
        }
      } catch (_) {}
    }
  }, []);

  const clearKeepAlive = () => {
    if (keepAliveTimerRef.current) {
      window.clearInterval(keepAliveTimerRef.current);
      keepAliveTimerRef.current = null;
    }
  };

  const stopSpeaking = useCallback(() => {
    requestCounterRef.current += 1;
    onEndedCallbackRef.current = null;
    clearKeepAlive();

    if (speechTimerRef.current) {
      window.clearTimeout(speechTimerRef.current);
      speechTimerRef.current = null;
    }

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }

    if (audioRef.current) {
      try {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
        audioRef.current.onended = null;
        audioRef.current.onerror = null;
      } catch (_) {}
    }

    if (synthRef.current) {
      try {
        synthRef.current.cancel();
      } catch (_) {}
    }

    setIsLoadingAudio(false);
    setIsSpeaking(false);
    setActiveMessageId(null);
  }, []);

  const speakWithBrowserFallback = useCallback(
    (text: string, requestId: number, messageId?: string) => {
      if (!synthRef.current || !text) {
        setIsLoadingAudio(false);
        setIsSpeaking(false);
        setActiveMessageId(null);
        return;
      }

      const chunks = splitBengaliSentences(text);
      const allVoices = voices.length > 0 ? voices : synthRef.current.getVoices();
      const bengaliVoices = allVoices.filter(
        (v) =>
          v.lang.toLowerCase().includes('bn') ||
          v.name.toLowerCase().includes('bengali') ||
          v.name.toLowerCase().includes('bangla')
      );

      const scoreMaleBengaliVoice = (v: SpeechSynthesisVoice): number => {
        const lang = v.lang.toLowerCase();
        const name = `${v.name} ${v.voiceURI}`.toLowerCase();
        let score = 0;

        if (lang === 'bn-bd') score += 4;
        else if (lang === 'bn-in') score += 3;
        else score += 1;

        if (/(male|man|purush|pradeep|bashkar|tanmay|sajib|bdb|bnd|bng)/.test(name)) {
          score += 12;
        }
        if (/(female|woman|mohila|nabanita|tanishaa|kalpana|bda|bna)/.test(name)) {
          score -= 12;
        }
        return score;
      };

      const bengaliVoice =
        bengaliVoices.length > 0
          ? [...bengaliVoices].sort((a, b) => scoreMaleBengaliVoice(b) - scoreMaleBengaliVoice(a))[0]
          : undefined;

      let index = 0;
      let triedFallbackBnIn = false;

      // Prevent Chrome's 15-second pause bug during long speech
      clearKeepAlive();
      keepAliveTimerRef.current = window.setInterval(() => {
        if (synthRef.current && synthRef.current.speaking) {
          try {
            synthRef.current.resume();
          } catch (_) {}
        }
      }, 8000);

      const speakNextChunk = (overrideLang?: string) => {
        if (requestId !== requestCounterRef.current || !synthRef.current) {
          clearKeepAlive();
          return;
        }
        if (index >= chunks.length) {
          clearKeepAlive();
          setIsLoadingAudio(false);
          setIsSpeaking(false);
          setActiveMessageId(null);
          const doneCb = onEndedCallbackRef.current;
          onEndedCallbackRef.current = null;
          doneCb?.();
          return;
        }

        const utterance = new SpeechSynthesisUtterance(chunks[index]);
        utterance.rate = Math.min(2, Math.max(0.5, speed));
        // Use natural male vocal pitch baseline (0.88) when profile pitch is default 1.0
        const targetMalePitch = pitch >= 0.98 && pitch <= 1.02 ? 0.88 : pitch;
        utterance.pitch = Math.min(2, Math.max(0.5, targetMalePitch));

        if (!overrideLang && bengaliVoice) {
          utterance.voice = bengaliVoice;
          utterance.lang = bengaliVoice.lang;
        } else {
          utterance.lang = overrideLang || 'bn-BD';
        }

        utterance.onstart = () => {
          if (requestId !== requestCounterRef.current) return;
          setIsLoadingAudio(false);
          setIsSpeaking(true);
          if (messageId) setActiveMessageId(messageId);
        };

        utterance.onend = () => {
          if (requestId !== requestCounterRef.current) return;
          index += 1;
          speakNextChunk(overrideLang);
        };

        utterance.onerror = (ev: any) => {
          if (requestId !== requestCounterRef.current) return;
          const errType = ev?.error;
          if (!triedFallbackBnIn && (errType === 'language-unavailable' || errType === 'voice-unavailable')) {
            triedFallbackBnIn = true;
            speakNextChunk('bn-IN');
            return;
          }
          index += 1;
          if (index < chunks.length) {
            speakNextChunk(overrideLang);
          } else {
            clearKeepAlive();
            setIsLoadingAudio(false);
            setIsSpeaking(false);
            setActiveMessageId(null);
            const doneCb = onEndedCallbackRef.current;
            onEndedCallbackRef.current = null;
            doneCb?.();
          }
        };

        synthRef.current.speak(utterance);
      };

      // Android Chrome requires a brief delay after cancel() before speak()
      speechTimerRef.current = window.setTimeout(() => {
        speakNextChunk();
      }, 70);
    },
    [speed, pitch, voices]
  );

  const playAudioUrl = useCallback(
    (url: string, requestId: number, messageId?: string, fallbackText?: string) => {
      if (requestId !== requestCounterRef.current) return;

      if (!audioRef.current) {
        audioRef.current = new Audio();
      }

      const audio = audioRef.current;
      audio.src = url;
      audio.playbackRate = speed;

      audio.onplaying = () => {
        if (requestId !== requestCounterRef.current) return;
        setIsLoadingAudio(false);
        setIsSpeaking(true);
        if (messageId) setActiveMessageId(messageId);
      };

      audio.onended = () => {
        if (requestId !== requestCounterRef.current) return;
        setIsSpeaking(false);
        setActiveMessageId(null);
        const doneCb = onEndedCallbackRef.current;
        onEndedCallbackRef.current = null;
        doneCb?.();
      };

      audio.onerror = () => {
        if (requestId !== requestCounterRef.current) return;
        setIsLoadingAudio(false);
        if (fallbackText) {
          speakWithBrowserFallback(fallbackText, requestId, messageId);
        } else {
          setIsSpeaking(false);
          setActiveMessageId(null);
        }
      };

      audio.play().catch((err) => {
        console.warn('Audio playback prevented or failed, using fallback:', err);
        if (requestId !== requestCounterRef.current) return;
        setIsLoadingAudio(false);
        if (fallbackText) {
          speakWithBrowserFallback(fallbackText, requestId, messageId);
        } else {
          setIsSpeaking(false);
          setActiveMessageId(null);
        }
      });
    },
    [speed, speakWithBrowserFallback]
  );

  const speak = useCallback(
    async (
      rawText: string,
      messageId?: string,
      onEnded?: () => void,
      preferInstantBrowser = false
    ) => {
      if (!rawText) {
        onEnded?.();
        return;
      }

      stopSpeaking();
      onEndedCallbackRef.current = onEnded || null;
      const requestId = requestCounterRef.current;

      const text = cleanTextForSpeech(rawText);
      if (!text) {
        const doneCb = onEndedCallbackRef.current;
        onEndedCallbackRef.current = null;
        doneCb?.();
        return;
      }

      if (preferInstantBrowser || serverTtsUnavailableRef.current) {
        if (messageId) setActiveMessageId(messageId);
        speakWithBrowserFallback(text, requestId, messageId);
        return;
      }

      const cacheKey = text.slice(0, 900);
      const cached = audioCacheRef.current.find((c) => c.key === cacheKey);
      if (cached) {
        if (messageId) setActiveMessageId(messageId);
        playAudioUrl(cached.url, requestId, messageId, text);
        return;
      }

      setIsLoadingAudio(true);
      if (messageId) setActiveMessageId(messageId);

      const controller = new AbortController();
      abortControllerRef.current = controller;
      const timeoutId = window.setTimeout(() => controller.abort(), 4500);

      try {
        const res = await fetch('/api/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({ text: cacheKey }),
        });

        window.clearTimeout(timeoutId);

        if (requestId !== requestCounterRef.current) return;

        if (!res.ok) {
          throw new Error('TTS API error');
        }

        const data = await res.json();
        if (data.fallbackToBrowser || !data.audioBase64) {
          serverTtsUnavailableRef.current = true;
          setIsLoadingAudio(false);
          speakWithBrowserFallback(text, requestId, messageId);
          return;
        }

        const binaryString = window.atob(data.audioBase64);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        const blob = new Blob([bytes], { type: data.mimeType || 'audio/wav' });
        const blobUrl = URL.createObjectURL(blob);

        if (audioCacheRef.current.length >= 5) {
          const oldest = audioCacheRef.current.shift();
          if (oldest) URL.revokeObjectURL(oldest.url);
        }
        audioCacheRef.current.push({ key: cacheKey, url: blobUrl });

        playAudioUrl(blobUrl, requestId, messageId, text);
      } catch (err: any) {
        window.clearTimeout(timeoutId);
        if (requestId !== requestCounterRef.current) {
          setIsLoadingAudio(false);
          return;
        }
        setIsLoadingAudio(false);
        if (synthRef.current) {
          speakWithBrowserFallback(text, requestId, messageId);
        } else {
          setIsSupported(false);
          setIsSpeaking(false);
          setActiveMessageId(null);
          const doneCb = onEndedCallbackRef.current;
          onEndedCallbackRef.current = null;
          doneCb?.();
        }
      }
    },
    [stopSpeaking, playAudioUrl, speakWithBrowserFallback]
  );

  return {
    isSpeaking,
    isLoadingAudio,
    activeMessageId,
    isSupported,
    speak,
    stopSpeaking,
    unlockAudio,
  };
}
