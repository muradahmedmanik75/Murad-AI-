import { useState, useEffect, useRef, useCallback } from 'react';

interface IWindow extends Window {
  SpeechRecognition?: any;
  webkitSpeechRecognition?: any;
}

const BENGALI_SPEECH_LANGS: ReadonlyArray<'bn-BD' | 'bn-IN'> = ['bn-BD', 'bn-IN'];
const MAX_RECORDING_MS = 45000;

export interface UseSpeechRecognitionOptions {
  passiveMode?: boolean;
  onUnclear?: () => void;
}

export function useSpeechRecognition(
  onResultCallback?: (transcript: string) => void,
  onAutoEndCallback?: (finalTranscript: string) => void,
  options?: UseSpeechRecognitionOptions
) {
  const [isListening, setIsListening] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [permissionBlocked, setPermissionBlocked] = useState(false);
  const [isSupported, setIsSupported] = useState(true);
  const [activeVoiceEngine, setActiveVoiceEngine] = useState<'bn-BD' | 'bn-IN' | 'gemini'>('bn-BD');
  const [hasNativeSpeech] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const win = window as unknown as IWindow;
    return Boolean(win?.SpeechRecognition || win?.webkitSpeechRecognition);
  });

  const recognitionRef = useRef<any>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const usingFallbackRecorderRef = useRef(false);
  const nativeDisabledForSessionRef = useRef(false);
  const manualStopRef = useRef(false);
  const langIndexRef = useRef(0);
  const sessionStartTimeRef = useRef(0);
  const startWatchdogRef = useRef<number | null>(null);
  const maxRecordTimerRef = useRef<number | null>(null);
  const switchingEngineRef = useRef(false);

  const transcriptRef = useRef('');
  const interimRef = useRef('');
  const onResultRef = useRef(onResultCallback);
  const onAutoEndRef = useRef(onAutoEndCallback);
  const onUnclearRef = useRef(options?.onUnclear);
  const passiveModeRef = useRef(Boolean(options?.passiveMode));
  const stopResolveRef = useRef<((text: string) => void) | null>(null);
  const vadTimerRef = useRef<number | null>(null);
  const vadAudioCtxRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    onResultRef.current = onResultCallback;
  }, [onResultCallback]);

  useEffect(() => {
    onAutoEndRef.current = onAutoEndCallback;
  }, [onAutoEndCallback]);

  useEffect(() => {
    onUnclearRef.current = options?.onUnclear;
  }, [options?.onUnclear]);

  useEffect(() => {
    passiveModeRef.current = Boolean(options?.passiveMode);
  }, [options?.passiveMode]);

  useEffect(() => {
    transcriptRef.current = transcript;
  }, [transcript]);

  const stopVadMonitor = useCallback(() => {
    if (vadTimerRef.current) {
      window.clearInterval(vadTimerRef.current);
      vadTimerRef.current = null;
    }
    if (vadAudioCtxRef.current) {
      vadAudioCtxRef.current.close().catch(() => {});
      vadAudioCtxRef.current = null;
    }
  }, []);

  const clearTimers = useCallback(() => {
    if (startWatchdogRef.current) {
      window.clearTimeout(startWatchdogRef.current);
      startWatchdogRef.current = null;
    }
    if (maxRecordTimerRef.current) {
      window.clearTimeout(maxRecordTimerRef.current);
      maxRecordTimerRef.current = null;
    }
    stopVadMonitor();
  }, [stopVadMonitor]);

  const stopMediaStream = useCallback(() => {
    stopVadMonitor();
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch (_) {}
      });
      mediaStreamRef.current = null;
    }
  }, [stopVadMonitor]);

  const isIframeMicBlockedByPolicy = (): boolean => {
    try {
      const doc = document as any;
      if (doc.featurePolicy && typeof doc.featurePolicy.allowsFeature === 'function') {
        if (!doc.featurePolicy.allowsFeature('microphone')) return true;
      }
      if (doc.permissionsPolicy && typeof doc.permissionsPolicy.allowsFeature === 'function') {
        if (!doc.permissionsPolicy.allowsFeature('microphone')) return true;
      }
    } catch (_) {}
    return false;
  };

  const checkMicPermissionState = async (): Promise<'granted' | 'denied' | 'prompt' | 'unknown'> => {
    try {
      if (navigator.permissions && typeof navigator.permissions.query === 'function') {
        const result = await navigator.permissions.query({ name: 'microphone' as PermissionName });
        return result.state;
      }
    } catch (_) {}
    return 'unknown';
  };

  const acquireMicStream = async (): Promise<MediaStream> => {
    try {
      return await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
    } catch (err: any) {
      if (err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError' || err?.name === 'NotFoundError') {
        throw err;
      }
      // Fallback to plain audio:true if hardware rejects constraints on OPPO ColorOS / Android
      return await navigator.mediaDevices.getUserMedia({ audio: true });
    }
  };

  const isAudioSilent = async (blob: Blob): Promise<boolean> => {
    if (blob.size < 600) return true;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return false;
      const ctx = new AudioCtx();
      try {
        const arrayBuffer = await blob.arrayBuffer();
        const audioBuffer = await ctx.decodeAudioData(arrayBuffer);
        const channel = audioBuffer.getChannelData(0);
        let maxAmp = 0;
        for (let i = 0; i < channel.length; i += 16) {
          const v = Math.abs(channel[i]);
          if (v > maxAmp) maxAmp = v;
        }
        return maxAmp < 0.0025;
      } finally {
        ctx.close().catch(() => {});
      }
    } catch (_) {
      return false;
    }
  };

  const transcribeRecordedBlob = useCallback(async (blob: Blob): Promise<string> => {
    setIsTranscribing(true);
    const controller = new AbortController();
    const timeoutId = window.setTimeout(() => controller.abort(), 30000);

    try {
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = reader.result as string;
          const base64Data = result.includes(',') ? result.split(',')[1] : result;
          resolve(base64Data);
        };
        reader.onerror = () => reject(new Error('অডিও ডেটা প্রসেস করা যায়নি।'));
        reader.readAsDataURL(blob);
      });

      const res = await fetch('/api/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          audioBase64: base64,
          mimeType: blob.type || 'audio/webm',
        }),
      });

      window.clearTimeout(timeoutId);

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'ভয়েস বুঝতে সমস্যা হয়েছে।');
      }

      const data = await res.json();
      const text = (data.text || '').trim();
      if (text) {
        setTranscript(text);
        transcriptRef.current = text;
        if (onResultRef.current) {
          onResultRef.current(text);
        }
      } else {
        setError('কোনো কথা বোঝা যায়নি। অনুগ্রহ করে মাইক্রোফোনের কাছে স্পষ্ট বাংলায় বলুন।');
        onUnclearRef.current?.();
      }
      return text;
    } catch (err: any) {
      window.clearTimeout(timeoutId);
      if (err?.name === 'AbortError') {
        setError('ভয়েস ট্রান্সক্রাইব করতে বেশি সময় লাগছে। দয়া করে আবার বলুন।');
      } else {
        setError(err?.message || 'ভয়েস বুঝতে সমস্যা হয়েছে।');
      }
      return '';
    } finally {
      setIsTranscribing(false);
    }
  }, []);

  const stopRecorderAndTranscribe = useCallback(async (): Promise<string> => {
    clearTimers();
    const recorder = mediaRecorderRef.current;
    usingFallbackRecorderRef.current = false;
    setIsListening(false);
    setInterimTranscript('');

    if (!recorder || recorder.state === 'inactive') {
      stopMediaStream();
      return transcriptRef.current;
    }

    return new Promise<string>((resolve) => {
      let resolved = false;
      const finalizeBlob = async () => {
        if (resolved) return;
        resolved = true;
        stopMediaStream();
        const chunks = audioChunksRef.current;
        audioChunksRef.current = [];
        if (chunks.length === 0) {
          setError('মাইক্রোফোন থেকে কোনো অডিও পাওয়া যায়নি। আবার চেষ্টা করুন।');
          resolve('');
          return;
        }
        const blob = new Blob(chunks, {
          type: recorder.mimeType || 'audio/webm',
        });
        const silent = await isAudioSilent(blob);
        if (silent) {
          setError('কোনো কথা শোনা যায়নি। অনুগ্রহ করে মাইক্রোফোনের কাছে স্পষ্টভাবে বলুন।');
          onUnclearRef.current?.();
          resolve('');
          return;
        }
        const text = await transcribeRecordedBlob(blob);
        resolve(text);
      };

      const guardTimer = window.setTimeout(() => {
        finalizeBlob();
      }, 1500);

      recorder.onstop = () => {
        window.clearTimeout(guardTimer);
        finalizeBlob();
      };

      try {
        if (typeof recorder.requestData === 'function' && recorder.state === 'recording') {
          try {
            recorder.requestData();
          } catch (_) {}
        }
        recorder.stop();
      } catch (_) {
        window.clearTimeout(guardTimer);
        stopMediaStream();
        resolve('');
      }
    });
  }, [clearTimers, stopMediaStream, transcribeRecordedBlob]);

  const startFallbackRecorder = useCallback(async () => {
    clearTimers();
    switchingEngineRef.current = false;

    if (
      typeof navigator === 'undefined' ||
      !navigator.mediaDevices ||
      !navigator.mediaDevices.getUserMedia ||
      typeof MediaRecorder === 'undefined'
    ) {
      setError('আপনার ব্রাউজারে মাইক্রোফোন রেকর্ডিং সমর্থিত নয়। অনুগ্রহ করে Chrome ব্রাউজার আপডেট করুন।');
      setIsSupported(false);
      setIsListening(false);
      return;
    }

    if (isIframeMicBlockedByPolicy()) {
      setPermissionBlocked(true);
      setIsListening(false);
      setError(
        'এই প্রিভিউ উইন্ডোতে মাইক্রোফোন সীমাবদ্ধ করা আছে। অনুগ্রহ করে অ্যাপটি সরাসরি Chrome ব্রাউজারে খুলুন বা PWA হিসেবে ইনস্টল করে ব্যবহার করুন।'
      );
      return;
    }

    const permState = await checkMicPermissionState();
    if (permState === 'denied') {
      setPermissionBlocked(true);
      setIsListening(false);
      setError(
        'Chrome-এ মাইক্রোফোন অনুমতি বন্ধ আছে। নিচের নিয়ম অনুযায়ী Microphone Allow করুন।'
      );
      return;
    }

    try {
      stopMediaStream();
      const stream = await acquireMicStream();
      mediaStreamRef.current = stream;
      audioChunksRef.current = [];

      const supportedMime = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/mp4;codecs=mp4a.40.2',
        'audio/mp4',
        'audio/ogg;codecs=opus',
      ].find((m) => {
        try {
          return MediaRecorder.isTypeSupported(m);
        } catch (_) {
          return false;
        }
      });

      const recorder = supportedMime
        ? new MediaRecorder(stream, { mimeType: supportedMime })
        : new MediaRecorder(stream);

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onerror = () => {
        clearTimers();
        setError('মাইক্রোফোন রেকর্ডিংয়ে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
        stopMediaStream();
        usingFallbackRecorderRef.current = false;
        setIsListening(false);
      };

      mediaRecorderRef.current = recorder;
      usingFallbackRecorderRef.current = true;
      manualStopRef.current = false;
      setPermissionBlocked(false);
      setActiveVoiceEngine('gemini');
      setError(null);

      // 250ms timeslice ensures OPPO A18 Android Chrome captures audio reliably even for short speech
      recorder.start(250);
      setIsListening(true);
      setInterimTranscript('বাংলায় কথা বলুন... শেষ হলে স্বয়ংক্রিয়ভাবে উত্তর দেবে');

      // Lightweight VAD: auto-stop 1.3s after user finishes speaking
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const vadCtx = new AudioCtx();
          vadAudioCtxRef.current = vadCtx;
          const source = vadCtx.createMediaStreamSource(stream);
          const analyser = vadCtx.createAnalyser();
          analyser.fftSize = 256;
          source.connect(analyser);
          const dataArray = new Uint8Array(analyser.fftSize);
          let heardSpeech = false;
          let lastSpeechAt = Date.now();
          const startedAt = Date.now();

          vadTimerRef.current = window.setInterval(async () => {
            if (!usingFallbackRecorderRef.current || mediaRecorderRef.current?.state !== 'recording') {
              stopVadMonitor();
              return;
            }
            analyser.getByteTimeDomainData(dataArray);
            let sumSq = 0;
            for (let i = 0; i < dataArray.length; i += 4) {
              const norm = (dataArray[i] - 128) / 128;
              sumSq += norm * norm;
            }
            const rms = Math.sqrt(sumSq / (dataArray.length / 4));
            const now = Date.now();
            if (rms > 0.018) {
              heardSpeech = true;
              lastSpeechAt = now;
            } else if (heardSpeech && now - lastSpeechAt >= 1300 && now - startedAt >= 900) {
              stopVadMonitor();
              const text = await stopRecorderAndTranscribe();
              if (text && onAutoEndRef.current) {
                onAutoEndRef.current(text);
              }
            }
          }, 130);
        }
      } catch (_) {}

      maxRecordTimerRef.current = window.setTimeout(async () => {
        if (usingFallbackRecorderRef.current && mediaRecorderRef.current?.state === 'recording') {
          const text = await stopRecorderAndTranscribe();
          if (text && onAutoEndRef.current) {
            onAutoEndRef.current(text);
          }
        }
      }, MAX_RECORDING_MS);
    } catch (err: any) {
      console.error('Microphone permission/init error:', err);
      stopMediaStream();
      usingFallbackRecorderRef.current = false;
      setIsListening(false);
      if (err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError') {
        setPermissionBlocked(true);
        setError(
          'মাইক্রোফোন চালু করা যায়নি (অনুমতি পাওয়া যায়নি)। Chrome ও ফোনের সেটিংস থেকে Microphone Allow করুন।'
        );
      } else if (err?.name === 'NotFoundError' || err?.name === 'DevicesNotFoundError') {
        setError('আপনার ডিভাইসে কোনো কার্যকর মাইক্রোফোন পাওয়া যায়নি।');
      } else if (err?.name === 'NotReadableError' || err?.name === 'TrackStartError') {
        setError('মাইক্রোফোন অন্য কোনো অ্যাপ (যেমন কল বা রেকর্ডার) ব্যবহার করছে। সেটি বন্ধ করে আবার চেষ্টা করুন।');
      } else {
        setError('মাইক্রোফোন চালু করা যায়নি। অনুগ্রহ করে পেজটি রিলোড করে আবার চেষ্টা করুন।');
      }
    }
  }, [clearTimers, stopMediaStream, stopRecorderAndTranscribe]);

  const startNativeRecognition = useCallback(
    (langIdx: number) => {
      const win = typeof window !== 'undefined' ? (window as unknown as IWindow) : null;
      const SpeechRecognition = win?.SpeechRecognition || win?.webkitSpeechRecognition;

      if (!SpeechRecognition) {
        nativeDisabledForSessionRef.current = true;
        startFallbackRecorder();
        return;
      }

      if (recognitionRef.current) {
        try {
          recognitionRef.current.onstart = null;
          recognitionRef.current.onresult = null;
          recognitionRef.current.onerror = null;
          recognitionRef.current.onend = null;
          recognitionRef.current.abort();
        } catch (_) {}
        recognitionRef.current = null;
      }

      try {
        const recognition = new SpeechRecognition();
        const chosenLang = BENGALI_SPEECH_LANGS[langIdx] || 'bn-BD';
        langIndexRef.current = langIdx;

        // continuous = false prevents Android Chrome / OPPO ColorOS duplicate phrases and silent hangs
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.maxAlternatives = 1;
        recognition.lang = chosenLang;

        let didStart = false;
        let receivedAnySpeech = false;

        clearTimers();
        startWatchdogRef.current = window.setTimeout(() => {
          if (!didStart && !manualStopRef.current && !usingFallbackRecorderRef.current) {
            console.warn('[SpeechRecognition] Start watchdog expired; switching to Gemini MediaRecorder');
            switchingEngineRef.current = true;
            try {
              recognition.abort();
            } catch (_) {}
            nativeDisabledForSessionRef.current = true;
            startFallbackRecorder();
          }
        }, 2000);

        recognition.onstart = () => {
          didStart = true;
          clearTimers();
          switchingEngineRef.current = false;
          manualStopRef.current = false;
          sessionStartTimeRef.current = Date.now();
          setActiveVoiceEngine(chosenLang);
          setPermissionBlocked(false);
          setIsListening(true);
          setError(null);
          interimRef.current = '';
          setInterimTranscript('');
        };

        recognition.onresult = (event: any) => {
          receivedAnySpeech = true;
          let finalCombined = '';
          let currentInterim = '';

          for (let i = 0; i < event.results.length; i++) {
            const item = event.results[i];
            const textPart = item[0]?.transcript || '';
            if (item.isFinal) {
              finalCombined += (finalCombined ? ' ' : '') + textPart.trim();
            } else {
              currentInterim += (currentInterim ? ' ' : '') + textPart.trim();
            }
          }

          if (finalCombined) {
            transcriptRef.current = finalCombined;
            setTranscript(finalCombined);
            if (onResultRef.current) {
              onResultRef.current(finalCombined);
            }
          }
          interimRef.current = currentInterim;
          setInterimTranscript(currentInterim);
        };

        recognition.onerror = (event: any) => {
          clearTimers();
          const errCode = event?.error;
          console.warn(`[SpeechRecognition:${chosenLang}] error:`, errCode);

          if (manualStopRef.current || switchingEngineRef.current) return;

          if (errCode === 'language-not-supported' && langIndexRef.current === 0) {
            switchingEngineRef.current = true;
            try {
              recognition.abort();
            } catch (_) {}
            startNativeRecognition(1);
            return;
          }

          // On OPPO A18 Android Chrome, Google Speech Service often triggers not-allowed / service-not-allowed /
          // audio-capture / network even when Chrome Microphone permission IS Allowed. Verify & run via MediaRecorder!
          if (
            errCode === 'not-allowed' ||
            errCode === 'service-not-allowed' ||
            errCode === 'audio-capture' ||
            errCode === 'network' ||
            errCode === 'language-not-supported'
          ) {
            switchingEngineRef.current = true;
            nativeDisabledForSessionRef.current = true;
            try {
              recognition.abort();
            } catch (_) {}
            startFallbackRecorder();
            return;
          }

          if (errCode === 'no-speech' && !receivedAnySpeech) {
            const elapsed = Date.now() - sessionStartTimeRef.current;
            // If Android Chrome killed SpeechRecognition quickly or bn-BD heard nothing, switch cleanly
            if (langIndexRef.current === 0 && elapsed < 2500) {
              switchingEngineRef.current = true;
              try {
                recognition.abort();
              } catch (_) {}
              startNativeRecognition(1);
              return;
            }
            if (elapsed < 3500) {
              switchingEngineRef.current = true;
              nativeDisabledForSessionRef.current = true;
              try {
                recognition.abort();
              } catch (_) {}
              startFallbackRecorder();
              return;
            }
          }

          if (errCode !== 'no-speech' && errCode !== 'aborted') {
            switchingEngineRef.current = true;
            nativeDisabledForSessionRef.current = true;
            startFallbackRecorder();
          }
        };

        recognition.onend = () => {
          clearTimers();
          if (switchingEngineRef.current || usingFallbackRecorderRef.current) return;

          const finalText = (transcriptRef.current || interimRef.current).trim();
          const elapsed = Date.now() - sessionStartTimeRef.current;

          // If Chrome SpeechRecognition ended almost immediately with no speech, auto-recover to Gemini MediaRecorder
          if (!manualStopRef.current && !finalText && elapsed > 0 && elapsed < 2200) {
            switchingEngineRef.current = true;
            nativeDisabledForSessionRef.current = true;
            startFallbackRecorder();
            return;
          }

          setIsListening(false);
          if (!transcriptRef.current && interimRef.current) {
            transcriptRef.current = finalText;
            setTranscript(finalText);
            if (onResultRef.current && finalText) {
              onResultRef.current(finalText);
            }
          }
          interimRef.current = '';
          setInterimTranscript('');

          if (stopResolveRef.current) {
            const resolveFn = stopResolveRef.current;
            stopResolveRef.current = null;
            resolveFn(finalText);
          } else if (!manualStopRef.current && finalText && onAutoEndRef.current) {
            onAutoEndRef.current(finalText);
          } else if (!manualStopRef.current && !finalText && !error) {
            if (passiveModeRef.current) {
              // In Always-Ready / Wake Word mode, allow parent to quietly re-arm without error flash
              onAutoEndRef.current?.('');
            } else {
              setError('কোনো কথা শোনা যায়নি। মাইক্রোফোনে চাপ দিয়ে বাংলায় বলুন।');
              onUnclearRef.current?.();
            }
          }
        };

        recognitionRef.current = recognition;
        recognition.start();
      } catch (e) {
        clearTimers();
        console.warn('Native SpeechRecognition threw synchronously, falling back to MediaRecorder:', e);
        nativeDisabledForSessionRef.current = true;
        startFallbackRecorder();
      }
    },
    [clearTimers, error, startFallbackRecorder]
  );

  useEffect(() => {
    const win = typeof window !== 'undefined' ? (window as unknown as IWindow) : null;
    const SpeechRecognition = win?.SpeechRecognition || win?.webkitSpeechRecognition;
    const hasMediaRecorder =
      typeof navigator !== 'undefined' &&
      Boolean(navigator.mediaDevices?.getUserMedia) &&
      typeof MediaRecorder !== 'undefined';

    if (!SpeechRecognition && !hasMediaRecorder) {
      setIsSupported(false);
    }

    return () => {
      clearTimers();
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (_) {}
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        try {
          mediaRecorderRef.current.stop();
        } catch (_) {}
      }
      stopMediaStream();
    };
  }, [clearTimers, stopMediaStream]);

  const startListening = useCallback(
    (forceServerRecorder = false) => {
      setError(null);
      setPermissionBlocked(false);
      setTranscript('');
      transcriptRef.current = '';
      interimRef.current = '';
      setInterimTranscript('');
      manualStopRef.current = false;
      switchingEngineRef.current = false;

      if (isIframeMicBlockedByPolicy()) {
        setPermissionBlocked(true);
        setError(
          'এই প্রিভিউ উইন্ডোতে মাইক্রোফোন সীমাবদ্ধ করা আছে। অনুগ্রহ করে অ্যাপটি সরাসরি Chrome ব্রাউজারে খুলুন বা PWA হিসেবে ইনস্টল করুন।'
        );
        return;
      }

      if (forceServerRecorder || nativeDisabledForSessionRef.current) {
        startFallbackRecorder();
        return;
      }

      const win = typeof window !== 'undefined' ? (window as unknown as IWindow) : null;
      const SpeechRecognition = win?.SpeechRecognition || win?.webkitSpeechRecognition;
      if (!SpeechRecognition) {
        startFallbackRecorder();
        return;
      }

      startNativeRecognition(langIndexRef.current);
    },
    [startFallbackRecorder, startNativeRecognition]
  );

  const stopListening = useCallback(async (): Promise<string> => {
    manualStopRef.current = true;
    clearTimers();

    if (usingFallbackRecorderRef.current && mediaRecorderRef.current) {
      return await stopRecorderAndTranscribe();
    }

    if (recognitionRef.current && isListening) {
      return new Promise<string>((resolve) => {
        const fallbackTimer = window.setTimeout(() => {
          if (stopResolveRef.current) {
            stopResolveRef.current = null;
            setIsListening(false);
            resolve((transcriptRef.current || interimRef.current).trim());
          }
        }, 500);

        stopResolveRef.current = (finalText: string) => {
          window.clearTimeout(fallbackTimer);
          resolve(finalText);
        };

        try {
          recognitionRef.current.stop();
        } catch (_) {
          window.clearTimeout(fallbackTimer);
          stopResolveRef.current = null;
          setIsListening(false);
          resolve((transcriptRef.current || interimRef.current).trim());
        }
      });
    }

    setIsListening(false);
    return (transcriptRef.current || interimRef.current).trim();
  }, [clearTimers, isListening, stopRecorderAndTranscribe]);

  const resetTranscript = useCallback(() => {
    setTranscript('');
    transcriptRef.current = '';
    interimRef.current = '';
    setInterimTranscript('');
    setError(null);
    setPermissionBlocked(false);
  }, []);

  return {
    isListening,
    isTranscribing,
    transcript,
    interimTranscript,
    error,
    permissionBlocked,
    isSupported,
    hasNativeSpeech,
    activeVoiceEngine,
    startListening,
    stopListening,
    resetTranscript,
    setTranscript,
  };
}
