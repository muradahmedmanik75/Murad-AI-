import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Mic,
  Volume2,
  Sparkles,
  MessageSquare,
  RotateCcw,
  ShieldAlert,
  Check,
  X,
  AlarmClock,
  Radio,
  Smartphone,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { useSpeechRecognition } from '../hooks/useSpeechRecognition';
import { AlarmItem, AssistantAction, UserProfile } from '../types';
import { SendMessageResult } from '../App';
import {
  parseVoiceConfirmation,
  parseWakeWord,
  playAssistantTone,
} from '../utils/assistantActions';

interface VoiceScreenProps {
  profile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
  alarms: AlarmItem[];
  onDeleteAlarm: (alarmId: string) => void;
  isSpeaking: boolean;
  isLoadingAudio?: boolean;
  speak: (
    text: string,
    messageId?: string,
    onEnded?: () => void,
    preferInstantBrowser?: boolean
  ) => void;
  stopSpeaking: () => void;
  unlockAudio?: () => void;
  onSendVoiceMessage: (
    text: string,
    onSpeakComplete?: () => void
  ) => Promise<SendMessageResult | void>;
  onExecuteAction: (action: AssistantAction) => { executed: boolean; feedback: string };
  onSwitchToChat: () => void;
}

export const VoiceScreen: React.FC<VoiceScreenProps> = ({
  profile,
  onUpdateProfile,
  alarms,
  onDeleteAlarm,
  isSpeaking,
  isLoadingAudio = false,
  speak,
  stopSpeaking,
  unlockAudio,
  onSendVoiceMessage,
  onExecuteAction,
  onSwitchToChat,
}) => {
  const [voiceStatus, setVoiceStatus] = useState<
    'idle' | 'listening' | 'processing' | 'speaking'
  >('idle');
  const [userSpokenText, setUserSpokenText] = useState('');
  const [aiSpokenText, setAiSpokenText] = useState(
    'আসসালামু আলাইকুম, মুরাদ ভাই! আমি Murad AI। শুধু "Murad" বলুন অথবা সরাসরি কথা বলুন, আমি দ্রুত শুনে বাংলায় উত্তর ও কাজ সম্পন্ন করব।'
  );
  const [lastFailedQuery, setLastFailedQuery] = useState<string | null>(null);
  const [pendingAction, setPendingAction] = useState<AssistantAction | null>(null);
  const [nativeNote, setNativeNote] = useState<string | null>(null);
  const [showCapabilities, setShowCapabilities] = useState(false);
  const [isSendingQuery, setIsSendingQuery] = useState(false);
  // Tracks whether user activated the live hands-free session at least once
  const [handsFreeArmed, setHandsFreeArmed] = useState(false);
  // After saying just "Murad", wait for the immediate follow-up command without wake word
  const [awaitingWakeCommand, setAwaitingWakeCommand] = useState(false);
  const [wakeLockActive, setWakeLockActive] = useState(false);
  const nativeBridge =
    typeof window !== 'undefined' ? (window as any).MuradNative : undefined;
  const isNativeApk = Boolean(nativeBridge?.isNativeApp?.());
  const [nativeServiceOn, setNativeServiceOn] = useState<boolean>(() =>
    Boolean(nativeBridge?.isWakeServiceRunning?.())
  );

  const isSendingRef = useRef(false);
  const handsFreeArmedRef = useRef(false);
  const alwaysReadyRef = useRef(Boolean(profile.alwaysReadyVoice ?? true));
  const wakeWordRef = useRef(Boolean(profile.wakeWordEnabled ?? true));
  const awaitingWakeCommandRef = useRef(false);
  const pendingActionRef = useRef<AssistantAction | null>(null);
  const restartTimerRef = useRef<number | null>(null);
  const wakeLockRef = useRef<any>(null);

  const alwaysReadyEnabled = Boolean(profile.alwaysReadyVoice ?? true);
  const wakeWordEnabled = Boolean(profile.wakeWordEnabled ?? true);

  useEffect(() => {
    handsFreeArmedRef.current = handsFreeArmed;
  }, [handsFreeArmed]);

  useEffect(() => {
    alwaysReadyRef.current = alwaysReadyEnabled;
  }, [alwaysReadyEnabled]);

  useEffect(() => {
    wakeWordRef.current = wakeWordEnabled;
  }, [wakeWordEnabled]);

  useEffect(() => {
    awaitingWakeCommandRef.current = awaitingWakeCommand;
  }, [awaitingWakeCommand]);

  useEffect(() => {
    pendingActionRef.current = pendingAction;
  }, [pendingAction]);

  const clearRestartTimer = useCallback(() => {
    if (restartTimerRef.current) {
      window.clearTimeout(restartTimerRef.current);
      restartTimerRef.current = null;
    }
  }, []);

  const schedulePassiveRelistenRef = useRef<() => void>(() => {});

  const handleConfirmPendingAction = useCallback(
    (actionToRun?: AssistantAction) => {
      const target = actionToRun || pendingActionRef.current;
      if (!target) return;
      setPendingAction(null);
      pendingActionRef.current = null;
      playAssistantTone('confirm');
      const result = onExecuteAction(target);
      if (result.feedback) {
        setAiSpokenText(result.feedback);
        speak(result.feedback, undefined, () => {
          schedulePassiveRelistenRef.current();
        });
      }
    },
    [onExecuteAction, speak]
  );

  const handleCancelPendingAction = useCallback(() => {
    if (!pendingActionRef.current) return;
    setPendingAction(null);
    pendingActionRef.current = null;
    const msg = 'ঠিক আছে মুরাদ ভাই, আপনার নির্দেশ অনুযায়ী কাজটি বাতিল করা হয়েছে।';
    setAiSpokenText(msg);
    speak(msg, undefined, () => {
      schedulePassiveRelistenRef.current();
    });
  }, [speak]);

  const sendVoiceQuery = useCallback(
    async (query: string) => {
      const cleanQuery = query.trim();
      if (!cleanQuery || isSendingRef.current) return;

      isSendingRef.current = true;
      setIsSendingQuery(true);
      setLastFailedQuery(null);
      setNativeNote(null);
      setUserSpokenText(cleanQuery);
      setVoiceStatus('processing');

      try {
        const result = await onSendVoiceMessage(cleanQuery, () => {
          schedulePassiveRelistenRef.current();
        });
        if (result?.reply) {
          setAiSpokenText(result.reply);
          if (result.action && result.action.type !== 'none') {
            if (result.action.nativeNote) {
              setNativeNote(result.action.nativeNote);
            }
            if (result.action.type === 'unclear') {
              setPendingAction(null);
            } else if (result.action.requiresConfirmation) {
              setPendingAction(result.action);
            } else if (
              result.action.type !== 'set_alarm' &&
              result.action.type !== 'set_timer' &&
              result.action.type !== 'check_capabilities'
            ) {
              onExecuteAction(result.action);
            }
          }
        } else {
          setVoiceStatus('idle');
        }
      } catch (e: any) {
        setLastFailedQuery(cleanQuery);
        setAiSpokenText(
          e?.message || 'দুঃখিত, এই মুহূর্তে উত্তর পাওয়া যায়নি। দয়া করে আবার চেষ্টা করুন।'
        );
        setVoiceStatus('idle');
      } finally {
        isSendingRef.current = false;
        setIsSendingQuery(false);
      }
    },
    [onExecuteAction, onSendVoiceMessage]
  );

  const handleUnclearSpeech = useCallback(() => {
    if (isSendingRef.current || isSpeaking) return;
    const msg = 'দুঃখিত মুরাদ ভাই, আপনার কথাটি স্পষ্ট বুঝতে পারিনি। অনুগ্রহ করে আবার বলবেন?';
    setAiSpokenText(msg);
    speak(msg, undefined, () => {
      schedulePassiveRelistenRef.current();
    });
  }, [isSpeaking, speak]);

  const handleAutoSpeechEnd = useCallback(
    (rawFinal: string) => {
      const clean = rawFinal.trim();

      // Empty passive round in Always-Ready / Wake Word mode -> quietly re-arm
      if (!clean) {
        if (handsFreeArmedRef.current && alwaysReadyRef.current) {
          schedulePassiveRelistenRef.current();
        }
        return;
      }

      // 1. Check if awaiting verbal Yes/No for a pending sensitive action
      if (pendingActionRef.current) {
        const decision = parseVoiceConfirmation(clean);
        if (decision === 'confirm') {
          setUserSpokenText(clean);
          handleConfirmPendingAction(pendingActionRef.current);
          return;
        }
        if (decision === 'cancel') {
          setUserSpokenText(clean);
          handleCancelPendingAction();
          return;
        }
        // User spoke a brand new request -> dismiss pending action and process new request
        setPendingAction(null);
      }

      // 2. Wake word check when Always-Ready + Wake Word is armed (unless already waiting for post-wake command)
      const shouldCheckWake =
        handsFreeArmedRef.current &&
        alwaysReadyRef.current &&
        wakeWordRef.current &&
        !awaitingWakeCommandRef.current;

      if (shouldCheckWake) {
        const wake = parseWakeWord(clean);
        if (!wake.matched) {
          // Ignore ambient chatter not addressed to Murad AI and keep listening quietly
          schedulePassiveRelistenRef.current();
          return;
        }

        playAssistantTone('wake');

        if (wake.wakeOnly) {
          setAwaitingWakeCommand(true);
          awaitingWakeCommandRef.current = true;
          const promptMsg = 'আসসালামু আলাইকুম, মুরাদ ভাই! বলুন, আমি শুনছি।';
          setUserSpokenText('Murad');
          setAiSpokenText(promptMsg);
          speak(
            promptMsg,
            undefined,
            () => {
              schedulePassiveRelistenRef.current();
            },
            true
          );
          return;
        }

        setAwaitingWakeCommand(false);
        awaitingWakeCommandRef.current = false;
        sendVoiceQuery(wake.command);
        return;
      }

      // 3. Direct command
      setAwaitingWakeCommand(false);
      awaitingWakeCommandRef.current = false;
      sendVoiceQuery(clean);
    },
    [
      handleCancelPendingAction,
      handleConfirmPendingAction,
      sendVoiceQuery,
      speak,
    ]
  );

  const {
    isListening,
    isTranscribing,
    transcript,
    interimTranscript,
    error: micError,
    permissionBlocked,
    hasNativeSpeech,
    startListening,
    stopListening,
    resetTranscript,
  } = useSpeechRecognition(
    (finalResult) => {
      setUserSpokenText(finalResult);
    },
    handleAutoSpeechEnd,
    {
      passiveMode: handsFreeArmed && alwaysReadyEnabled,
      onUnclear: handleUnclearSpeech,
    }
  );

  // Wire passive re-listen scheduler safely (only when native SpeechRecognition is supported & tab is visible)
  useEffect(() => {
    schedulePassiveRelistenRef.current = () => {
      clearRestartTimer();
      if (
        !handsFreeArmedRef.current ||
        !alwaysReadyRef.current ||
        !hasNativeSpeech ||
        permissionBlocked ||
        typeof document === 'undefined' ||
        document.visibilityState !== 'visible'
      ) {
        return;
      }
      restartTimerRef.current = window.setTimeout(() => {
        if (
          handsFreeArmedRef.current &&
          alwaysReadyRef.current &&
          !isSendingRef.current &&
          document.visibilityState === 'visible'
        ) {
          resetTranscript();
          startListening();
        }
      }, 260);
    };
  }, [clearRestartTimer, hasNativeSpeech, permissionBlocked, resetTranscript, startListening]);

  // Keep OPPO A18 screen gently awake while user keeps Hands-Free Voice Assistant active
  useEffect(() => {
    let cancelled = false;

    const releaseWakeLock = async () => {
      if (wakeLockRef.current) {
        try {
          await wakeLockRef.current.release();
        } catch (_) {}
        wakeLockRef.current = null;
      }
      if (!cancelled) setWakeLockActive(false);
    };

    const requestWakeLock = async () => {
      if (
        typeof navigator === 'undefined' ||
        !('wakeLock' in navigator) ||
        document.visibilityState !== 'visible'
      ) {
        return;
      }
      try {
        const sentinel = await (navigator as any).wakeLock.request('screen');
        if (cancelled) {
          sentinel.release().catch(() => {});
          return;
        }
        wakeLockRef.current = sentinel;
        setWakeLockActive(true);
        sentinel.addEventListener('release', () => {
          if (!cancelled) setWakeLockActive(false);
        });
      } catch (_) {
        if (!cancelled) setWakeLockActive(false);
      }
    };

    if (handsFreeArmed && alwaysReadyEnabled) {
      requestWakeLock();
    } else {
      releaseWakeLock();
    }

    return () => {
      cancelled = true;
      releaseWakeLock();
    };
  }, [handsFreeArmed, alwaysReadyEnabled]);

  // Pause mic if OPPO A18 screen turns off or app goes background, resume when back
  useEffect(() => {
    const onVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        clearRestartTimer();
        if (isListening) {
          stopListening();
        }
      } else if (
        document.visibilityState === 'visible' &&
        handsFreeArmedRef.current &&
        alwaysReadyRef.current &&
        hasNativeSpeech &&
        !isListening &&
        !isSpeaking &&
        !isSendingRef.current
      ) {
        schedulePassiveRelistenRef.current();
      }
    };

    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange);
      clearRestartTimer();
    };
  }, [clearRestartTimer, hasNativeSpeech, isListening, isSpeaking, stopListening]);

  // Track status based on listening, transcribing, audio loading, and speaking
  useEffect(() => {
    if (isSpeaking) {
      setVoiceStatus('speaking');
    } else if (isListening) {
      setVoiceStatus('listening');
    } else if (isTranscribing || isLoadingAudio || isSendingQuery) {
      setVoiceStatus('processing');
    } else {
      setVoiceStatus('idle');
    }
  }, [isListening, isSpeaking, isTranscribing, isLoadingAudio, isSendingQuery]);

  const handleStartListening = (forceServerRecorder = false) => {
    clearRestartTimer();
    unlockAudio?.();
    stopSpeaking();
    resetTranscript();
    setUserSpokenText('');
    setLastFailedQuery(null);
    if (!forceServerRecorder && alwaysReadyEnabled && hasNativeSpeech) {
      setHandsFreeArmed(true);
      handsFreeArmedRef.current = true;
    }
    setVoiceStatus('listening');
    startListening(forceServerRecorder);
  };

  const handleFinishSpeaking = async () => {
    clearRestartTimer();
    unlockAudio?.();
    setVoiceStatus('processing');
    const recordedText = await stopListening();
    const finalQuery = (
      recordedText ||
      transcript ||
      interimTranscript ||
      userSpokenText
    ).trim();

    if (!finalQuery) {
      setHandsFreeArmed(false);
      handsFreeArmedRef.current = false;
      setVoiceStatus('idle');
      return;
    }

    handleAutoSpeechEnd(finalQuery);
  };

  const handleToggleMic = () => {
    unlockAudio?.();
    if (voiceStatus === 'speaking' || isLoadingAudio) {
      stopSpeaking();
      setVoiceStatus('idle');
      if (handsFreeArmed && alwaysReadyEnabled && hasNativeSpeech) {
        schedulePassiveRelistenRef.current();
      }
      return;
    }
    if (isListening) {
      // If user taps orb during passive wake-word listening, stop hands-free cleanly
      if (handsFreeArmed && wakeWordEnabled && !interimTranscript && !transcript) {
        clearRestartTimer();
        setHandsFreeArmed(false);
        handsFreeArmedRef.current = false;
        stopListening();
        return;
      }
      handleFinishSpeaking();
    } else {
      // Direct tap to speak a command immediately
      setAwaitingWakeCommand(true);
      awaitingWakeCommandRef.current = true;
      handleStartListening();
    }
  };

  const handleTestQuickVoice = async (query: string) => {
    clearRestartTimer();
    unlockAudio?.();
    stopSpeaking();
    setPendingAction(null);
    await sendVoiceQuery(query);
  };

  const toggleAlwaysReady = () => {
    const next = !alwaysReadyEnabled;
    onUpdateProfile({ ...profile, alwaysReadyVoice: next });
    if (!next) {
      clearRestartTimer();
      setHandsFreeArmed(false);
      handsFreeArmedRef.current = false;
    }
  };

  const toggleWakeWord = () => {
    const next = !wakeWordEnabled;
    onUpdateProfile({ ...profile, wakeWordEnabled: next });
  };

  const activeAlarms = alarms.filter((a) => a.active);

  return (
    <div className="flex-1 flex flex-col items-center justify-between px-4 py-4 pb-24 max-w-md mx-auto w-full relative overflow-y-auto select-none space-y-3">
      {/* Background Neon Halo */}
      <div
        className={`absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full pointer-events-none transition-all duration-700 blur-3xl ${
          isSpeaking
            ? 'bg-gradient-to-r from-sky-500/25 via-indigo-600/30 to-purple-600/35 scale-125'
            : isListening
            ? 'bg-gradient-to-r from-rose-500/25 via-purple-600/30 to-sky-500/25 scale-110'
            : 'bg-indigo-600/15 scale-90'
        }`}
      />

      {/* Top Bar: Title & Switch to Text */}
      <div className="w-full space-y-2 z-10">
        <div className="w-full flex items-center justify-between">
          <div className="flex items-center gap-2">
            {profile.avatarUrl ? (
              <img
                src={profile.avatarUrl}
                alt={profile.name}
                className="w-7 h-7 rounded-full object-cover border border-sky-400/60 shadow-sm"
              />
            ) : (
              <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
            )}
            <h2 className="text-sm font-bold text-white tracking-wide">
              <span className="text-red-500">Murad</span>{' '}
              <span className="text-white">AI</span> লাইভ ভয়েস
            </h2>
          </div>

          <button
            onClick={() => {
              clearRestartTimer();
              setHandsFreeArmed(false);
              onSwitchToChat();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1a0f3d] border border-[#341d6e] text-indigo-200 text-xs hover:bg-[#231551] transition active:scale-95"
          >
            <MessageSquare className="w-3.5 h-3.5 text-sky-400" />
            <span>টেক্সট চ্যাটে যান</span>
          </button>
        </div>

        {/* Always-Ready & Wake Word "Murad" Controls */}
        <div className="flex items-center justify-between gap-2 bg-[#120a2e]/85 border border-[#2d185e] rounded-xl px-2.5 py-1.5 text-[11px]">
          <button
            type="button"
            onClick={toggleAlwaysReady}
            className={`flex items-center gap-1.5 px-2 py-1 rounded-lg transition ${
              alwaysReadyEnabled
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <Radio className={`w-3 h-3 ${handsFreeArmed && alwaysReadyEnabled ? 'animate-pulse' : ''}`} />
            <span>সবসময় প্রস্তুত: {alwaysReadyEnabled ? 'চালু' : 'বন্ধ'}</span>
          </button>

          <button
            type="button"
            onClick={toggleWakeWord}
            disabled={!hasNativeSpeech}
            className={`flex items-center gap-1.5 px-2 py-1 rounded-lg transition ${
              wakeWordEnabled && hasNativeSpeech
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                : 'text-gray-400 hover:text-gray-200 disabled:opacity-50'
            }`}
          >
            <span>Wake Word "Murad": {wakeWordEnabled && hasNativeSpeech ? 'চালু' : 'সরাসরি'}</span>
          </button>
        </div>
      </div>

      {/* Central Visualizer & Holographic Voice Orb */}
      <div className="flex flex-col items-center justify-center my-auto py-2 z-10 space-y-4 w-full">
        {/* Status Chip */}
        <div className="px-4 py-1.5 rounded-full bg-[#170e3c]/90 border border-[#372074] backdrop-blur-md shadow-lg text-xs font-semibold flex items-center gap-2">
          {voiceStatus === 'listening' ? (
            <>
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <span className="text-rose-300">
                {handsFreeArmed &&
                alwaysReadyEnabled &&
                wakeWordEnabled &&
                !awaitingWakeCommand &&
                !pendingAction
                  ? 'শুধু "Murad" বলার অপেক্ষায়...'
                  : 'আপনাকে শুনছি... বাংলায় বলুন'}
              </span>
            </>
          ) : voiceStatus === 'processing' || isTranscribing || isLoadingAudio ? (
            <>
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
              <span className="text-amber-300">
                {isTranscribing
                  ? 'আপনার বাংলা কথা বোঝা হচ্ছে...'
                  : isLoadingAudio
                  ? 'বাংলা কণ্ঠ প্রস্তুত হচ্ছে...'
                  : 'Murad AI কাজ বুঝে উত্তর তৈরি করছে...'}
              </span>
            </>
          ) : voiceStatus === 'speaking' ? (
            <>
              <Volume2 className="w-3.5 h-3.5 text-sky-400 animate-bounce" />
              <span className="text-sky-300">বাংলায় পুরুষ কণ্ঠে উত্তর দিচ্ছে...</span>
            </>
          ) : (
            <>
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span className="text-indigo-200">
                {hasNativeSpeech
                  ? 'ভয়েস অ্যাসিস্ট্যান্ট চালু করতে বাটনে চাপুন'
                  : 'কথা বলতে বাটনে চাপুন (অটো-ভয়েস চালু)'}
              </span>
            </>
          )}
        </div>

        {/* Holographic Glowing Orb */}
        <div className="relative flex items-center justify-center">
          <div
            className={`absolute w-48 h-48 rounded-full border border-sky-400/20 transition-all duration-500 ${
              isSpeaking || isListening ? 'scale-110 opacity-100 animate-pulse' : 'scale-95 opacity-40'
            }`}
          />
          <div
            className={`absolute w-40 h-40 rounded-full border border-purple-500/30 transition-all duration-500 ${
              isSpeaking || isListening ? 'scale-105 opacity-100' : 'scale-90 opacity-40'
            }`}
          />

          <button
            onClick={handleToggleMic}
            disabled={voiceStatus === 'processing' && !isLoadingAudio}
            className={`relative w-32 h-32 rounded-full flex flex-col items-center justify-center shadow-2xl transition-all duration-300 active:scale-95 ${
              voiceStatus === 'listening'
                ? 'bg-gradient-to-tr from-rose-600 via-pink-600 to-purple-600 shadow-rose-900/60 ring-4 ring-rose-400/50'
                : voiceStatus === 'speaking'
                ? 'bg-gradient-to-tr from-sky-500 via-indigo-600 to-purple-600 shadow-sky-900/60 ring-4 ring-sky-400/50'
                : 'bg-gradient-to-tr from-indigo-800 via-purple-900 to-[#12082f] border-2 border-indigo-500/40 shadow-purple-950/80 hover:scale-105'
            }`}
          >
            {isSpeaking || isListening ? (
              <div className="flex items-center gap-1.5 h-9 mb-1">
                <span className="w-1.5 bg-white rounded-full voice-bar" />
                <span className="w-1.5 bg-white rounded-full voice-bar" />
                <span className="w-1.5 bg-white rounded-full voice-bar" />
                <span className="w-1.5 bg-white rounded-full voice-bar" />
                <span className="w-1.5 bg-white rounded-full voice-bar" />
              </div>
            ) : (
              <Mic className="w-9 h-9 text-white mb-1" />
            )}

            <span className="text-[11px] font-bold text-white tracking-wide">
              {voiceStatus === 'listening'
                ? 'থামান / পাঠান'
                : voiceStatus === 'speaking' || isLoadingAudio
                ? 'থামুন'
                : 'কথা বলুন'}
            </span>
          </button>
        </div>

        {/* Pending Permission / Confirmation Card (Req #6 & #7) */}
        {pendingAction && (
          <div className="w-full rounded-2xl bg-gradient-to-br from-amber-950/80 via-[#1a1040] to-[#120a2e] border border-amber-400/50 p-3.5 shadow-xl space-y-2.5">
            <div className="flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="text-left space-y-0.5">
                <p className="text-xs font-bold text-amber-200">
                  আপনার অনুমতি প্রয়োজন
                </p>
                <p className="text-[11px] text-gray-200 leading-relaxed">
                  {pendingAction.confirmationReason ||
                    (pendingAction.type === 'send_sms'
                      ? `${pendingAction.phone || 'প্রাপক'} নম্বরে SMS: "${pendingAction.smsBody || ''}"`
                      : pendingAction.type === 'make_call'
                      ? `${pendingAction.phone || 'নম্বরে'} ফোন কল শুরু করা হবে`
                      : pendingAction.type === 'clear_chat'
                      ? 'সমস্ত চ্যাট ইতিহাস স্থায়ীভাবে মুছে ফেলা হবে'
                      : pendingAction.type === 'delete_alarms'
                      ? 'সব অ্যালার্ম ও টাইমার মুছে ফেলা হবে'
                      : `${pendingAction.appName || pendingAction.url || 'নির্ধারিত কাজ'} খোলা হবে`)}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => handleConfirmPendingAction(pendingAction)}
                className="flex-1 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95 transition"
              >
                <Check className="w-3.5 h-3.5" />
                <span>অনুমতি দিন</span>
              </button>
              <button
                type="button"
                onClick={handleCancelPendingAction}
                className="flex-1 py-2 rounded-xl bg-[#241654] hover:bg-[#2f1d6b] border border-rose-500/30 text-rose-200 text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95 transition"
              >
                <X className="w-3.5 h-3.5" />
                <span>বাতিল</span>
              </button>
            </div>
          </div>
        )}

        {/* Live Bengali Transcript Box */}
        <div className="w-full bg-[#120a2e]/90 border border-[#2d185e] rounded-2xl p-3.5 text-center space-y-2 backdrop-blur-sm min-h-[100px] flex flex-col justify-center shadow-lg">
          {micError ? (
            <div className="space-y-2 text-left">
              <p className="text-xs text-amber-300 leading-relaxed text-center font-medium">
                {micError}
              </p>
              {permissionBlocked ? (
                <div className="text-[11px] text-amber-200/90 bg-black/30 rounded-xl p-2.5 space-y-1 leading-relaxed border border-amber-500/20">
                  <p className="font-semibold text-amber-300">
                    সমাধানের সহজ নিয়ম (OPPO A18 Chrome):
                  </p>
                  <p>
                    ১. ব্রাউজারের ঠিকানা বারের বাম পাশে সেটিংস/লক আইকনে চাপুন → Permissions → Microphone Allow করুন।
                  </p>
                  <p>
                    ২. ফোনের Settings → Apps → Chrome → Permissions → Microphone Allow চালু রাখুন।
                  </p>
                  <p>
                    ৩. অথবা ব্রাউজার মেনু থেকে "Install app" দিয়ে ইনস্টল করে সরাসরি ব্যবহার করুন।
                  </p>
                </div>
              ) : (
                <div className="text-center">
                  <button
                    type="button"
                    onClick={() => handleStartListening(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[11px] font-medium shadow-md active:scale-95 transition"
                  >
                    <Mic className="w-3 h-3" />
                    <span>জেমিনি ভয়েস মোডে আবার বলুন</span>
                  </button>
                </div>
              )}
            </div>
          ) : voiceStatus === 'listening' ? (
            <div>
              <p className="text-[11px] text-gray-400 mb-1">
                {handsFreeArmed && wakeWordEnabled && !awaitingWakeCommand && !pendingAction
                  ? 'হ্যান্ডস-ফ্রি ওয়েক ওয়ার্ড মোড:'
                  : 'আপনার কথা:'}
              </p>
              <p className="text-sm font-medium text-white italic">
                "{transcript || interimTranscript || 'শোনা হচ্ছে...'}"
              </p>
            </div>
          ) : voiceStatus === 'speaking' || aiSpokenText ? (
            <div className="space-y-1.5">
              {userSpokenText && (
                <p className="text-[11px] text-indigo-300/80 truncate">
                  আপনি: “{userSpokenText}”
                </p>
              )}
              <p className="text-[11px] mb-0.5 font-semibold">
                <span className="text-red-500">Murad</span>{' '}
                <span className="text-white">AI</span>{' '}
                <span className="text-sky-400">উত্তর:</span>
              </p>
              <p className="text-xs text-gray-200 line-clamp-4 leading-relaxed font-sans">
                {aiSpokenText}
              </p>
              {nativeNote && (
                <p className="text-[11px] text-amber-300/90 bg-amber-950/40 border border-amber-500/20 rounded-lg px-2.5 py-1.5 text-left">
                  ℹ️ {nativeNote}
                </p>
              )}
              {lastFailedQuery && voiceStatus !== 'processing' ? (
                <button
                  type="button"
                  onClick={() => {
                    unlockAudio?.();
                    sendVoiceQuery(lastFailedQuery);
                  }}
                  className="mt-1 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-[11px] font-medium shadow-md shadow-blue-950/40 active:scale-95 transition"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>আবার চেষ্টা করুন</span>
                </button>
              ) : (
                voiceStatus === 'idle' &&
                aiSpokenText && (
                  <button
                    type="button"
                    onClick={() => {
                      unlockAudio?.();
                      speak(aiSpokenText);
                    }}
                    className="mt-1 inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-[#1b1040] border border-[#3a2378] text-sky-300 text-[11px] font-medium hover:bg-[#231552] active:scale-95 transition"
                  >
                    <Volume2 className="w-3 h-3" />
                    <span>শুনুন</span>
                  </button>
                )
              )}
            </div>
          ) : (
            <p className="text-xs text-gray-400">
              বাংলায় কিছু বলুন। <span className="font-semibold text-red-500">Murad</span>{' '}
              <span className="font-semibold text-white">AI</span> সাথে সাথে বাংলায় উত্তর শুনিয়ে দেবে।
            </p>
          )}
        </div>

        {/* Active In-App Alarms / Timers */}
        {activeAlarms.length > 0 && (
          <div className="w-full bg-[#120a2e]/80 border border-indigo-500/30 rounded-xl p-2.5 space-y-1.5">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-sky-300">
              <AlarmClock className="w-3.5 h-3.5" />
              <span>সক্রিয় অ্যালার্ম / টাইমার (অ্যাপ খোলা থাকাকালীন):</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {activeAlarms.map((alarm) => (
                <div
                  key={alarm.id}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#1c1045] border border-indigo-400/30 text-[11px] text-indigo-100"
                >
                  <span>
                    ⏰ {alarm.timeDisplay} ({alarm.label})
                  </span>
                  <button
                    type="button"
                    onClick={() => onDeleteAlarm(alarm.id)}
                    className="text-rose-300 hover:text-rose-200"
                    title="মুছুন"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Quick Voice Action Chips + Android Capability Verifier */}
      <div className="w-full space-y-2 z-10">
        <p className="text-[11px] text-gray-400 text-center font-medium">
          দ্রুত ভয়েস কমান্ড পরীক্ষা করুন:
        </p>

        <div className="grid grid-cols-2 gap-2">
          {[
            { label: 'YouTube খোলো', query: 'অনুমতি নিয়ে YouTube অ্যাপ খোলো' },
            { label: '৫ মিনিট টাইমার দাও', query: '৫ মিনিটের একটি টাইমার সেট করো' },
            { label: 'গুগলে খবর খোঁজো', query: 'আজকের বাংলাদেশের খবর গুগলে সার্চ করো' },
            { label: 'আজকের ভালো উক্তি', query: 'আজকের জন্য একটি চমৎকার বাংলা অনুপ্রেরণাদায়ী উক্তি বলুন।' },
          ].map((item, idx) => (
            <button
              key={idx}
              onClick={() => handleTestQuickVoice(item.query)}
              className="p-2.5 rounded-xl bg-[#170e3d]/80 border border-[#321d6e] hover:border-sky-500/50 text-indigo-200 text-[11px] font-medium text-left truncate active:scale-95 transition"
            >
              🎙️ {item.label}
            </button>
          ))}
        </div>

        {/* Android vs Native App Honest Verification Drawer (Req #12) */}
        <div className="rounded-xl bg-[#120a2e]/85 border border-[#2c195b] overflow-hidden">
          <button
            type="button"
            onClick={() => setShowCapabilities(!showCapabilities)}
            className="w-full px-3 py-2 flex items-center justify-between text-[11px] font-semibold text-indigo-200 hover:bg-[#1a0f42] transition"
          >
            <span className="flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-sky-400" />
              <span>Android ও Native সক্ষমতা যাচাই (OPPO A18)</span>
            </span>
            {showCapabilities ? (
              <ChevronUp className="w-3.5 h-3.5 text-gray-400" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
            )}
          </button>

          {showCapabilities && (
            <div className="px-3 pb-3 pt-1 space-y-2 text-[11px] leading-relaxed border-t border-[#25154e]">
              {isNativeApk && (
                <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 space-y-2">
                  <p className="font-bold text-emerald-300">
                    🎙️ Native Android ব্যাকগ্রাউন্ড ও স্ক্রিন-অফ "Murad" সার্ভিস
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        if (nativeServiceOn) {
                          nativeBridge?.stopWakeService?.();
                          setNativeServiceOn(false);
                        } else {
                          nativeBridge?.startWakeService?.();
                          setNativeServiceOn(true);
                        }
                      }}
                      className={`px-2.5 py-1 rounded-lg font-semibold transition ${
                        nativeServiceOn
                          ? 'bg-emerald-600 text-white'
                          : 'bg-[#23154f] text-indigo-200 border border-indigo-400/30'
                      }`}
                    >
                      {nativeServiceOn ? 'ব্যাকগ্রাউন্ড সার্ভিস চালু (বন্ধ করুন)' : 'ব্যাকগ্রাউন্ড সার্ভিস চালু করুন'}
                    </button>
                    <button
                      type="button"
                      onClick={() => nativeBridge?.openOppoAutoLaunchSettings?.()}
                      className="px-2.5 py-1 rounded-lg bg-[#23154f] border border-sky-400/30 text-sky-200 font-medium"
                    >
                      OPPO Auto-Launch সেটিংস
                    </button>
                    <button
                      type="button"
                      onClick={() => nativeBridge?.openBatterySettings?.()}
                      className="px-2.5 py-1 rounded-lg bg-[#23154f] border border-amber-400/30 text-amber-200 font-medium"
                    >
                      ব্যাটারি অপটিমাইজেশন বন্ধ
                    </button>
                  </div>
                </div>
              )}

              <div>
                <p className="font-bold text-emerald-400">
                  ✅ এখনই Android Chrome / PWA-তে সম্ভব:
                </p>
                <p className="text-gray-300">
                  অ্যাপ খোলা থাকাকালীন শুধু “Murad” Wake Word{wakeLockActive ? ' (স্ক্রিন সজাগ রাখা সক্রিয়)' : ''}, দ্রুত বাংলা ভয়েস কথা ও পুরুষ কণ্ঠে উত্তর, ওয়েবসাইট/সার্চ, পরিচিত অ্যাপ লিংক (YouTube, WhatsApp, Facebook, Maps), অনুমতি নিয়ে ডায়ালার ও SMS ড্রাফট এবং ইন-অ্যাপ অ্যালার্ম/টাইমার।
                </p>
              </div>
              <div>
                <p className="font-bold text-amber-300">
                  📱 অ্যাপ বন্ধ বা স্ক্রিন বন্ধ রেখে “Murad” Wake Word (Native APK):
                </p>
                <p className="text-gray-300">
                  নিরাপত্তার কারণে Android Chrome বা কোনো Web App/PWA বন্ধ থাকলে কিংবা স্ক্রিন বন্ধ থাকলে মাইক্রোফোন চালু রাখতে পারে না। ব্যাকগ্রাউন্ড ও স্ক্রিন-অফ অবস্থায় শুধু “Murad” শুনে জেগে ওঠার জন্য Native Android APK প্রয়োজন—যেখানে Foreground Microphone Service, Partial WakeLock, Auto-Restart এবং OPPO A18-এ Battery Optimization বন্ধ + Auto-Launch চালু থাকে। সম্পূর্ণ Native APK প্রজেক্ট ও অটোমেটিক ক্লাউড বিল্ড সেটআপ প্রস্তুত রয়েছে (কোনো API Key ছাড়াই)।
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
