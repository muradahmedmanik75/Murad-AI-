import React from 'react';
import {
  Mic,
  MessageSquare,
  Sparkles,
  Zap,
  ArrowRight,
  ShieldCheck,
  BookOpen,
  Briefcase,
  Smartphone,
  HeartPulse,
  Feather,
  Clock,
} from 'lucide-react';
import { UserProfile, ChatMessage, ActiveTab } from '../types';

interface HomeScreenProps {
  profile: UserProfile;
  recentMessages: ChatMessage[];
  onStartVoice: () => void;
  onStartChat: (initialPrompt?: string) => void;
  onChangeTab: (tab: ActiveTab) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  profile,
  recentMessages,
  onStartVoice,
  onStartChat,
  onChangeTab,
}) => {
  // Always greet with Assalamu Alaikum as requested
  const getBengaliGreeting = () => {
    return 'আসসালামু আলাইকুম';
  };

  const quickPrompts = [
    {
      id: '1',
      title: 'স্মার্টফোন ও প্রযুক্তি',
      description: 'OPPO A18 ফোনের চার্জ ও মেমোরি ঠিক রাখার উপায়',
      prompt: 'OPPO A18 ফোনের ব্যাটারি সেভ করা ও ৪জিবি র‍্যামে সেরা স্পিড পাওয়ার জন্য কয়েকটি সহজ টিপস বাংলায় দিন।',
      icon: Smartphone,
      color: 'from-sky-500/20 to-blue-600/20 text-sky-400 border-sky-500/30',
    },
    {
      id: '2',
      title: 'দাপ্তরিক ও আনুষ্ঠানিক লেখা',
      description: 'ছুটির আবেদন বা প্রাতিষ্ঠানিক দরখাস্ত তৈরি',
      prompt: 'অফিস বা প্রতিষ্ঠানের জন্য ৩ দিনের ছুটির একটি শুদ্ধ ও সুন্দর বাংলা আবেদনপত্র খসড়া তৈরি করুন।',
      icon: Briefcase,
      color: 'from-indigo-500/20 to-purple-600/20 text-indigo-300 border-indigo-500/30',
    },
    {
      id: '3',
      title: 'শিক্ষা ও জ্ঞান',
      description: 'জটিল যেকোনো বিষয় সহজে বাংলায় ব্যাখ্যা',
      prompt: 'আর্টিফিশিয়াল ইন্টেলিজেন্স বা এআই কীভাবে কাজ করে, তা একজন সাধারণ মানুষের বোঝার মতো সহজ বাংলায় বুঝিয়ে বলুন।',
      icon: BookOpen,
      color: 'from-purple-500/20 to-pink-600/20 text-purple-300 border-purple-500/30',
    },
    {
      id: '4',
      title: 'স্বাস্থ্য ও পুষ্টি',
      description: 'সুস্থ থাকার জন্য দৈনন্দিন খাবারের তালিকা',
      prompt: 'প্রতিদিন সুস্থ ও কর্মক্ষম থাকার জন্য একটি সহজ ও পুষ্টিকর দেশীয় খাবার রুটিন পরামর্শ দিন।',
      icon: HeartPulse,
      color: 'from-rose-500/20 to-red-600/20 text-rose-300 border-rose-500/30',
    },
    {
      id: '5',
      title: 'সাহিত্য ও বিনোদন',
      description: 'ছোট গল্প, ছন্দ বা অনুপ্রেরণামূলক কবিতা',
      prompt: 'পরিশ্রম, স্বপ্ন এবং সাফল্য নিয়ে ৪ চরণের একটি অনুপ্রেরণাদায়ী সুন্দর বাংলা কবিতা লিখুন।',
      icon: Feather,
      color: 'from-amber-500/20 to-orange-600/20 text-amber-300 border-amber-500/30',
    },
    {
      id: '6',
      title: 'ব্যবসায়িক বুদ্ধি ও আইডিয়া',
      description: 'কম পুঁজিতে নতুন ব্যবসা শুরুর কার্যকর কৌশল',
      prompt: 'বাংলাদেশে স্বল্প পুঁজিতে শুরু করা যায় এমন ৩টি চমৎকার ব্যবসার আইডিয়া এবং মার্কেটিং পরিকল্পনা দিন।',
      icon: Sparkles,
      color: 'from-emerald-500/20 to-teal-600/20 text-emerald-300 border-emerald-500/30',
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto px-4 py-4 pb-24 max-w-xl mx-auto w-full space-y-5">
      {/* Welcome Greeting & User Status */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-xs font-medium text-sky-400 bg-sky-950/60 border border-sky-800/50 px-2.5 py-0.5 rounded-full inline-block mb-1.5">
            {getBengaliGreeting()}
          </span>
          <h2 className="text-xl font-bold text-white tracking-tight">
            {profile.name}
          </h2>
          <p className="text-xs text-gray-400 mt-0.5">
            মুরাদ ভাই, <span className="font-semibold"><span className="text-red-500">Murad</span> <span className="text-white">AI</span></span> আপনার সেবায় সম্পূর্ণ প্রস্তুত।
          </p>
        </div>

        {/* User Mini Avatar */}
        <button
          onClick={() => onChangeTab('profile')}
          className="relative group p-0.5 rounded-full bg-gradient-to-r from-sky-500 to-purple-600 shadow-md shadow-purple-950/50 active:scale-95 transition"
        >
          {profile.avatarUrl ? (
            <img
              src={profile.avatarUrl}
              alt={profile.name}
              className="w-12 h-12 rounded-full object-cover"
            />
          ) : (
            <div className="w-12 h-12 rounded-full bg-[#1b103e] flex items-center justify-center text-sky-300 font-bold text-sm">
              {profile.name.charAt(0) || 'মু'}
            </div>
          )}
        </button>
      </div>

      {/* Main Hero Card: Voice AI Showcase with Dark Purple/Blue Neon Glow */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#160b38] via-[#10082b] to-[#0a051d] border border-[#3b2378]/60 p-5 shadow-xl shadow-purple-950/40">
        {/* Subtle background glow orbs */}
        <div className="absolute -right-8 -top-8 w-40 h-40 bg-purple-600/15 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -left-8 -bottom-8 w-40 h-40 bg-sky-500/15 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 space-y-4">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
            <span className="text-[11px] font-semibold tracking-wider uppercase text-sky-300">
              ভয়েস ও টেক্সট সহকারী
            </span>
          </div>

          <h3 className="text-lg font-bold text-white leading-snug">
            মুখে বলুন বা বাংলায় লিখুন,
            <br />
            <span className="text-red-500">Murad</span> <span className="text-white">AI</span> সাথে সাথে দেবে উত্তর!
          </h3>

          <p className="text-xs text-indigo-200/80 leading-relaxed">
            বাংলা কণ্ঠস্বর চিনে নেওয়া এবং স্পষ্ট মিষ্টি বাংলায় কথা বলার পূর্ণ সুবিধা।
          </p>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <button
              onClick={onStartVoice}
              className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-medium text-xs shadow-lg shadow-blue-900/40 active:scale-95 transition"
            >
              <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center">
                <Mic className="w-3 h-3 text-white" />
              </div>
              <span>ভয়েসে কথা বলুন</span>
            </button>

            <button
              onClick={() => onStartChat()}
              className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-[#1c1244] hover:bg-[#251759] border border-[#3e277a] text-indigo-200 font-medium text-xs active:scale-95 transition"
            >
              <MessageSquare className="w-4 h-4 text-sky-400" />
              <span>চ্যাট শুরু করুন</span>
            </button>
          </div>
        </div>
      </div>

      {/* OPPO A18 & Lightweight Performance Optimization Badge */}
      <div className="flex items-center justify-between p-3 rounded-xl bg-[#120a2e]/70 border border-[#2b1859] text-xs">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-sky-500/10 border border-sky-500/30 text-sky-400">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <p className="font-semibold text-gray-200">OPPO A18 অপটিমাইজেশন</p>
            <p className="text-[11px] text-gray-400">৪জিবি র‍্যাম উপযোগী হালকা ও দ্রুত মেমোরি মোড</p>
          </div>
        </div>
        <div className="flex items-center gap-1 text-emerald-400 text-[11px] font-medium bg-emerald-950/60 border border-emerald-800/40 px-2 py-0.5 rounded-full">
          <ShieldCheck className="w-3 h-3" />
          <span>স্মুথ ৯০Hz</span>
        </div>
      </div>

      {/* Recent Chats Preview (if any) */}
      {recentMessages.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-sky-400" />
              <h4 className="text-xs font-bold text-gray-300">সাম্প্রতিক কথোপকথন</h4>
            </div>
            <button
              onClick={() => onChangeTab('chat')}
              className="text-[11px] text-sky-400 hover:text-sky-300 flex items-center gap-0.5"
            >
              সব দেখুন <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div
            onClick={() => onChangeTab('chat')}
            className="p-3 rounded-xl bg-[#120b2e] border border-[#2c185c] hover:border-indigo-500/50 cursor-pointer transition active:scale-[0.99] space-y-1.5"
          >
            <div className="flex items-center justify-between text-[11px] text-gray-400">
              <span className="text-sky-300 font-medium">শেষ বার্তা:</span>
              <span>{recentMessages[recentMessages.length - 1]?.timestamp}</span>
            </div>
            <p className="text-xs text-gray-200 line-clamp-2">
              {recentMessages[recentMessages.length - 1]?.content}
            </p>
          </div>
        </div>
      )}

      {/* Quick Bengali Suggestion Cards */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-gray-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            দ্রুত জানার বিষয়সমূহ
          </h4>
          <span className="text-[11px] text-gray-400">ট্যাপ করলেই উত্তর পাবেন</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {quickPrompts.map((item) => {
            const IconComponent = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => onStartChat(item.prompt)}
                className={`p-3 rounded-xl bg-[#120b2e]/90 border text-left flex flex-col justify-between hover:bg-[#19103c] transition active:scale-98 ${item.color}`}
              >
                <div className="flex items-start justify-between w-full">
                  <span className="text-xs font-bold text-gray-200">{item.title}</span>
                  <IconComponent className="w-4 h-4 shrink-0" />
                </div>
                <p className="text-[11px] text-gray-400 mt-1 line-clamp-2 leading-relaxed">
                  {item.description}
                </p>
                <div className="mt-2.5 flex items-center gap-1 text-[10px] text-sky-400 font-medium">
                  <span>জিজ্ঞাসা করুন</span>
                  <ArrowRight className="w-2.5 h-2.5" />
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
