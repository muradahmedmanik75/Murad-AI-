import React from 'react';
import { Home, MessageSquare, Mic, User } from 'lucide-react';
import { ActiveTab, UserProfile } from '../types';

interface BottomNavProps {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
  profile: UserProfile;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  profile,
}) => {
  const handleTabClick = (tab: ActiveTab) => {
    if (typeof window !== 'undefined' && window.navigator && 'vibrate' in window.navigator) {
      try {
        window.navigator.vibrate(10);
      } catch (_) {}
    }
    onChangeTab(tab);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0d0724]/90 backdrop-blur-lg border-t border-[#26164f] pb-safe">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-around">
        {/* হোম (Home) */}
        <button
          onClick={() => handleTabClick('home')}
          className={`flex flex-col items-center justify-center w-16 py-1 transition-all ${
            activeTab === 'home'
              ? 'text-sky-400 font-semibold'
              : 'text-gray-400 hover:text-gray-200'
          }`}
        >
          <Home className={`w-5 h-5 transition-transform ${activeTab === 'home' ? 'scale-110' : ''}`} />
          <span className="text-[11px] mt-1">হোম</span>
        </button>

        {/* চ্যাট (Chat) */}
        <button
          onClick={() => handleTabClick('chat')}
          className={`flex flex-col items-center justify-center w-16 py-1 transition-all ${
            activeTab === 'chat'
              ? 'text-indigo-400 font-semibold'
              : 'text-gray-400 hover:text-gray-200'
          }`}
        >
          <MessageSquare className={`w-5 h-5 transition-transform ${activeTab === 'chat' ? 'scale-110' : ''}`} />
          <span className="text-[11px] mt-1">চ্যাট</span>
        </button>

        {/* ভয়েস (Voice - Center highlight) */}
        <button
          onClick={() => handleTabClick('voice')}
          className="relative -top-3 flex flex-col items-center justify-center group focus:outline-none"
        >
          <div
            className={`w-13 h-13 rounded-full flex items-center justify-center shadow-lg transition-all ${
              activeTab === 'voice'
                ? 'bg-gradient-to-tr from-sky-400 via-indigo-500 to-purple-600 text-white shadow-indigo-500/50 scale-105'
                : 'bg-gradient-to-tr from-indigo-700 to-purple-800 text-sky-200 shadow-purple-950/60 group-hover:scale-105'
            }`}
          >
            <Mic className="w-6 h-6 animate-pulse" />
          </div>
          <span
            className={`text-[11px] mt-0.5 font-medium ${
              activeTab === 'voice' ? 'text-sky-300 font-bold' : 'text-gray-400'
            }`}
          >
            ভয়েস
          </span>
        </button>

        {/* প্রোফাইল (Profile) */}
        <button
          onClick={() => handleTabClick('profile')}
          className={`flex flex-col items-center justify-center w-16 py-1 transition-all ${
            activeTab === 'profile'
              ? 'text-purple-400 font-semibold'
              : 'text-gray-400 hover:text-gray-200'
          }`}
        >
          {profile.avatarUrl ? (
            <div
              className={`w-6 h-6 rounded-full overflow-hidden border ${
                activeTab === 'profile' ? 'border-purple-400 ring-2 ring-purple-500/30' : 'border-gray-500'
              }`}
            >
              <img
                src={profile.avatarUrl}
                alt={profile.name}
                className="w-full h-full object-cover"
              />
            </div>
          ) : (
            <User className={`w-5 h-5 transition-transform ${activeTab === 'profile' ? 'scale-110' : ''}`} />
          )}
          <span className="text-[11px] mt-1">প্রোফাইল</span>
        </button>
      </div>
    </nav>
  );
};
