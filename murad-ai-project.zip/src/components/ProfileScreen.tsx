import React, { useState, useRef } from 'react';
import {
  Camera,
  ImagePlus,
  Trash2,
  Save,
  CheckCircle2,
  Volume2,
  Smartphone,
  Download,
  Radio,
  UserPlus,
  X,
  FolderArchive,
} from 'lucide-react';
import { UserProfile, AITone, QuickContact } from '../types';
import { compressAvatarImage } from '../utils/storage';
import { normalizePhoneNumber } from '../utils/assistantActions';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface ProfileScreenProps {
  profile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
  onClearHistory: () => void;
  onTestVoice: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  profile,
  onUpdateProfile,
  onClearHistory,
  onTestVoice,
}) => {
  const [name, setName] = useState(profile.name);
  const [bio, setBio] = useState(profile.bio);
  const [voiceSpeed, setVoiceSpeed] = useState(profile.voiceSpeed);
  const [autoSpeakVoice, setAutoSpeakVoice] = useState(profile.autoSpeakVoice);
  const [wakeWordEnabled, setWakeWordEnabled] = useState(profile.wakeWordEnabled ?? true);
  const [alwaysReadyVoice, setAlwaysReadyVoice] = useState(profile.alwaysReadyVoice ?? true);
  const [quickContacts, setQuickContacts] = useState<QuickContact[]>(profile.quickContacts || []);
  const [newContactName, setNewContactName] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [aiTone, setAiTone] = useState<AITone>(profile.aiTone);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [zipError, setZipError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const { isInstallable, isInstalled, install, isIOS } = usePWAInstall();

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploadError(null);
      setIsUploading(true);
      // Center-crop and compress to 280x280 JPEG for ultra-light memory on OPPO A18 (4GB RAM)
      const compressedDataUrl = await compressAvatarImage(file);
      const updated = { ...profile, avatarUrl: compressedDataUrl };
      onUpdateProfile(updated);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } catch (err: any) {
      setUploadError(
        err?.message || 'ছবি আপলোড করতে ব্যর্থ হয়েছে। অনুগ্রহ করে অন্য ছবি নির্বাচন করুন।'
      );
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
      if (cameraInputRef.current) cameraInputRef.current.value = '';
    }
  };

  const handleRemovePhoto = () => {
    setUploadError(null);
    const updated = { ...profile, avatarUrl: '' };
    onUpdateProfile(updated);
  };

  const handleAddQuickContact = () => {
    const cleanName = newContactName.trim();
    const cleanPhone = normalizePhoneNumber(newContactPhone);
    if (!cleanName || !cleanPhone) return;

    const updatedContacts = [
      ...quickContacts,
      { id: `c-${Date.now()}`, name: cleanName, phone: cleanPhone },
    ].slice(0, 12);

    setQuickContacts(updatedContacts);
    setNewContactName('');
    setNewContactPhone('');
    onUpdateProfile({
      ...profile,
      quickContacts: updatedContacts,
    });
  };

  const handleRemoveQuickContact = (id: string) => {
    const updatedContacts = quickContacts.filter((c) => c.id !== id);
    setQuickContacts(updatedContacts);
    onUpdateProfile({
      ...profile,
      quickContacts: updatedContacts,
    });
  };

  const handleDownloadProjectZip = async () => {
    if (isDownloadingZip) return;
    setZipError(null);
    setIsDownloadingZip(true);
    try {
      const response = await fetch('/api/download-project-zip');
      if (!response.ok) {
        throw new Error('ZIP ডাউনলোড ব্যর্থ হয়েছে।');
      }
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = blobUrl;
      anchor.download = 'murad-ai-project.zip';
      anchor.style.display = 'none';
      document.body.appendChild(anchor);
      anchor.click();
      window.setTimeout(() => {
        try {
          document.body.removeChild(anchor);
          URL.revokeObjectURL(blobUrl);
        } catch (_) {}
      }, 1000);
    } catch (err: any) {
      setZipError(err?.message || 'প্রজেক্ট ZIP ডাউনলোড করা যায়নি। আবার চেষ্টা করুন।');
    } finally {
      setIsDownloadingZip(false);
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...profile,
      name: name.trim() || 'মোঃ মুরাদ সিদ্দিকী',
      bio: bio.trim(),
      voiceSpeed,
      autoSpeakVoice,
      wakeWordEnabled,
      alwaysReadyVoice,
      quickContacts,
      aiTone,
    };
    onUpdateProfile(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-4 pb-24 max-w-xl mx-auto w-full space-y-5">
      {/* Profile Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">আপনার প্রোফাইল</h2>
          <p className="text-xs text-gray-400 mt-0.5">
            <span className="font-semibold text-red-500">Murad</span>{' '}
            <span className="font-semibold text-white">AI</span>-এর সাথে আপনার ব্যক্তিগত তথ্য ও সেটিংস
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs animate-bounce">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>সংরক্ষিত হয়েছে!</span>
          </div>
        )}
      </div>

      {/* Avatar Upload Card */}
      <div className="p-5 rounded-2xl bg-[#140c33] border border-[#351e6b] shadow-xl text-center space-y-4">
        <div className="relative inline-block mx-auto">
          {/* Glowing Avatar Frame */}
          <div className="w-28 h-28 rounded-full p-[3px] bg-gradient-to-tr from-sky-400 via-indigo-500 to-purple-600 shadow-xl shadow-purple-950/80">
            <div className="w-full h-full rounded-full bg-[#1b103e] overflow-hidden flex items-center justify-center">
              {profile.avatarUrl ? (
                <img
                  src={profile.avatarUrl}
                  alt={profile.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="flex flex-col items-center justify-center text-indigo-300">
                  <span className="text-2xl font-bold">
                    {profile.name.charAt(0) || 'মু'}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Upload Button Badge */}
          <button
            type="button"
            disabled={isUploading}
            onClick={() => fileInputRef.current?.click()}
            className="absolute bottom-0 right-0 p-2.5 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-lg shadow-blue-950/80 border-2 border-[#140c33] active:scale-90 transition"
            title="ছবি আপলোড বা পরিবর্তন করুন"
          >
            <Camera className="w-4 h-4" />
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handlePhotoUpload}
            className="hidden"
          />
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="user"
            onChange={handlePhotoUpload}
            className="hidden"
          />
        </div>

        <div>
          <h3 className="text-base font-bold text-white">{name || 'মোঃ মুরাদ সিদ্দিকী'}</h3>
          <p className="text-xs text-indigo-300 mt-0.5">
            {bio || (
              <>
                <span className="font-semibold text-red-500">Murad</span>{' '}
                <span className="font-semibold text-white">AI</span> ব্যবহারকারী
              </>
            )}
          </p>
        </div>

        {uploadError && (
          <p className="text-xs text-rose-300 bg-rose-950/50 border border-rose-800/40 rounded-lg px-3 py-1.5">
            {uploadError}
          </p>
        )}

        <div className="flex flex-wrap justify-center gap-2">
          <button
            type="button"
            disabled={isUploading}
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-xs font-medium shadow-md shadow-blue-900/40 hover:from-blue-500 hover:to-indigo-500 active:scale-95 transition disabled:opacity-60"
          >
            <ImagePlus className="w-3.5 h-3.5" />
            <span>{isUploading ? 'প্রসেসিং হচ্ছে...' : 'গ্যালারি থেকে ছবি'}</span>
          </button>

          <button
            type="button"
            disabled={isUploading}
            onClick={() => cameraInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#1f134b] border border-[#3d257a] text-indigo-200 text-xs font-medium hover:bg-[#28195e] active:scale-95 transition disabled:opacity-60"
          >
            <Camera className="w-3.5 h-3.5 text-sky-400" />
            <span>ক্যামেরায় তুলুন</span>
          </button>

          {profile.avatarUrl && (
            <button
              type="button"
              onClick={handleRemovePhoto}
              className="px-3 py-1.5 rounded-xl bg-[#201249] text-rose-300 hover:text-rose-200 border border-rose-900/40 text-xs font-medium active:scale-95 transition"
            >
              ছবি মুছুন
            </button>
          )}
        </div>
      </div>

      {/* Edit Form */}
      <form onSubmit={handleSaveProfile} className="space-y-4">
        {/* Name Input */}
        <div className="p-4 rounded-xl bg-[#120a2e] border border-[#2b1759] space-y-1.5">
          <label className="text-xs font-bold text-gray-200 block">
            আপনার নাম
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="আপনার নাম লিখুন..."
            className="w-full bg-[#1b103e] border border-[#3b2377] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-sky-400 font-sans"
          />
          <p className="text-[11px] text-gray-400">
            <span className="font-medium text-red-500">Murad</span>{' '}
            <span className="font-medium text-white">AI</span> কথা বলার সময় এই নামে আপনাকে সম্মান জানাবে।
          </p>
        </div>

        {/* Bio Input */}
        <div className="p-4 rounded-xl bg-[#120a2e] border border-[#2b1759] space-y-1.5">
          <label className="text-xs font-bold text-gray-200 block">
            পেশা বা পরিচয়
          </label>
          <input
            type="text"
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            placeholder="যেমন: উদ্যোক্তা, শিক্ষার্থী, ব্যবসায়ী..."
            className="w-full bg-[#1b103e] border border-[#3b2377] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-sky-400 font-sans"
          />
        </div>

        {/* AI Personality Selector */}
        <div className="p-4 rounded-xl bg-[#120a2e] border border-[#2b1759] space-y-2.5">
          <label className="text-xs font-bold text-gray-200 block">
            <span className="text-red-500">Murad</span>{' '}
            <span className="text-white">AI</span>-এর বাচনভঙ্গি নির্বাচন করুন
          </label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'friendly', title: 'বন্ধুসুলভ ও আন্তরিক', desc: 'সহজ, মিষ্টি ও বন্ধুত্বপূর্ণ' },
              { id: 'formal', title: 'প্রাতিষ্ঠানিক ও বিজ্ঞ', desc: 'গম্ভীর ও সুশৃঙ্খল বিশ্লেষণ' },
              { id: 'academic', title: 'শিক্ষক ও নির্দেশক', desc: 'বিস্তারিত ব্যাখ্যামূলক' },
              { id: 'creative', title: 'সৃজনশীল চিন্তাবিদ', desc: 'নতুন আইডিয়া ও সাহিত্যিক' },
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setAiTone(t.id as AITone)}
                className={`p-2.5 rounded-xl border text-left transition active:scale-98 ${
                  aiTone === t.id
                    ? 'bg-gradient-to-br from-indigo-950/80 to-purple-950/80 border-sky-400/80 shadow-md ring-1 ring-sky-400/40'
                    : 'bg-[#180e3c] border-[#301a61] text-gray-300 hover:bg-[#1f134c]'
                }`}
              >
                <p className="text-xs font-bold text-white">{t.title}</p>
                <p className="text-[10px] text-gray-400 mt-0.5">{t.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Bengali Voice Settings */}
        <div className="p-4 rounded-xl bg-[#120a2e] border border-[#2b1759] space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-gray-200 flex items-center gap-1.5">
              <Volume2 className="w-3.5 h-3.5 text-sky-400" />
              বাংলা কণ্ঠস্বর সেটিংস
            </label>
            <button
              type="button"
              onClick={onTestVoice}
              className="text-[11px] text-sky-400 hover:text-sky-300 font-medium"
            >
              কণ্ঠ পরীক্ষা করুন 🔊
            </button>
          </div>

          {/* Voice Speed Slider */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-gray-300">
              <span>কথা বলার গতি:</span>
              <span className="font-semibold text-sky-300">
                {voiceSpeed === 0.8 ? 'ধীর (০.৮x)' : voiceSpeed === 1.2 ? 'দ্রুত (১.২x)' : 'স্বাভাবিক (১.০x)'}
              </span>
            </div>
            <input
              type="range"
              min="0.8"
              max="1.2"
              step="0.2"
              value={voiceSpeed}
              onChange={(e) => setVoiceSpeed(parseFloat(e.target.value))}
              className="w-full accent-sky-400 h-1.5 bg-[#26154e] rounded-lg cursor-pointer"
            />
          </div>

          {/* Auto Speak Toggle */}
          <div className="flex items-center justify-between pt-1">
            <div>
              <p className="text-xs font-medium text-gray-200">স্বয়ংক্রিয় ভয়েস উত্তর</p>
              <p className="text-[11px] text-gray-400">উত্তর আসার সাথে সাথে পড়ে শোনানো</p>
            </div>
            <button
              type="button"
              onClick={() => setAutoSpeakVoice(!autoSpeakVoice)}
              className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                autoSpeakVoice ? 'bg-sky-500' : 'bg-[#291752]'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  autoSpeakVoice ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Voice Assistant & Quick Contacts Card */}
        <div className="p-4 rounded-xl bg-[#120a2e] border border-[#2b1759] space-y-3">
          <div className="flex items-center gap-1.5 text-xs font-bold text-gray-200">
            <Radio className="w-3.5 h-3.5 text-emerald-400" />
            <span>Personal Voice Assistant ও দ্রুত কন্টাক্ট</span>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-gray-200">সবসময় কথা শোনার জন্য প্রস্তুত</p>
              <p className="text-[11px] text-gray-400">অ্যাপ খোলা থাকাকালীন উত্তর শেষে আবার শুনবে</p>
            </div>
            <button
              type="button"
              onClick={() => setAlwaysReadyVoice(!alwaysReadyVoice)}
              className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                alwaysReadyVoice ? 'bg-emerald-500' : 'bg-[#291752]'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  alwaysReadyVoice ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-gray-200">Wake Word ("Murad")</p>
              <p className="text-[11px] text-gray-400">শুধু "Murad" বললেই অ্যাসিস্ট্যান্ট জেগে উঠবে</p>
            </div>
            <button
              type="button"
              onClick={() => setWakeWordEnabled(!wakeWordEnabled)}
              className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                wakeWordEnabled ? 'bg-sky-500' : 'bg-[#291752]'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  wakeWordEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Local Quick Contacts for Voice Call / SMS */}
          <div className="pt-2 border-t border-[#25154e] space-y-2">
            <p className="text-[11px] font-semibold text-indigo-200">
              দ্রুত কন্টাক্ট (নাম ধরে কল বা SMS-এর জন্য)
            </p>
            <div className="flex gap-1.5">
              <input
                type="text"
                value={newContactName}
                onChange={(e) => setNewContactName(e.target.value)}
                placeholder="নাম (যেমন: আম্মু)"
                className="w-1/3 bg-[#1b103e] border border-[#3b2377] rounded-lg px-2.5 py-1.5 text-[11px] text-white placeholder-gray-500 focus:outline-none focus:border-sky-400"
              />
              <input
                type="tel"
                value={newContactPhone}
                onChange={(e) => setNewContactPhone(e.target.value)}
                placeholder="ফোন নম্বর (017...)"
                className="flex-1 bg-[#1b103e] border border-[#3b2377] rounded-lg px-2.5 py-1.5 text-[11px] text-white placeholder-gray-500 focus:outline-none focus:border-sky-400"
              />
              <button
                type="button"
                onClick={handleAddQuickContact}
                className="px-2.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-semibold flex items-center gap-1 shrink-0"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>যোগ</span>
              </button>
            </div>

            {quickContacts.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {quickContacts.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#1b103e] border border-[#3a2376] text-[11px] text-indigo-100"
                  >
                    <span>
                      {c.name}: {c.phone}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleRemoveQuickContact(c.id)}
                      className="text-rose-300 hover:text-rose-200"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Save Button */}
        <button
          type="submit"
          className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold text-xs shadow-lg shadow-blue-900/40 active:scale-95 transition flex items-center justify-center gap-2"
        >
          <Save className="w-4 h-4" />
          <span>প্রোফাইল সংরক্ষণ করুন</span>
        </button>
      </form>

      {/* PWA Android Install Guide Card */}
      <div className="p-4 rounded-xl bg-gradient-to-br from-[#160c38] to-[#10072a] border border-[#372070] space-y-3">
        <div className="flex items-center gap-2 text-sky-400">
          <Download className="w-4 h-4" />
          <h4 className="text-xs font-bold text-white">
            অ্যান্ড্রয়েড ফোনে অ্যাপ হিসেবে ইনস্টল করুন
          </h4>
        </div>
        <p className="text-xs text-gray-300 leading-relaxed">
          <span className="font-semibold text-red-500">Murad</span>{' '}
          <span className="font-semibold text-white">AI</span> একটি আধুনিক প্রগ্রেসিভ ওয়েব অ্যাপ (PWA)। ক্রোম বা ব্রাউজারের মাধ্যমে সরাসরি ফোনে ইনস্টল করে অ্যাপের মতো ব্যবহার করতে পারবেন।
        </p>

        {isInstallable ? (
          <button
            onClick={() => install()}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white text-xs font-bold shadow-md shadow-sky-900/40 active:scale-95 transition"
          >
            📲 ফোনে ইনস্টল করুন
          </button>
        ) : isInstalled ? (
          <div className="flex items-center justify-center gap-1.5 p-2 rounded-xl bg-emerald-950/60 border border-emerald-800/40 text-emerald-300 text-xs">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>অ্যাপটি ইতিমধ্যে ইনস্টল করা আছে</span>
          </div>
        ) : isIOS ? (
          <p className="text-[11px] text-gray-400">
            আইফোনে Safari এর Share আইকনে ট্যাপ করে 'Add to Home Screen' বেছে নিন।
          </p>
        ) : (
          <div className="text-[11px] text-gray-400 bg-[#1b103e] p-2.5 rounded-lg border border-[#331c6b] space-y-1">
            <p className="font-semibold text-gray-300">ইনস্টল করার সহজ নিয়ম:</p>
            <p>১. ক্রোমের উপরে ৩টি ডট (মেনু) বাটনে চাপুন।</p>
            <p>২. "Install app" বা "Add to Home screen" নির্বাচন করুন।</p>
          </div>
        )}
      </div>

      {/* Complete Project ZIP Download Card (GitHub & Native APK) */}
      <div className="p-4 rounded-xl bg-gradient-to-br from-[#160c38] to-[#10072a] border border-[#372070] space-y-3">
        <div className="flex items-center gap-2 text-emerald-400">
          <FolderArchive className="w-4 h-4" />
          <h4 className="text-xs font-bold text-white">
            সম্পূর্ণ প্রজেক্ট ZIP ডাউনলোড (GitHub / APK)
          </h4>
        </div>
        <p className="text-xs text-gray-300 leading-relaxed">
          <span className="font-semibold text-red-500">Murad</span>{' '}
          <span className="font-semibold text-white">AI</span>-এর সম্পূর্ণ ওয়েব ও Native Android প্রজেক্ট (গোপন API Key ছাড়াই নিরাপদ) এক ক্লিকে ZIP ফাইল হিসেবে ডাউনলোড করে GitHub-এ আপলোড বা APK বিল্ড করতে পারবেন।
        </p>

        {zipError && (
          <p className="text-[11px] text-rose-300 bg-rose-950/50 border border-rose-800/40 rounded-lg px-2.5 py-1.5">
            {zipError}
          </p>
        )}

        <button
          type="button"
          onClick={handleDownloadProjectZip}
          disabled={isDownloadingZip}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-md shadow-emerald-950/40 active:scale-95 transition flex items-center justify-center gap-2 disabled:opacity-60"
        >
          <FolderArchive className="w-4 h-4" />
          <span>
            {isDownloadingZip
              ? 'ZIP ফাইল তৈরি ও ডাউনলোড হচ্ছে...'
              : 'প্রজেক্ট ZIP ডাউনলোড করুন (murad-ai-project.zip)'}
          </span>
        </button>
      </div>

      {/* OPPO A18 Specs & Storage Cleanup */}
      <div className="p-4 rounded-xl bg-[#120a2e] border border-[#2b1759] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-indigo-300">
            <Smartphone className="w-4 h-4 text-sky-400" />
            <h4 className="text-xs font-bold text-gray-200">OPPO A18 অপটিমাইজেশন</h4>
          </div>
          <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-2 py-0.5 rounded-full">
            ৪জিবি র‍্যাম মোড সক্রিয়
          </span>
        </div>

        <p className="text-[11px] text-gray-400 leading-relaxed">
          লো-মেমোরি ফিচার নিশ্চিত করে যে আপনার OPPO A18 ফোনে অ্যাপটি সবসময় হালকা থাকবে এবং ব্যাটারি খরচ কম করবে।
        </p>

        <button
          type="button"
          onClick={() => setShowClearConfirm(true)}
          className="w-full py-2.5 rounded-xl bg-[#201040] hover:bg-[#2b1555] border border-rose-900/40 text-rose-300 text-xs font-medium flex items-center justify-center gap-2 active:scale-95 transition"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>সমস্ত চ্যাট হিস্ট্রি মুছে মেমোরি খালি করুন</span>
        </button>
      </div>

      {/* Clear Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-[#150c33] border border-[#3c2475] rounded-2xl p-5 max-w-xs w-full text-center space-y-3 shadow-2xl">
            <h3 className="text-sm font-bold text-white">মেমোরি খালি করতে চান?</h3>
            <p className="text-xs text-gray-300">
              সমস্ত পূর্বের চ্যাট রেকর্ড মুছে ফেলা হবে।
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-2 text-xs rounded-xl bg-[#20134b] text-gray-300"
              >
                বাতিল
              </button>
              <button
                onClick={() => {
                  onClearHistory();
                  setShowClearConfirm(false);
                }}
                className="flex-1 py-2 text-xs rounded-xl bg-rose-600 text-white font-medium"
              >
                মুছুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
