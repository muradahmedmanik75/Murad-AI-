import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Copy,
  Check,
  Trash2,
  Sparkles,
  RefreshCw,
  ShieldAlert,
  ExternalLink,
  X,
} from 'lucide-react';
import { AssistantAction, ChatMessage, UserProfile } from '../types';
import { useSpeechRecognition } from '../hooks/useSpeechRecognition';

interface ChatScreenProps {
  messages: ChatMessage[];
  isLoading: boolean;
  onSendMessage: (text: string, isVoicePrompt?: boolean) => void;
  onRetryMessage: (errorMessageId: string, retryText: string, isVoicePrompt?: boolean) => void;
  onClearChat: () => void;
  onExecuteAction?: (action: AssistantAction) => { executed: boolean; feedback: string };
  profile: UserProfile;
  speak: (text: string, messageId?: string) => void;
  stopSpeaking: () => void;
  unlockAudio?: () => void;
  isSpeaking: boolean;
  activeSpeakingId: string | null;
}

export const ChatScreen: React.FC<ChatScreenProps> = ({
  messages,
  isLoading,
  onSendMessage,
  onRetryMessage,
  onClearChat,
  onExecuteAction,
  profile,
  speak,
  stopSpeaking,
  unlockAudio,
  isSpeaking,
  activeSpeakingId,
}) => {
  const [inputText, setInputText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [actionStates, setActionStates] = useState<Record<string, 'approved' | 'cancelled'>>({});
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Bengali Speech recognition for the microphone button (auto-sends to chat when speech ends)
  const {
    isListening,
    isTranscribing,
    transcript,
    interimTranscript,
    error: micError,
    permissionBlocked,
    startListening,
    stopListening,
    resetTranscript,
  } = useSpeechRecognition(undefined, (autoFinalText) => {
    const clean = autoFinalText.trim();
    if (!clean) return;
    if (isLoading) {
      setInputText((prev) => (prev ? `${prev} ${clean}` : clean));
      resetTranscript();
      return;
    }
    unlockAudio?.();
    resetTranscript();
    setInputText('');
    onSendMessage(clean, true);
  });

  // Update input text if transcript arrives while loading or after error
  useEffect(() => {
    if (transcript && !isListening && !isTranscribing) {
      setInputText((prev) => (prev ? `${prev} ${transcript}` : transcript));
      resetTranscript();
    }
  }, [transcript, isListening, isTranscribing, resetTranscript]);

  // Auto-scroll to bottom
  const scrollToBottom = (smooth = true) => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({
        behavior: smooth ? 'smooth' : 'auto',
      });
    }
  };

  useEffect(() => {
    scrollToBottom(true);
  }, [messages, isLoading]);

  const handleSend = () => {
    const trimmed = inputText.trim();
    if (!trimmed || isLoading) return;

    unlockAudio?.();
    if (isListening) {
      stopListening();
    }

    onSendMessage(trimmed);
    setInputText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => {
      setCopiedId(null);
    }, 2000);
  };

  const handleToggleVoiceInput = async () => {
    unlockAudio?.();
    if (isListening) {
      const spoken = await stopListening();
      const combined = (spoken || transcript || interimTranscript).trim();
      if (combined && !isLoading) {
        resetTranscript();
        setInputText('');
        onSendMessage(combined, true);
      }
    } else {
      stopSpeaking();
      resetTranscript();
      startListening();
    }
  };

  const quickFollowUps = [
    'সহজ ভাষায় ব্যাখ্যা করুন',
    'সংক্ষেপে বুলেট পয়েন্ট দিন',
    'আরো বিস্তারিত উদাহরণ দিন',
  ];

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-4rem)] max-w-xl mx-auto w-full">
      {/* Chat Top Sub-bar */}
      <div className="px-4 py-2 border-b border-[#211445] bg-[#0c0721]/60 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 text-indigo-300">
          <Sparkles className="w-3.5 h-3.5 text-sky-400" />
          <span>
            <span className="font-bold text-red-500">Murad</span>{' '}
            <span className="font-bold text-white">AI</span> চ্যাট সহায়ক
          </span>
        </div>

        {messages.length > 0 && (
          <button
            onClick={() => setShowClearConfirm(true)}
            className="flex items-center gap-1 text-gray-400 hover:text-rose-400 active:scale-95 transition"
            title="চ্যাট মুছুন"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="text-[11px]">পরিষ্কার করুন</span>
          </button>
        )}
      </div>

      {/* Clear Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-[#150c33] border border-[#3c2475] rounded-2xl p-5 max-w-xs w-full text-center space-y-3 shadow-2xl">
            <h3 className="text-sm font-bold text-white">সব চ্যাট মুছে ফেলতে চান?</h3>
            <p className="text-xs text-gray-300">
              সমস্ত আগের বার্তা মুছে যাবে। এটি আর ফিরিয়ে আনা যাবে না।
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-2 text-xs rounded-xl bg-[#20134b] text-gray-300 hover:bg-[#28185d]"
              >
                বাতিল
              </button>
              <button
                onClick={() => {
                  onClearChat();
                  setShowClearConfirm(false);
                }}
                className="flex-1 py-2 text-xs rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-medium"
              >
                মুছে ফেলুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Message List */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3 my-auto">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-sky-500/20 via-indigo-600/30 to-purple-600/20 border border-indigo-500/30 flex items-center justify-center overflow-hidden shadow-lg shadow-purple-950/40">
              <img src="/icon.svg" alt="Murad AI" className="w-14 h-14 object-contain" />
            </div>
            <h3 className="text-base font-bold text-white">
              আসসালামু আলাইকুম, মুরাদ ভাই!
            </h3>
            <p className="text-xs text-gray-400 max-w-xs leading-relaxed">
              আমি <span className="font-semibold"><span className="text-red-500">Murad</span> <span className="text-white">AI</span></span>। যেকোনো প্রশ্ন লিখে পাঠান অথবা নিচের মাইক্রোফোন বাটনে ট্যাপ করে মুখে বাংলায় বলুন।
            </p>
            <div className="flex flex-wrap gap-2 justify-center pt-2">
              {[
                'আজকের একটি ভালো উক্তি বলুন',
                'স্মার্টফোন ফাস্ট রাখার উপায় কী?',
                'একটি অনুপ্রেরণাদায়ী ছোট গল্প বলুন',
              ].map((suggestion, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    unlockAudio?.();
                    onSendMessage(suggestion);
                  }}
                  className="px-3 py-1.5 rounded-full bg-[#180e3d] border border-[#331d6d] text-indigo-200 text-xs hover:border-sky-400/50 transition active:scale-95"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.role === 'user';
            const isThisSpeaking = isSpeaking && activeSpeakingId === msg.id;

            return (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {/* Assistant Avatar */}
                {!isUser && (
                  <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-sky-500 to-indigo-600 p-[1px] shrink-0 mt-1 shadow-sm">
                    <div className="w-full h-full bg-[#12082f] rounded-[7px] flex items-center justify-center">
                      <img src="/icon.svg" alt="Murad AI" className="w-5 h-5 object-contain rounded" />
                    </div>
                  </div>
                )}

                {/* Message Bubble Container */}
                <div
                  className={`relative max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed shadow-md ${
                    isUser
                      ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white rounded-tr-xs shadow-blue-950/40'
                      : 'bg-[#150d36] border border-[#2e1a63] text-gray-100 rounded-tl-xs shadow-purple-950/40'
                  }`}
                >
                  {/* Message Content */}
                  <div className="whitespace-pre-wrap break-words font-normal selection:bg-indigo-500 selection:text-white">
                    {msg.content}
                  </div>

                  {/* Native Note if action needs Native Android App */}
                  {!isUser && msg.action?.nativeNote && (
                    <p className="mt-2 text-[11px] text-amber-300/90 bg-amber-950/40 border border-amber-500/20 rounded-lg px-2.5 py-1.5">
                      ℹ️ {msg.action.nativeNote}
                    </p>
                  )}

                  {/* Permission Confirmation Bar for Assistant Actions */}
                  {!isUser && msg.action?.requiresConfirmation && onExecuteAction && (
                    <div className="mt-2.5 p-2.5 rounded-xl bg-[#1c1046] border border-amber-400/40 space-y-2">
                      {actionStates[msg.id] === 'approved' ? (
                        <p className="text-[11px] text-emerald-300 font-medium flex items-center gap-1">
                          <Check className="w-3.5 h-3.5" />
                          <span>অনুমতি দেওয়া হয়েছে ও কাজ শুরু হয়েছে।</span>
                        </p>
                      ) : actionStates[msg.id] === 'cancelled' ? (
                        <p className="text-[11px] text-gray-400">বাতিল করা হয়েছে।</p>
                      ) : (
                        <>
                          <p className="text-[11px] text-amber-200 flex items-center gap-1 font-semibold">
                            <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                            <span>
                              {msg.action.confirmationReason || 'কাজটি সম্পন্ন করতে অনুমতি দিন:'}
                            </span>
                          </p>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                unlockAudio?.();
                                setActionStates((prev) => ({ ...prev, [msg.id]: 'approved' }));
                                const res = onExecuteAction(msg.action!);
                                if (res.feedback) {
                                  speak(res.feedback);
                                }
                              }}
                              className="flex-1 py-1.5 px-2.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-[11px] font-bold flex items-center justify-center gap-1 active:scale-95 transition"
                            >
                              <ExternalLink className="w-3 h-3" />
                              <span>অনুমতি দিন</span>
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setActionStates((prev) => ({ ...prev, [msg.id]: 'cancelled' }))
                              }
                              className="px-2.5 py-1.5 rounded-lg bg-[#27175c] text-rose-200 text-[11px] font-medium flex items-center gap-1 active:scale-95 transition"
                            >
                              <X className="w-3 h-3" />
                              <span>বাতিল</span>
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  )}

                  {/* Retry Button for Failed Responses */}
                  {!isUser && msg.isError && msg.retryText && (
                    <button
                      type="button"
                      disabled={isLoading}
                      onClick={() => {
                        unlockAudio?.();
                        onRetryMessage(msg.id, msg.retryText!, msg.isVoicePrompt);
                      }}
                      className="mt-2.5 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-[11px] font-medium shadow-md shadow-blue-950/40 active:scale-95 transition disabled:opacity-50"
                    >
                      <RefreshCw className={`w-3 h-3 ${isLoading ? 'animate-spin' : ''}`} />
                      <span>আবার চেষ্টা করুন</span>
                    </button>
                  )}

                  {/* Bubble Footer Actions */}
                  <div className="mt-2 pt-1 border-t border-white/10 flex items-center justify-between gap-3 text-[10px] text-gray-400">
                    <span className="opacity-80">{msg.timestamp}</span>

                    {/* Actions for Assistant Message */}
                    {!isUser && (
                      <div className="flex items-center gap-1.5">
                        {/* Bengali Voice Speak Button */}
                        <button
                          onClick={() => {
                            unlockAudio?.();
                            if (isThisSpeaking) {
                              stopSpeaking();
                            } else {
                              speak(msg.content, msg.id);
                            }
                          }}
                          className={`p-1 rounded-md transition ${
                            isThisSpeaking
                              ? 'bg-sky-500/30 text-sky-300'
                              : 'hover:bg-white/10 text-gray-400 hover:text-sky-300'
                          }`}
                          title={isThisSpeaking ? 'ভয়েস থামান' : 'বাংলায় শুনুন'}
                        >
                          {isThisSpeaking ? (
                            <VolumeX className="w-3.5 h-3.5 text-sky-400 animate-pulse" />
                          ) : (
                            <Volume2 className="w-3.5 h-3.5" />
                          )}
                        </button>

                        {/* Copy Button */}
                        <button
                          onClick={() => handleCopy(msg.id, msg.content)}
                          className="p-1 rounded-md hover:bg-white/10 text-gray-400 hover:text-gray-200 transition"
                          title="কপি করুন"
                        >
                          {copiedId === msg.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* User Avatar */}
                {isUser && (
                  <div className="w-7 h-7 rounded-lg overflow-hidden shrink-0 mt-1 border border-indigo-400/40">
                    {profile.avatarUrl ? (
                      <img
                        src={profile.avatarUrl}
                        alt={profile.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-[#1e1047] flex items-center justify-center text-[10px] font-bold text-sky-300">
                        {profile.name.charAt(0) || 'মু'}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}

        {/* Loading / Generating State */}
        {isLoading && (
          <div className="flex gap-2.5 justify-start">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-sky-500 to-indigo-600 p-[1px] shrink-0">
              <div className="w-full h-full bg-[#12082f] rounded-[7px] flex items-center justify-center">
                <img src="/icon.svg" alt="Murad AI" className="w-5 h-5 object-contain animate-spin" />
              </div>
            </div>
            <div className="bg-[#150d36] border border-[#2e1a63] rounded-2xl rounded-tl-xs px-4 py-3 text-xs text-sky-300 flex items-center gap-2 shadow-md">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-sky-400" />
              <span>
                <span className="font-semibold text-red-500">Murad</span>{' '}
                <span className="font-semibold text-white">AI</span> উত্তর তৈরি করছে...
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Follow-up Chips (if has messages) */}
      {messages.length > 0 && !isLoading && (
        <div className="px-4 py-1.5 flex gap-2 overflow-x-auto scrollbar-none">
          {quickFollowUps.map((chip, i) => (
            <button
              key={i}
              onClick={() => {
                unlockAudio?.();
                onSendMessage(chip);
              }}
              className="px-2.5 py-1 rounded-full bg-[#160d36] border border-[#2e1961] text-[11px] text-indigo-300 whitespace-nowrap hover:bg-[#20134e] active:scale-95 transition"
            >
              {chip}
            </button>
          ))}
        </div>
      )}

      {/* Voice Listening / Transcribing / Mic Error Indicator */}
      {(isListening || isTranscribing || micError) && (
        <div className="px-4 py-2.5 mx-4 mb-2 rounded-xl bg-gradient-to-r from-sky-950/90 to-purple-950/90 border border-sky-500/40 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              {isListening ? (
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping shrink-0" />
              ) : isTranscribing ? (
                <RefreshCw className="w-3.5 h-3.5 text-sky-400 animate-spin shrink-0" />
              ) : (
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shrink-0" />
              )}
              <span className="text-xs font-medium text-sky-200 leading-snug">
                {micError
                  ? micError
                  : isTranscribing
                  ? 'আপনার বাংলা কথা লেখা হচ্ছে...'
                  : transcript || interimTranscript || 'বাংলায় কথা বলুন, শোনা হচ্ছে...'}
              </span>
            </div>
            {isListening ? (
              <button
                onClick={handleToggleVoiceInput}
                className="text-[11px] font-bold text-rose-300 bg-rose-950/60 border border-rose-700/50 px-2.5 py-1 rounded-lg hover:bg-rose-900/60 shrink-0"
              >
                পাঠান
              </button>
            ) : (
              micError && (
                <button
                  onClick={() => resetTranscript()}
                  className="text-[11px] text-gray-300 hover:text-white px-2 py-0.5 rounded bg-white/5 shrink-0"
                >
                  বন্ধ
                </button>
              )
            )}
          </div>

          {micError && permissionBlocked && (
            <div className="text-[11px] text-amber-200/90 bg-black/25 rounded-lg p-2 space-y-0.5 leading-relaxed">
              <p className="font-semibold text-amber-300">মাইক্রোফোন চালু করার নিয়ম (OPPO A18 Chrome):</p>
              <p>১. ব্রাউজারের উপরে ঠিকানা বারের বাম পাশে সেটিংস/লক আইকনে চাপুন → Permissions → Microphone Allow করুন।</p>
              <p>২. ফোনের Settings → Apps → Chrome → Permissions → Microphone Allow চালু রাখুন।</p>
              <p>৩. অথবা Chrome মেনু থেকে "Install app" দিয়ে ইনস্টল করে সরাসরি ব্যবহার করুন।</p>
            </div>
          )}

          {micError && !permissionBlocked && (
            <button
              type="button"
              onClick={() => {
                unlockAudio?.();
                resetTranscript();
                startListening(true);
              }}
              className="text-[11px] font-medium text-sky-300 underline hover:text-sky-200"
            >
              জেমিনি ভয়েস রেকর্ডিং মোডে আবার চেষ্টা করুন
            </button>
          )}
        </div>
      )}

      {/* Chat Input Bar */}
      <div className="p-3 bg-[#0d0726]/95 border-t border-[#23154a] pb-20">
        <div className="flex items-end gap-2 bg-[#160d38] border border-[#321c6b] rounded-2xl p-1.5 focus-within:border-sky-500/60 focus-within:ring-1 focus-within:ring-sky-500/30 transition shadow-inner">
          {/* Bengali Voice Input Mic Button */}
          <button
            type="button"
            onClick={handleToggleVoiceInput}
            className={`p-2.5 rounded-xl transition shrink-0 active:scale-90 ${
              isListening
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-900/50 animate-bounce'
                : 'text-sky-400 hover:text-sky-300 hover:bg-[#20144d]'
            }`}
            title={isListening ? 'ভয়েস টাইপিং বন্ধ করুন' : 'বাংলায় ভয়েস টাইপিং'}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Textarea */}
          <textarea
            ref={textareaRef}
            rows={1}
            value={inputText}
            onChange={(e) => {
              setInputText(e.target.value);
              e.target.style.height = 'auto';
              e.target.style.height = `${Math.min(e.target.scrollHeight, 120)}px`;
            }}
            onKeyDown={handleKeyDown}
            placeholder="Murad AI-কে বাংলায় যেকোনো প্রশ্ন করুন..."
            className="flex-1 bg-transparent border-0 text-xs text-white placeholder-gray-500 focus:outline-none resize-none py-2 px-1 max-h-28 leading-relaxed font-sans"
          />

          {/* Send Button */}
          <button
            type="button"
            disabled={!inputText.trim() || isLoading}
            onClick={handleSend}
            className={`p-2.5 rounded-xl shrink-0 transition active:scale-95 ${
              inputText.trim() && !isLoading
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-900/40 hover:from-blue-500 hover:to-indigo-500'
                : 'text-gray-500 bg-[#1c1244] opacity-50 cursor-not-allowed'
            }`}
            title="বার্তা পাঠান"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
