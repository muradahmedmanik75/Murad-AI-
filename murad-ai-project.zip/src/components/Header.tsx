import React from 'react';
import { Download, Sparkles, CheckCircle2 } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface HeaderProps {
  onOpenInstallModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenInstallModal }) => {
  const { isInstallable, install } = usePWAInstall();

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0b061d]/85 backdrop-blur-md border-b border-[#25174f] px-4 py-2.5 transition-all">
      <div className="max-w-2xl mx-auto flex items-center justify-between">
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-tr from-[#3b82f6] via-[#8b5cf6] to-[#ec4899] p-[1.5px] shadow-lg shadow-purple-900/40">
            <div className="w-full h-full bg-[#11092b] rounded-[10px] flex items-center justify-center overflow-hidden">
              <img src="/icon.svg" alt="Murad AI" className="w-full h-full object-cover" />
            </div>
            {/* Online Green Pulsing Indicator */}
            <span className="absolute -bottom-0.5 -right-0.5 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500 border-2 border-[#0b061d]"></span>
            </span>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-bold text-base tracking-wide">
                <span className="text-red-500">Murad</span>{' '}
                <span className="text-white">AI</span>
              </h1>
              <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-gradient-to-r from-indigo-500/30 to-purple-500/30 border border-indigo-400/40 text-indigo-300 rounded-full">
                বাংলা
              </span>
            </div>
            <p className="text-[11px] text-gray-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block"></span>
              সক্রিয় ও প্রস্তুত
            </p>
          </div>
        </div>

        {/* Right Action: PWA Install Button & Badge */}
        <div className="flex items-center gap-2">
          {isInstallable ? (
            <button
              onClick={() => {
                if (install) install();
                else if (onOpenInstallModal) onOpenInstallModal();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-xs font-medium shadow-md shadow-blue-900/40 hover:from-blue-500 hover:to-indigo-500 active:scale-95 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>ইনস্টল করুন</span>
            </button>
          ) : (
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#1b103e] border border-[#341e6e] text-[11px] text-indigo-200">
              <Sparkles className="w-3 h-3 text-sky-400" />
              <span>OPPO A18 ফাস্ট মোড</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
