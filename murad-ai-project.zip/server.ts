import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { ZipArchive, ArchiverError } from 'archiver';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '15mb' }));

// Initialize Gemini SDK with User-Agent header and fast failover retry config
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      timeout: 12000,
      retryOptions: {
        attempts: 1,
      },
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const withTimeout = <T>(promise: Promise<T>, ms: number, label = 'TIMEOUT'): Promise<T> => {
  let timer: ReturnType<typeof setTimeout>;
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => {
      timer = setTimeout(() => reject(new Error(label)), ms);
    }),
  ]).finally(() => clearTimeout(timer));
};

const getErrorStatus = (error: any): number => {
  if (typeof error?.status === 'number') return error.status;
  if (typeof error?.code === 'number') return error.code;
  const msg = String(error?.message || '');
  if (msg.includes('503') || msg.includes('UNAVAILABLE')) return 503;
  if (msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED')) return 429;
  if (msg.includes('403') || msg.includes('PERMISSION_DENIED')) return 403;
  if (msg.includes('400') || msg.includes('API_KEY_INVALID')) return 400;
  if (msg.includes('404') || msg.includes('NOT_FOUND')) return 404;
  return 500;
};

const isRetryableError = (error: any): boolean => {
  const status = getErrorStatus(error);
  if ([408, 429, 500, 502, 503, 504].includes(status)) {
    return true;
  }
  const msg = String(error?.message || '').toLowerCase();
  return (
    msg.includes('unavailable') ||
    msg.includes('high demand') ||
    msg.includes('overloaded') ||
    msg.includes('timeout') ||
    msg.includes('timed out') ||
    msg.includes('econnreset') ||
    msg.includes('fetch failed') ||
    msg.includes('network')
  );
};

const ASSISTANT_RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    reply: {
      type: Type.STRING,
      description: 'Polite, concise Bengali reply by male assistant Murad AI addressing মুরাদ ভাই.',
    },
    actionType: {
      type: Type.STRING,
      description:
        'One of: none, open_website, search_web, open_app, make_call, send_sms, set_alarm, set_timer, clear_chat, delete_alarms, check_capabilities, unclear',
    },
    requiresConfirmation: {
      type: Type.BOOLEAN,
      description:
        'True for send_sms, clear_chat, delete_alarms, make_call, open_app, open_website, or any important/irreversible action.',
    },
    confirmationReason: {
      type: Type.STRING,
      description: 'Short Bengali explanation of what permission is being requested.',
    },
    url: {
      type: Type.STRING,
      description: 'HTTPS URL for open_website or search_web.',
    },
    phone: {
      type: Type.STRING,
      description: 'Phone number or contact name for make_call or send_sms.',
    },
    smsBody: {
      type: Type.STRING,
      description: 'Exact SMS message body if actionType is send_sms.',
    },
    appName: {
      type: Type.STRING,
      description: 'App name requested by user (e.g., YouTube, WhatsApp, Facebook, Maps, Camera, Settings).',
    },
    alarmTime: {
      type: Type.STRING,
      description: '24-hour HH:mm string if actionType is set_alarm (e.g., 06:30 or 18:00).',
    },
    alarmLabel: {
      type: Type.STRING,
      description: 'Short Bengali label for alarm or timer.',
    },
    timerSeconds: {
      type: Type.INTEGER,
      description: 'Duration in seconds if actionType is set_timer.',
    },
    nativeNote: {
      type: Type.STRING,
      description: 'Honest Bengali note if a feature requires a Native Android App beyond browser capabilities.',
    },
  },
  required: ['reply', 'actionType', 'requiresConfirmation'],
};

const VALID_ACTION_TYPES = new Set([
  'none',
  'open_website',
  'search_web',
  'open_app',
  'make_call',
  'send_sms',
  'set_alarm',
  'set_timer',
  'clear_chat',
  'delete_alarms',
  'check_capabilities',
  'unclear',
]);

async function generateWithRetryAndFallback(
  ai: GoogleGenAI,
  contents: Array<{ role: string; parts: Array<{ text: string }> }>,
  systemInstruction: string,
  isVoiceMode: boolean,
  structuredAssistant = false
): Promise<string> {
  // Fast model ordering: gemini-4-hydrogen (ThinkingLevel.LOW) primary + gemini-3.1-flash-lite fallback
  const modelCandidates = ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'];
  let lastError: any = null;

  for (const model of modelCandidates) {
    const maxAttempts = model === 'gemini-4-hydrogen' ? 2 : 1;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const config: Record<string, any> = {
          systemInstruction,
        };

        // Keep latency ultra-low for voice & assistant tasks
        if (model === 'gemini-4-hydrogen') {
          config.thinkingConfig = {
            thinkingLevel: isVoiceMode || structuredAssistant ? ThinkingLevel.LOW : ThinkingLevel.LOW,
          };
        }

        if (structuredAssistant) {
          config.responseMimeType = 'application/json';
          config.responseSchema = ASSISTANT_RESPONSE_SCHEMA;
        }

        const response = await withTimeout(
          ai.models.generateContent({
            model,
            contents,
            config,
          }),
          isVoiceMode ? 10500 : 14000,
          'CHAT_TIMEOUT'
        );

        const text = response.text?.trim();
        if (text) {
          return text;
        }

        throw new Error('EMPTY_RESPONSE');
      } catch (err: any) {
        lastError = err;
        const status = getErrorStatus(err);
        const retryable = isRetryableError(err) || err?.message === 'EMPTY_RESPONSE';

        console.warn(
          `[Gemini API] Model ${model} attempt ${attempt}/${maxAttempts} failed (status=${status}):`,
          err?.message || err
        );

        if (status === 400 || status === 401 || status === 403) {
          throw err;
        }

        if (status === 404 || err?.message === 'CHAT_TIMEOUT') {
          break;
        }

        if (!retryable) {
          throw err;
        }

        if (attempt < maxAttempts) {
          const backoffMs = 450 * Math.pow(2, attempt - 1) + Math.floor(Math.random() * 150);
          await sleep(backoffMs);
        }
      }
    }
  }

  throw lastError || new Error('সার্ভার থেকে কোনো উত্তর পাওয়া যায়নি।');
}

const cleanTextForTTS = (text: string): string => {
  return text
    .replace(/```[\s\S]*?```/g, 'কোড অংশ বাদ দেওয়া হলো।')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/#{1,6}\s+/g, '')
    .replace(/[*_]{1,3}([^*_]+)[*_]{1,3}/g, '$1')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/[>#*~_]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 900); // Keep concise for fast playback & low memory on OPPO A18
};

// API: Health check
app.get('/api/health', (_req: Request, res: Response) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY);
  res.json({
    status: 'ok',
    hasApiKey: hasKey,
    app: 'Murad AI',
    time: new Date().toISOString(),
  });
});

// API: Download complete Murad AI project as a clean ZIP (excludes secrets, node_modules, build artifacts)
app.get('/api/download-project-zip', (_req: Request, res: Response) => {
  const excludedDirs = new Set([
    'node_modules',
    'dist',
    'dev-dist',
    '.git',
    '.aistudio',
    'apk-output',
    '.gradle',
    'build',
  ]);

  const shouldExcludeFile = (name: string): boolean => {
    const lower = name.toLowerCase();
    if (lower === '.ds_store') return true;
    if (lower.startsWith('.env') && lower !== '.env.example') return true;
    if (
      lower.endsWith('.log') ||
      lower.endsWith('.apk') ||
      lower.endsWith('.aab') ||
      lower.endsWith('.keystore') ||
      lower.endsWith('.jks')
    ) {
      return true;
    }
    return false;
  };

  try {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="murad-ai-project.zip"');
    res.setHeader('Cache-Control', 'no-store');

    const archive = new ZipArchive({ zlib: { level: 6 } });

    archive.on('error', (err: ArchiverError) => {
      console.error('Project ZIP archive error:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'ZIP ফাইল তৈরি করতে সমস্যা হয়েছে।' });
      } else {
        res.end();
      }
    });

    archive.pipe(res);

    const appendRecursive = (absDir: string, relDir: string) => {
      const entries = fs.readdirSync(absDir, { withFileTypes: true });
      for (const entry of entries) {
        const entryName = entry.name;
        const absPath = path.join(absDir, entryName);
        const relPath = relDir ? path.posix.join(relDir, entryName) : entryName;

        if (entry.isDirectory()) {
          if (!excludedDirs.has(entryName)) {
            appendRecursive(absPath, relPath);
          }
        } else if (entry.isFile()) {
          if (!shouldExcludeFile(entryName)) {
            archive.file(absPath, { name: relPath });
          }
        }
      }
    };

    appendRecursive(__dirname, '');
    archive.finalize();
  } catch (err) {
    console.error('Download ZIP route error:', err);
    if (!res.headersSent) {
      res.status(500).json({ error: 'প্রজেক্ট ZIP ডাউনলোড করা যায়নি।' });
    }
  }
});

// API: Bengali Chat with Murad AI
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { messages, userProfile, isVoiceMode, isAssistantMode, customTone } = req.body;

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(500).json({
        error:
          'জেমিনি এআই এপিআই কী (API Key) কনফিগার করা নেই। অনুগ্রহ করে সেটিংস প্যানেলে কী সংযুক্ত আছে কিনা তা নিশ্চিত করুন।',
      });
    }

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({
        error: 'অনুগ্রহ করে বার্তা প্রদান করুন।',
      });
    }

    const userName = userProfile?.name?.trim() || 'মুরাদ ভাই';
    const persona = customTone || 'বন্ধুভাবাপন্ন ও প্রজ্ঞাবান সহায়ক';
    const savedContactsList = Array.isArray(userProfile?.quickContacts) && userProfile.quickContacts.length > 0
      ? userProfile.quickContacts
          .slice(0, 10)
          .map((c: any) => `${c.name}: ${c.phone}`)
          .join(', ')
      : 'কোনো সংরক্ষিত কন্টাক্ট নেই';
    const useStructured = Boolean(isVoiceMode || isAssistantMode);

    const systemInstruction = `আপনি "Murad AI" — বাংলা ভাষার অত্যন্ত আধুনিক, দ্রুত, বিনয়ী, প্রজ্ঞাবান এবং নির্ভরযোগ্য একজন পুরুষ ব্যক্তিগত এআই ভয়েস ও টাস্ক সহকারী (Personal AI Voice Assistant)।
আপনার প্রধান ব্যবহারকারী হলেন মুরাদ ভাই (প্রোফাইল নাম: ${userName})।
আপনার চরিত্র ও বাচনভঙ্গি: ${persona}।
সংরক্ষিত দ্রুত কন্টাক্ট: ${savedContactsList}।

কঠোর নিয়মাবলী (অবশ্যই অনুসরণ করবেন):
১. অভিবাদন: ব্যবহারকারীকে সবসময় কেবল "আসসালামু আলাইকুম" বলে অভিবাদন জানাবেন (যেমন: "আসসালামু আলাইকুম, মুরাদ ভাই!")। কখনোই কোনো অবস্থাতেই "নমস্কার", "নমস্তে", "আদাব", "হ্যালো", "হাই" বা অন্য কোনো অভিবাদন বলবেন না।
২. সম্বোধন: কথোপকথনে ব্যবহারকারীকে সবসময় আন্তরিকতা ও সম্মানের সাথে "মুরাদ ভাই" বলে সম্বোধন করবেন।
৩. ভাষা ও মান: সম্পূর্ণ উত্তর সবসময় সুন্দর, শুদ্ধ, মার্জিত ও প্রাঞ্জল বাংলা ভাষায় হতে হবে। ইংরেজি বাক্য ব্যবহার করবেন না।
৪. পুরুষ বাচনভঙ্গি: নিজের সম্পর্কে কথা বলার সময় বিনয়ী ও পরিশীলিত পুরুষ কণ্ঠের উপযোগী বাচনভঙ্গি বজায় রাখবেন।
${isVoiceMode ? '৫. ভয়েস মোড নির্দেশনা: ব্যবহারকারী বর্তমানে লাইভ ভয়েস অ্যাসিস্ট্যান্ট মোডে আছেন। তাই উত্তরটি ১ থেকে ৩টি সুনির্দিষ্ট, শ্রুতিমধুর ও সংক্ষিপ্ত শুদ্ধ বাংলা বাক্যে রাখুন, যাতে কণ্ঠে দ্রুত শোনানো যায়।' : '৫. চ্যাট মোড নির্দেশনা: মুরাদ ভাইয়ের প্রশ্নের পরিষ্কার, গোছানো (প্রয়োজনে প্যারাগ্রাফ বা বুলেট পয়েন্ট) ও তথ্যসমৃদ্ধ উত্তর দিন।'}
${useStructured ? `৬. কমান্ড ও অ্যাকশন পার্সিং (JSON output):
- যদি মুরাদ ভাই কোনো ওয়েবসাইট খুলতে বলেন -> actionType: "open_website", url দিন (https://...), requiresConfirmation: true।
- যদি কিছু গুগল/ইন্টারনেটে খুঁজতে বলেন -> actionType: "search_web", url: "https://www.google.com/search?q=...", requiresConfirmation: true।
- যদি Android অ্যাপ (যেমন YouTube, WhatsApp, Facebook, Google Maps, Gmail, Instagram, Play Store) খুলতে বলেন -> actionType: "open_app", appName দিন, requiresConfirmation: true। যদি এমন কোনো সিস্টেম অ্যাপ (যেমন Settings/Camera/Gallery/File Manager) হয় যা ওয়েব ব্রাউজার সরাসরি খুলতে পারে না, তবে nativeNote-এ পরিষ্কার করে বলুন এটির জন্য Native Android App প্রয়োজন।
- যদি কল করতে বলেন -> actionType: "make_call", phone-এ নম্বর বা কন্টাক্টের নাম দিন, requiresConfirmation: true (অনুমতি চাওয়ার বাক্য reply-তে বলুন)।
- যদি SMS পাঠাতে বলেন -> actionType: "send_sms", phone ও smsBody দিন, requiresConfirmation: true (অবশ্যই অনুমতির জন্য জিজ্ঞাসা করুন)।
- যদি অ্যালার্ম সেট করতে বলেন -> actionType: "set_alarm", alarmTime ("HH:mm" 24-hour format) ও alarmLabel দিন, requiresConfirmation: false। মনে রাখবেন: এটি অ্যাপ খোলা থাকা অবস্থায় ইন-অ্যাপ অ্যালার্ম হিসেবে বাজবে; ফোন বন্ধ/অ্যাপ বন্ধ অবস্থায় সিস্টেম অ্যালার্মের জন্য Native Android App দরকার—এটা nativeNote-এ সংক্ষেপে জানাবেন।
- যদি টাইমার সেট করতে বলেন (যেমন ৫ মিনিট পর মনে করিয়ে দাও) -> actionType: "set_timer", timerSeconds দিন, requiresConfirmation: false।
- যদি চ্যাট বা অ্যালার্ম মুছে ফেলতে বলেন -> actionType: "clear_chat" বা "delete_alarms", requiresConfirmation: true (কখনোই অনুমতি ছাড়া মুছবেন না)।
- যদি ব্যবহারকারীর কথা অস্পষ্ট, অর্থহীন বা আংশিক মনে হয় -> actionType: "unclear", requiresConfirmation: false এবং বিনয়ের সাথে আবার বলতে অনুরোধ করুন।
- সাধারণ প্রশ্ন/কথোপকথনে -> actionType: "none", requiresConfirmation: false।` : ''}`;

    const cleanMessages = messages
      .filter(
        (msg: { role: string; content: string; isError?: boolean }) =>
          msg && typeof msg.content === 'string' && msg.content.trim().length > 0 && !msg.isError
      )
      .slice(-10);

    if (cleanMessages.length === 0) {
      return res.status(400).json({
        error: 'অনুগ্রহ করে একটি বৈধ বার্তা লিখুন।',
      });
    }

    const contents = cleanMessages.map((msg: { role: string; content: string }) => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.content.trim() }],
    }));

    const rawOutput = await generateWithRetryAndFallback(
      ai,
      contents,
      systemInstruction,
      Boolean(isVoiceMode),
      useStructured
    );

    const sanitizeBengaliGreeting = (txt: string) =>
      txt
        .replace(/নমস্কার[!।,\s]*/g, 'আসসালামু আলাইকুম! ')
        .replace(/নমস্তে[!।,\s]*/g, 'আসসালামু আলাইকুম! ')
        .trim();

    if (useStructured) {
      try {
        const parsed = JSON.parse(rawOutput);
        const replyText = sanitizeBengaliGreeting(String(parsed.reply || ''));
        const actionType = VALID_ACTION_TYPES.has(parsed.actionType)
          ? parsed.actionType
          : 'none';

        // Hard safety gate: sensitive or destructive actions ALWAYS require explicit confirmation
        const sensitiveTypes = new Set([
          'send_sms',
          'clear_chat',
          'delete_alarms',
          'make_call',
          'open_app',
          'open_website',
          'search_web',
        ]);

        const action = {
          type: actionType,
          requiresConfirmation: sensitiveTypes.has(actionType)
            ? true
            : Boolean(parsed.requiresConfirmation),
          confirmationReason: parsed.confirmationReason || undefined,
          label: parsed.alarmLabel || parsed.appName || undefined,
          url: typeof parsed.url === 'string' && /^https?:\/\//i.test(parsed.url) ? parsed.url : undefined,
          phone: parsed.phone || undefined,
          smsBody: parsed.smsBody || undefined,
          appName: parsed.appName || undefined,
          alarmTime: parsed.alarmTime || undefined,
          alarmLabel: parsed.alarmLabel || undefined,
          timerSeconds: typeof parsed.timerSeconds === 'number' ? parsed.timerSeconds : undefined,
          nativeNote: parsed.nativeNote || undefined,
        };

        return res.json({
          reply: replyText || 'জি মুরাদ ভাই, আপনার কথা শুনেছি। অনুগ্রহ করে আবার বলবেন?',
          action,
        });
      } catch (_) {
        // Fallback to plain reply if JSON parse fails
      }
    }

    const replyText = sanitizeBengaliGreeting(rawOutput);

    return res.json({
      reply: replyText,
      action: { type: 'none', requiresConfirmation: false },
    });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    const status = getErrorStatus(error);

    if (status === 503) {
      return res.status(503).json({
        error:
          'এআই সার্ভারে বর্তমানে অতিরিক্ত চাপ রয়েছে (Error 503)। অনুগ্রহ করে কয়েক সেকেন্ড পর আবার চেষ্টা করুন।',
        retryable: true,
      });
    }

    if (status === 429) {
      return res.status(429).json({
        error:
          'এই মুহূর্তে অনেক বেশি অনুরোধ পাঠানো হয়েছে। অনুগ্রহ করে কিছুক্ষণ অপেক্ষা করে আবার চেষ্টা করুন।',
        retryable: true,
      });
    }

    if (status === 403 || status === 401 || status === 400) {
      return res.status(status).json({
        error:
          'এপিআই কী (API Key) যাচাই করা যায়নি। অনুগ্রহ করে Settings > Secrets প্যানেলে আপনার জেমিনি এপিআই কী পরীক্ষা করুন।',
        retryable: false,
      });
    }

    return res.status(500).json({
      error:
        'Murad AI সার্ভারে সাময়িক সংযোগ সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।',
      retryable: true,
    });
  }
});

// API: Bengali Text-to-Speech (TTS)
app.post('/api/tts', async (req: Request, res: Response) => {
  try {
    const { text } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({ fallbackToBrowser: true });
    }

    if (!text || typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({
        error: 'শোনানোর জন্য কোনো লেখা পাওয়া যায়নি।',
      });
    }

    const cleanedText = cleanTextForTTS(text);
    if (!cleanedText) {
      return res.status(400).json({
        error: 'বৈধ বাংলা লেখা পাওয়া যায়নি।',
      });
    }

    try {
      const response = await withTimeout(
        ai.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [
            {
              role: 'user',
              parts: [{ text: cleanedText }],
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: 'Orus' },
              },
            },
          },
        }),
        4500,
        'TTS_TIMEOUT'
      );

      const base64Audio =
        response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

      if (base64Audio) {
        return res.json({
          audioBase64: base64Audio,
          mimeType: 'audio/wav',
        });
      }
    } catch (_) {
      // Model not enabled or slow; instruct client to use built-in Bengali male TTS immediately
    }

    return res.json({ fallbackToBrowser: true });
  } catch (error: any) {
    console.error('TTS route error:', error?.message || error);
    return res.json({ fallbackToBrowser: true });
  }
});

// API: Bengali Audio Transcription (Universal Mic Support for OPPO A18 & all browsers)
app.post('/api/transcribe', async (req: Request, res: Response) => {
  try {
    const { audioBase64, mimeType } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.status(500).json({
        error: 'এপিআই কী কনফিগার করা নেই।',
      });
    }

    if (!audioBase64 || typeof audioBase64 !== 'string' || audioBase64.trim().length < 50) {
      return res.status(400).json({
        error: 'পর্যাপ্ত অডিও ডেটা পাওয়া যায়নি। অনুগ্রহ করে আবার বলুন।',
      });
    }

    const rawMime = typeof mimeType === 'string' ? mimeType.split(';')[0].trim().toLowerCase() : '';
    const safeMimeType =
      rawMime === 'video/webm' || !rawMime
        ? 'audio/webm'
        : rawMime.startsWith('audio/')
        ? rawMime
        : 'audio/webm';
    const models = ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'];
    let lastError: any = null;

    for (const model of models) {
      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          const config: Record<string, any> = {
            systemInstruction:
              'You are a strict Bengali Automatic Speech Recognition (ASR) engine. NEVER reply conversationally, NEVER ask questions, NEVER greet, and NEVER explain anything. Your sole task is to transcribe exact spoken Bengali words (বাংলা) from the audio. If there is no clear human speech (such as silence, noise, or pure tones), output exactly the single word SILENT.',
          };
          if (model === 'gemini-4-hydrogen') {
            config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
          }

          const response = await withTimeout(
            ai.models.generateContent({
              model,
              contents: {
                parts: [
                  {
                    inlineData: {
                      mimeType: safeMimeType,
                      data: audioBase64,
                    },
                  },
                  {
                    text: 'Transcribe any spoken Bengali speech in this audio verbatim in Bengali script. If there is no spoken human speech, reply ONLY with SILENT.',
                  },
                ],
              },
              config,
            }),
            13000,
            'TRANSCRIBE_TIMEOUT'
          );

          let text = (response.text || '').trim();
          if (/^SILENT[\s.,!]*$/i.test(text)) {
            text = '';
          }
          return res.json({ text });
        } catch (err: any) {
          lastError = err;
          console.warn(`[Transcribe] Model ${model} attempt ${attempt} failed:`, err?.message || err);
          const status = getErrorStatus(err);
          if (status === 400 || status === 401 || status === 403 || status === 404 || err?.message === 'TRANSCRIBE_TIMEOUT') {
            break;
          }
          if (attempt < 2 && isRetryableError(err)) {
            await sleep(600);
            continue;
          }
          break;
        }
      }
    }

    throw lastError || new Error('Transcription failed');
  } catch (error: any) {
    console.error('Gemini Transcribe Error:', error?.message || error);
    return res.status(500).json({
      error: 'আপনার কণ্ঠস্বর বুঝতে সাময়িক সমস্যা হয়েছে। দয়া করে আবার বলুন।',
    });
  }
});

// Vite middleware in dev or static files in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, 'dist');
    app.get('/manifest.webmanifest', (_req: Request, res: Response) => {
      res.setHeader('Cache-Control', 'no-cache');
      res.type('application/manifest+json');
      res.sendFile(path.join(distDir, 'manifest.json'));
    });
    app.use(
      express.static(distDir, {
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('sw.js') || filePath.endsWith('manifest.json')) {
            res.setHeader('Cache-Control', 'no-cache');
          }
          if (filePath.endsWith('manifest.json')) {
            res.type('application/manifest+json');
          }
        },
      })
    );
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Murad AI Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
