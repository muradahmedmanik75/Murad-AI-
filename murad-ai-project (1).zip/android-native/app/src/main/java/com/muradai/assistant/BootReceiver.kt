package com.muradai.assistant

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * Restarts Murad AI's Foreground Microphone Service after device reboot
 * when microphone permission is granted and OPPO Auto-launch is enabled.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_LOCKED_BOOT_COMPLETED) {
            return
        }

        val hasMic = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasMic) return

        val prefs = context.getSharedPreferences(WakeWordService.PREFS_NAME, Context.MODE_PRIVATE)
        val wakeEnabled = prefs.getBoolean(WakeWordService.KEY_WAKE_ENABLED, true)
        if (!wakeEnabled) return

        val serviceIntent = Intent(context, WakeWordService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (_: Exception) {
            // Android 14+ may restrict background microphone FGS from BOOT_COMPLETED on some OEMs
        }
    }
}
