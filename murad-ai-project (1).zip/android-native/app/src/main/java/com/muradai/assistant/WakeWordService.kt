package com.muradai.assistant

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Native Android Microphone Foreground Service for solo "Murad" wake word & Bengali voice assistant.
 * Optimized for OPPO A18 (4GB RAM / ColorOS):
 * - Continues listening in the background even when the app is closed or phone screen is OFF.
 * - Wakes immediately on solo "Murad" / "মুরাদ" without requiring any prefix word.
 * - Restarts cleanly on swipe-close (onTaskRemoved) when Wake Word is enabled.
 * - Zero API keys embedded in APK: connects strictly to the Murad AI HTTPS backend.
 */
class WakeWordService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL_ID = "murad_ai_wake_channel"
        const val NOTIFICATION_ID = 1001
        const val PREFS_NAME = "murad_ai_native_prefs"
        const val KEY_WAKE_ENABLED = "wake_enabled"
        const val ACTION_STOP_SERVICE = "com.muradai.assistant.STOP_WAKE_SERVICE"

        @Volatile
        var isServiceRunning: Boolean = false
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var awaitingCommand = false
    private var isRecognizing = false
    private var pendingSensitiveAction: JSONObject? = null
    private var consecutiveErrors = 0
    private var isDestroyed = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val pendingSpeechCallbacks = mutableMapOf<String, () -> Unit>()

    override fun onCreate() {
        super.onCreate()
        isServiceRunning = true
        createNotificationChannel()
        tts = TextToSpeech(this, this)
        acquirePartialWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_WAKE_ENABLED, false)
                .apply()
            isServiceRunning = false
            stopSelf()
            return START_NOT_STICKY
        }

        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_WAKE_ENABLED, true)
            .apply()
        isServiceRunning = true

        val notification = buildForegroundNotification("শুধু “Murad” বলার অপেক্ষায়... (ব্যাকগ্রাউন্ড ও স্ক্রিন-অফ সক্রিয়)")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.post { startListeningLoop() }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val wakeEnabled = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_WAKE_ENABLED, true)
        if (wakeEnabled) {
            try {
                val restartIntent = Intent(applicationContext, WakeWordService::class.java)
                val pendingIntent = PendingIntent.getService(
                    applicationContext,
                    2001,
                    restartIntent,
                    PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                )
                val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                alarmManager.set(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + 1200L,
                    pendingIntent
                )
            } catch (_: Exception) {
            }
        }
        super.onTaskRemoved(rootIntent)
    }

    private fun acquirePartialWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MuradAI::WakeWordLock").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun wakeScreenAndOpenActivity() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        val screenWake = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "MuradAI::ScreenWake"
        )
        screenWake.acquire(8000L)

        val launchIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("wokenByMurad", true)
        }
        startActivity(launchIntent)
    }

    private fun playWakeBeep() {
        try {
            val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 75)
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 140)
            mainHandler.postDelayed({ tone.release() }, 240L)
        } catch (_: Exception) {
        }
    }

    private fun updateNotificationStatus(text: String) {
        try {
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(NOTIFICATION_ID, buildForegroundNotification(text))
        } catch (_: Exception) {
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isDestroyed) return
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({ startListeningLoop() }, delayMs)
    }

    private fun startListeningLoop() {
        if (isDestroyed || isRecognizing || !SpeechRecognizer.isRecognitionAvailable(this)) return

        try {
            isRecognizing = true
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}

                    override fun onError(error: Int) {
                        isRecognizing = false
                        consecutiveErrors++
                        // Adaptive OPPO A18 4GB RAM backoff to preserve battery when silent
                        val delay = when {
                            consecutiveErrors > 6 -> 1600L
                            error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 850L
                            else -> 380L
                        }
                        scheduleRestart(delay)
                    }

                    override fun onResults(results: Bundle?) {
                        isRecognizing = false
                        consecutiveErrors = 0
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        handleSpokenCandidates(matches ?: emptyList())
                    }
                })
            }

            val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                // Always prioritize Bengali (Bangladesh); accurately catches solo "Murad" / "মুরাদ"
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 4)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 750L)
            }
            speechRecognizer?.startListening(recognizerIntent)
        } catch (_: Exception) {
            isRecognizing = false
            scheduleRestart(1000L)
        }
    }

    private fun handleSpokenCandidates(candidates: List<String>) {
        if (candidates.isEmpty()) {
            scheduleRestart(300L)
            return
        }

        val primaryText = candidates.first().trim()

        // 1. Handle verbal confirmation for pending Call / SMS
        pendingSensitiveAction?.let { pending ->
            val lower = primaryText.lowercase(Locale.ROOT)
            if (lower.contains("হ্যাঁ") || lower.contains("জি") || lower.contains("ঠিক আছে") || lower.contains("yes") || lower.contains("পাঠাও") || lower.contains("করো")) {
                pendingSensitiveAction = null
                executeAndroidAction(pending)
                speakBengali("জি মুরাদ ভাই, আপনার অনুমতি অনুযায়ী কাজটি সম্পন্ন করছি।") {
                    scheduleRestart(250L)
                }
                return
            } else if (lower.contains("না") || lower.contains("বাতিল") || lower.contains("cancel") || lower.contains("no")) {
                pendingSensitiveAction = null
                speakBengali("ঠিক আছে মুরাদ ভাই, কাজটি বাতিল করা হয়েছে।") {
                    scheduleRestart(250L)
                }
                return
            }
            pendingSensitiveAction = null
        }

        // 2. Solo "Murad" wake word check (no prefix needed)
        if (!awaitingCommand) {
            val matchedCandidate = candidates.firstOrNull { isSoloMuradWakeWord(it) }
            if (matchedCandidate != null) {
                playWakeBeep()
                wakeScreenAndOpenActivity()
                updateNotificationStatus("Murad AI সক্রিয় — আপনার বাংলা নির্দেশ শুনছে...")

                val inlineCommand = extractInlineCommand(matchedCandidate)
                if (inlineCommand.isNotEmpty()) {
                    sendCommandToMuradServer(inlineCommand)
                } else {
                    awaitingCommand = true
                    speakBengali("আসসালামু আলাইকুম, মুরাদ ভাই! বলুন, আমি শুনছি।") {
                        scheduleRestart(120L)
                    }
                }
            } else {
                scheduleRestart(260L)
            }
            return
        }

        // 3. Process Bengali voice command immediately after waking
        awaitingCommand = false
        updateNotificationStatus("শুধু “Murad” বলার অপেক্ষায়... (ব্যাকগ্রাউন্ড ও স্ক্রিন-অফ সক্রিয়)")
        if (primaryText.isBlank()) {
            speakBengali("দুঃখিত মুরাদ ভাই, আপনার কথাটি স্পষ্ট বুঝতে পারিনি। আবার বলবেন?") {
                scheduleRestart(150L)
            }
            return
        }
        sendCommandToMuradServer(primaryText)
    }

    private fun isSoloMuradWakeWord(text: String): Boolean {
        val clean = text.trim().lowercase(Locale.ROOT)
        val wakeTokens = listOf("murad", "murat", "morad", "muradh", "মুরাদ", "মোরাদ", "মুড়াদ", "মুড়াদ", "মুরাত")
        if (wakeTokens.any { token ->
                clean == token ||
                    clean.startsWith("$token ") ||
                    clean.startsWith("$token,") ||
                    clean.startsWith("$token।")
            }
        ) {
            return true
        }
        val words = clean.split(Regex("\\s+"))
        return words.size <= 4 && wakeTokens.any { token -> words.contains(token) }
    }

    private fun extractInlineCommand(text: String): String {
        return text.trim()
            .replace(Regex("(?i)^(?:murad|murat|morad|muradh)(?:\\s+ai|\\s+bhai|\\s+ভাই)?[\\s,।:!?-]*"), "")
            .replace(Regex("^(?:মুরাদ|মোরাদ|মুড়াদ|মুড়াদ|মুরাত)(?:\\s+এআই|\\s+ai|\\s+ভাই)?[\\s,।:!?-]*"), "")
            .trim()
    }

    private fun sendCommandToMuradServer(command: String) {
        networkExecutor.execute {
            try {
                val url = URL("${BuildConfig.MURAD_SERVER_URL}/api/chat")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    connectTimeout = 9000
                    readTimeout = 14000
                    doOutput = true
                }

                val payload = JSONObject().apply {
                    put("isVoiceMode", true)
                    put("isAssistantMode", true)
                    put("messages", JSONArray().put(JSONObject().apply {
                        put("role", "user")
                        put("content", command)
                    }))
                }

                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

                val responseText = conn.inputStream.bufferedReader(Charsets.UTF_8).readText()
                val json = JSONObject(responseText)
                val reply = json.optString("reply", "মুরাদ ভাই, দয়া করে আবার বলবেন?")
                val action = json.optJSONObject("action")

                if (action != null) {
                    val actionType = action.optString("type", "none")
                    val requiresConfirmation = action.optBoolean("requiresConfirmation", false)
                    if (actionType != "none" && actionType != "unclear") {
                        if (requiresConfirmation) {
                            pendingSensitiveAction = action
                        } else {
                            mainHandler.post { executeAndroidAction(action) }
                        }
                    }
                }

                speakBengali(reply) {
                    scheduleRestart(250L)
                }
            } catch (_: Exception) {
                speakBengali("মুরাদ ভাই, সার্ভারে সংযোগ পেতে সমস্যা হয়েছে। আবার চেষ্টা করুন।") {
                    scheduleRestart(450L)
                }
            }
        }
    }

    private fun executeAndroidAction(action: JSONObject) {
        val type = action.optString("type", "none")
        try {
            when (type) {
                "open_website", "search_web" -> {
                    val targetUrl = action.optString("url")
                    if (targetUrl.startsWith("http")) {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    }
                }
                "open_app" -> {
                    val appName = action.optString("appName").lowercase(Locale.ROOT)
                    val pkg = when {
                        appName.contains("youtube") || appName.contains("ইউটিউব") -> "com.google.android.youtube"
                        appName.contains("whatsapp") || appName.contains("হোয়াটসঅ্যাপ") -> "com.whatsapp"
                        appName.contains("facebook") || appName.contains("ফেসবুক") -> "com.facebook.katana"
                        appName.contains("map") || appName.contains("ম্যাপ") -> "com.google.android.apps.maps"
                        appName.contains("instagram") || appName.contains("ইনস্টাগ্রাম") -> "com.instagram.android"
                        appName.contains("gmail") || appName.contains("মেইল") -> "com.google.android.gm"
                        else -> null
                    }
                    val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
                    if (launch != null) {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(launch)
                    }
                }
                "make_call" -> {
                    val phone = action.optString("phone").replace(Regex("[^\\d+]"), "")
                    if (phone.isNotEmpty()) {
                        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    }
                }
                "send_sms" -> {
                    val phone = action.optString("phone").replace(Regex("[^\\d+]"), "")
                    val body = action.optString("smsBody")
                    val smsIntent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone")).apply {
                        putExtra("sms_body", body)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(smsIntent)
                }
                "set_alarm" -> {
                    val timeParts = action.optString("alarmTime").split(":")
                    if (timeParts.size == 2) {
                        val hour = timeParts[0].toIntOrNull() ?: return
                        val minute = timeParts[1].toIntOrNull() ?: return
                        val alarmIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                            putExtra(AlarmClock.EXTRA_HOUR, hour)
                            putExtra(AlarmClock.EXTRA_MINUTES, minute)
                            putExtra(AlarmClock.EXTRA_MESSAGE, action.optString("alarmLabel", "Murad AI অ্যালার্ম"))
                            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(alarmIntent)
                    }
                }
                "set_timer" -> {
                    val secs = action.optInt("timerSeconds", 0)
                    if (secs > 0) {
                        val timerIntent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                            putExtra(AlarmClock.EXTRA_LENGTH, secs)
                            putExtra(AlarmClock.EXTRA_MESSAGE, action.optString("alarmLabel", "Murad AI টাইমার"))
                            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(timerIntent)
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun requestTransientAudioFocus() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .build()
                am.requestAudioFocus(req)
            }
        } catch (_: Exception) {
        }
    }

    private fun speakBengali(text: String, onDone: () -> Unit) {
        if (!ttsReady || tts == null) {
            onDone()
            return
        }
        requestTransientAudioFocus()
        val utteranceId = "murad_${System.currentTimeMillis()}"
        pendingSpeechCallbacks[utteranceId] = onDone
        tts?.setPitch(0.85f)
        tts?.setSpeechRate(1.05f)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    private fun selectMaleBengaliVoice() {
        try {
            val voices = tts?.voices ?: return
            val maleBd = voices.firstOrNull { v ->
                v.locale.language == "bn" &&
                    (v.name.contains("male", ignoreCase = true) ||
                        v.name.contains("bnd", ignoreCase = true) ||
                        v.name.contains("bn-bd-x-bdb", ignoreCase = true))
            }
            if (maleBd != null) {
                tts?.voice = maleBd
            }
        } catch (_: Exception) {
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val res = tts?.setLanguage(Locale("bn", "BD"))
            ttsReady = res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) {
                tts?.setLanguage(Locale("bn", "IN"))
                ttsReady = true
            }
            selectMaleBengaliVoice()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    utteranceId?.let { id ->
                        pendingSpeechCallbacks.remove(id)?.let { cb ->
                            mainHandler.post(cb)
                        }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    utteranceId?.let { id ->
                        pendingSpeechCallbacks.remove(id)?.let { cb ->
                            mainHandler.post(cb)
                        }
                    }
                }
            })
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Murad AI Wake Word Service",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(content: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, WakeWordService::class.java).apply { action = ACTION_STOP_SERVICE },
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Murad AI ভয়েস সহকারী")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "বন্ধ করুন",
                    stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isDestroyed = true
        isServiceRunning = false
        isRecognizing = false
        mainHandler.removeCallbacksAndMessages(null)
        pendingSpeechCallbacks.clear()
        speechRecognizer?.destroy()
        tts?.shutdown()
        networkExecutor.shutdownNow()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        super.onDestroy()
    }
}
